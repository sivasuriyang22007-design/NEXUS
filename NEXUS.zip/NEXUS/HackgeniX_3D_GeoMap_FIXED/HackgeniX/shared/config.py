"""Shared configuration for NEXUS analytics."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import json


@dataclass
class AnalyticsConfig:
    seed: int = 42
    bootstrap_samples: int = 1000
    report_dir: str = "reports"
    policies: tuple[str, ...] = (
        "fixed_equal",
        "round_robin",
        "weighted_fair",
        "static_qos",
    )
    qos_weights: dict[str, float] = field(default_factory=dict)
    rr_quantum_mbps: float = 1.0

    @classmethod
    def from_json(cls, path: str | Path) -> "AnalyticsConfig":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if "policies" in data:
            data["policies"] = tuple(data["policies"])
        return cls(**data)
