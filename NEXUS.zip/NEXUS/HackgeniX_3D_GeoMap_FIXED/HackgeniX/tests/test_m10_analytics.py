import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from M10_Analytics.baseline_schedulers import allocate
from M10_Analytics.comparison import TickInput, compare_policies, jain_fairness
from M10_Analytics.what_if_simulation import WhatIfConfig, run_what_if


def sample_trace():
    return [
        TickInput(
            tick=t,
            cell_id="cell-1",
            capacity_mbps=100.0,
            demands_mbps={"u1": 80.0, "u2": 60.0, "u3": 10.0},
            state={"weights": {"u1": 2.0, "u2": 1.0, "u3": 1.0},
                   "qos_weights": {"u1": 3.0, "u2": 1.0, "u3": 1.0}},
        )
        for t in range(10)
    ]


def test_capacity_invariant():
    for policy in ("fixed_equal", "round_robin", "weighted_fair", "static_qos"):
        result = allocate(
            policy,
            {"a": 80.0, "b": 50.0},
            100.0,
            {"weights": {"a": 2, "b": 1}, "qos_weights": {"a": 3, "b": 1}},
        )
        assert sum(result.grants_mbps.values()) <= 100.0 + 1e-8
        assert all(v >= 0 for v in result.grants_mbps.values())


def test_same_trace_comparison():
    result = compare_policies(sample_trace(), seed=42)
    assert result["comparison_contract"]["same_trace"] is True
    assert result["trace_ticks"] == 10
    assert set(result["policies"]) == {
        "fixed_equal", "round_robin", "weighted_fair", "static_qos"
    }
    for policy_data in result["policies"].values():
        assert policy_data["summary"]["capacity_violations"] == 0


def test_fairness_bounds():
    assert 0.0 <= jain_fairness([1, 2, 3]) <= 1.0
    assert jain_fairness([10, 10, 10]) == 1.0


def test_what_if_does_not_mutate_trace():
    trace = sample_trace()
    original = trace[0].capacity_mbps
    result = run_what_if(
        trace,
        WhatIfConfig(capacity_multiplier=0.5, forced_failure_cells=("cell-1",), seed=7),
    )
    assert trace[0].capacity_mbps == original
    assert result["scenario"]["isolated_clone"] is True
    assert result["policies"]["fixed_equal"]["summary"]["mean_granted_mbps"] == 0.0
