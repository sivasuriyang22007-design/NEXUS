"""Timestamped per-cell telemetry from actual SimPy measurement windows."""
from collections import defaultdict, deque
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class LoadSample:
    time_s: float
    offered_mbps: float
    delivered_mbps: float
    queue_mbits: float
    active_users: int
    active_sessions: int
    capacity_mbps: float

    def __post_init__(self):
        values = (self.time_s, self.offered_mbps, self.delivered_mbps,
                  self.queue_mbits, self.capacity_mbps)
        if not all(math.isfinite(v) for v in values) or any(v < 0 for v in values):
            raise ValueError("Telemetry must be finite and nonnegative")
        if self.active_users < 0 or self.active_sessions < 0:
            raise ValueError("Counts must be nonnegative")

class LoadMonitor:
    def __init__(self, max_samples=600):
        self.series = defaultdict(lambda: deque(maxlen=max_samples))

    def record(self, cell_id, sample: LoadSample):
        series = self.series[cell_id]
        if series and sample.time_s <= series[-1].time_s:
            raise ValueError("Samples must be strictly chronological")
        series.append(sample)

    def record_window(self, cell_id, end_s, duration_s, offered_bits,
                      delivered_bits, queue_bits, active_users,
                      active_sessions, capacity_mbps):
        if duration_s <= 0:
            raise ValueError("Window duration must be positive")
        sample = LoadSample(end_s, offered_bits / duration_s / 1e6,
                            delivered_bits / duration_s / 1e6,
                            queue_bits / 1e6, active_users, active_sessions,
                            capacity_mbps)
        self.record(cell_id, sample)
        return sample

    def history(self, cell_id, as_of_s=None, limit=None):
        items = list(self.series.get(cell_id, ()))
        if as_of_s is not None:
            items = [s for s in items if s.time_s <= as_of_s]
        return items[-limit:] if limit else items
