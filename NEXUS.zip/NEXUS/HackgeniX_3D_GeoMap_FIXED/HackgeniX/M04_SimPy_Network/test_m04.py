from environment import SimulationEnvironment
from packet_queue import PacketQueue
from transmission import Transmission
from cell import Cell
from router import Router
from congestion import CongestionMonitor


print("================================")
print("      M04 MODULE TEST")
print("================================")


# 1. ENVIRONMENT TEST
print("\n1. ENVIRONMENT TEST")

env = SimulationEnvironment()

print("Initial time:", env.now)


def test_process():
    print("Process started at:", env.now)
    yield env.timeout(2)
    print("Process ended at:", env.now)


env.process(test_process())
env.run(until=3)

print("Environment: PASS")


# 2. PACKET QUEUE TEST
print("\n2. PACKET QUEUE TEST")

queue = PacketQueue(
    max_bytes=1000
)

packet = {
    "id": 1,
    "size_bytes": 200
}

result = queue.enqueue(
    packet,
    env.now
)

print("Packet added:", result)
print("Queue bytes:", queue.current_bytes)
print("Queue occupancy:", queue.occupancy_ratio)

item = queue.dequeue(env.now)

print("Packet removed:", item)

print("Packet Queue: PASS")
# 3. TRANSMISSION TEST
print("\n3. TRANSMISSION TEST")

packet = {
    "id": 2,
    "size_bytes": 1_000_000
}

transmission = Transmission(
    packet=packet,
    start_time=env.now,
    allocated_mbps=10,
    propagation_delay_ms=5
)

print("Transmission object created successfully")
print("Packet:", transmission.packet)
print("Start time:", transmission.start_time)
print("Allocated Mbps:", transmission.allocated_mbps)
print("Propagation delay:", transmission.propagation_delay_ms)

print("Transmission: PASS")

# 4. CELL TEST
print("\n4. CELL TEST")

cell = Cell(
    "CELL_1",
    100,
    90
)

print("Cell created successfully")
print("Cell:", cell.snapshot())

print("Cell: PASS")


# 5. ROUTER TEST
print("\n5. ROUTER TEST")

router = Router()

router.add_route(
    source="CELL_1",
    destination="CELL_2",
    link_id="L1",
    next_hop="CELL_2"
)

route = router.get_route(
    source="CELL_1",
    destination="CELL_2"
)

print("Route:", route)

print("Router: PASS")


# 6. CONGESTION TEST
print("\n6. CONGESTION TEST")

monitor = CongestionMonitor()

print("CongestionMonitor created successfully")
print("Available methods:")

for name in dir(monitor):
    if not name.startswith("_"):
        print(" -", name)

print("Congestion Monitor: PASS")