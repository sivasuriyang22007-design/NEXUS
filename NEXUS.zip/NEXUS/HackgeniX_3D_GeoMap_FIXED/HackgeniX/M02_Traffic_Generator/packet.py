"""
M02_Traffic_Generator
packet.py

Packet and observation-event representations.

This module intentionally contains no real application names.

It provides:
    - Packet
    - PacketBatch
    - validation
    - direction handling
    - retransmission proxy
    - ordering checks
    - packet statistics
    - serialization
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, Iterable, List, Optional, Tuple
import math


# ============================================================================
# PACKET
# ============================================================================

@dataclass
class Packet:
    """Synthetic packet representation."""

    user_id: str

    timestamp: float

    size_bytes: int

    direction: str

    flow_id: str

    sequence_number: int

    arrival_process: str = "poisson"

    retransmission_proxy: float = 0.0

    late: bool = False

    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:

        self.direction = self.direction.upper()

        if not self.flow_id:
            self.flow_id = (
                f"{self.user_id}_flow_"
                f"{self.sequence_number}"
            )

    def validate(self) -> None:
        """Validate packet fields."""

        if not self.user_id:
            raise ValueError(
                "user_id cannot be empty."
            )

        if not math.isfinite(self.timestamp):
            raise ValueError(
                "timestamp must be finite."
            )

        if self.timestamp < 0:
            raise ValueError(
                "timestamp cannot be negative."
            )

        if self.size_bytes <= 0:
            raise ValueError(
                "size_bytes must be greater than zero."
            )

        if self.direction not in {
            "UL",
            "DL",
        }:
            raise ValueError(
                "direction must be UL or DL."
            )

        if self.sequence_number < 0:
            raise ValueError(
                "sequence_number cannot be negative."
            )

        if not 0 <= self.retransmission_proxy <= 1:
            raise ValueError(
                "retransmission_proxy must be between 0 and 1."
            )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(
        cls,
        data: Dict[str, Any],
    ) -> "Packet":

        packet = cls(**data)

        packet.validate()

        return packet


# ============================================================================
# PACKET BATCH
# ============================================================================

@dataclass
class PacketBatch:
    """Collection of packets belonging to an observation tick."""

    packets: List[Packet]

    timestamp: float = 0.0

    run_id: str = ""

    def validate(self) -> None:

        for packet in self.packets:
            packet.validate()

    @property
    def total_bytes(self) -> int:
        return sum(
            packet.size_bytes
            for packet in self.packets
        )

    @property
    def total_packets(self) -> int:
        return len(self.packets)

    def sort_by_time(self) -> None:

        self.packets.sort(
            key=lambda packet: (
                packet.timestamp,
                packet.user_id,
                packet.sequence_number,
            )
        )

    def to_dict(self) -> Dict[str, Any]:

        return {
            "timestamp": self.timestamp,
            "run_id": self.run_id,
            "total_packets": self.total_packets,
            "total_bytes": self.total_bytes,
            "packets": [
                packet.to_dict()
                for packet in self.packets
            ],
        }


# ============================================================================
# CONVERSION FROM TRAFFIC GENERATOR EVENTS
# ============================================================================

def event_to_packet(event: Any) -> Packet:
    """
    Convert a TrafficEvent from traffic_generator.py into Packet.
    """

    packet = Packet(
        user_id=event.user_id,
        timestamp=event.timestamp,
        size_bytes=event.size_bytes,
        direction=event.direction,
        flow_id=event.flow_id,
        sequence_number=event.sequence_number,
        arrival_process=event.arrival_process,
        retransmission_proxy=0.0,
        metadata={
            "simulation_anomaly": event.anomaly,
        },
    )

    packet.validate()

    return packet


def events_to_packet_batch(
    events: Iterable[Any],
    timestamp: float = 0.0,
    run_id: str = "",
) -> PacketBatch:

    packets = [
        event_to_packet(event)
        for event in events
    ]

    batch = PacketBatch(
        packets=packets,
        timestamp=timestamp,
        run_id=run_id,
    )

    batch.validate()

    return batch


# ============================================================================
# RETRANSMISSION PROXY
# ============================================================================

def assign_retransmission_proxy(
    packets: List[Packet],
    probability: float,
    seed: int = 42,
) -> None:
    """
    Assign a synthetic retransmission proxy.

    This is not a real network retransmission measurement.
    It is a synthetic observable used for experimentation.
    """

    import random

    if not 0 <= probability <= 1:
        raise ValueError(
            "probability must be between 0 and 1."
        )

    rng = random.Random(seed)

    for packet in packets:

        if rng.random() < probability:
            packet.retransmission_proxy = 1.0
        else:
            packet.retransmission_proxy = 0.0


# ============================================================================
# DUPLICATE DETECTION
# ============================================================================

def find_duplicate_packets(
    packets: Iterable[Packet],
) -> List[Packet]:
    """Find packets with duplicate user/sequence identifiers."""

    seen = set()
    duplicates = []

    for packet in packets:

        key = (
            packet.user_id,
            packet.sequence_number,
        )

        if key in seen:
            duplicates.append(packet)
        else:
            seen.add(key)

    return duplicates


# ============================================================================
# ORDER CHECKING
# ============================================================================

def find_out_of_order_packets(
    packets: Iterable[Packet],
) -> List[Packet]:
    """
    Identify packets whose timestamp is earlier than the previously
    observed timestamp for the same user.
    """

    last_timestamp: Dict[str, float] = {}

    out_of_order: List[Packet] = []

    for packet in packets:

        previous = last_timestamp.get(
            packet.user_id
        )

        if (
            previous is not None
            and packet.timestamp < previous
        ):
            out_of_order.append(packet)
            packet.late = True

        last_timestamp[
            packet.user_id
        ] = max(
            packet.timestamp,
            previous if previous is not None else packet.timestamp,
        )

    return out_of_order


# ============================================================================
# PACKET STATISTICS
# ============================================================================

def packet_statistics(
    packets: Iterable[Packet],
) -> Dict[str, Any]:

    packets = list(packets)

    if not packets:
        return {
            "packet_count": 0,
            "total_bytes": 0,
            "mean_size": 0.0,
            "min_size": 0,
            "max_size": 0,
            "ul_packets": 0,
            "dl_packets": 0,
        }

    sizes = [
        packet.size_bytes
        for packet in packets
    ]

    ul_packets = sum(
        packet.direction == "UL"
        for packet in packets
    )

    dl_packets = sum(
        packet.direction == "DL"
        for packet in packets
    )

    return {
        "packet_count": len(packets),
        "total_bytes": sum(sizes),
        "mean_size": sum(sizes) / len(sizes),
        "min_size": min(sizes),
        "max_size": max(sizes),
        "ul_packets": ul_packets,
        "dl_packets": dl_packets,
        "ul_dl_ratio": (
            ul_packets / max(1, dl_packets)
        ),
        "late_packets": sum(
            packet.late
            for packet in packets
        ),
        "retransmission_proxy_mean": (
            sum(
                packet.retransmission_proxy
                for packet in packets
            )
            / len(packets)
        ),
    }


# ============================================================================
# SCHEMA VALIDATION
# ============================================================================

REQUIRED_PACKET_FIELDS = {
    "user_id",
    "timestamp",
    "size_bytes",
    "direction",
    "flow_id",
    "sequence_number",
}


def validate_packet_schema(
    packet: Packet,
) -> Tuple[bool, List[str]]:
    """
    Return (valid, errors) without raising an exception.
    """

    errors: List[str] = []

    data = packet.to_dict()

    missing = (
        REQUIRED_PACKET_FIELDS
        - set(data.keys())
    )

    if missing:
        errors.append(
            f"Missing fields: {sorted(missing)}"
        )

    try:
        packet.validate()
    except (ValueError, TypeError) as exc:
        errors.append(str(exc))

    return (
        len(errors) == 0,
        errors,
    )


# ============================================================================
# SELF TEST
# ============================================================================

def run_self_test() -> bool:

    print("=" * 70)
    print("M02 Packet - Self Test")
    print("=" * 70)

    packets = [
        Packet(
            user_id="user_0001",
            timestamp=0.10,
            size_bytes=800,
            direction="DL",
            flow_id="flow_1",
            sequence_number=1,
        ),
        Packet(
            user_id="user_0001",
            timestamp=0.20,
            size_bytes=1000,
            direction="UL",
            flow_id="flow_1",
            sequence_number=2,
        ),
    ]

    for packet in packets:
        packet.validate()

    print("[PASS] Packet validation")

    batch = PacketBatch(
        packets=packets,
        timestamp=1.0,
        run_id="test_run",
    )

    batch.validate()

    assert batch.total_packets == 2
    assert batch.total_bytes == 1800

    print("[PASS] Packet batch")

    stats = packet_statistics(packets)

    assert stats["packet_count"] == 2
    assert stats["total_bytes"] == 1800

    print("[PASS] Packet statistics")

    assign_retransmission_proxy(
        packets,
        probability=1.0,
        seed=42,
    )

    assert all(
        packet.retransmission_proxy == 1.0
        for packet in packets
    )

    print("[PASS] Retransmission proxy")

    valid, errors = validate_packet_schema(
        packets[0]
    )

    assert valid
    assert not errors

    print("[PASS] Schema validation")

    print()
    print("ALL PACKET TESTS PASSED")
    print("=" * 70)

    return True


if __name__ == "__main__":
    run_self_test()

