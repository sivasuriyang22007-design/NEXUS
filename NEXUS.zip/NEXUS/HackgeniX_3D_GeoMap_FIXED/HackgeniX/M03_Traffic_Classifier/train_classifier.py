"""
NEXUS M03 - Reproducible synthetic traffic classifier training.

Run:
    python -m nexus.ml.train_classifier --config configs/ml.yaml

If your checkout keeps this three-file module outside a Python package, the same
script can be executed directly:
    python M03_Traffic_Classifier/train_classifier.py --config configs/ml.yaml
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
)
from sklearn.model_selection import GroupShuffleSplit, ParameterSampler
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer

try:
    from sklearn.frozen import FrozenEstimator
except ImportError:  # sklearn < 1.8 compatibility
    FrozenEstimator = None

try:
    from xgboost import XGBClassifier
except Exception:
    XGBClassifier = None

try:
    from .feature_extractor import FEATURE_COLUMNS, FEATURE_SCHEMA_VERSION
    from .classifier import SERVICE_CATEGORIES
except ImportError:
    from feature_extractor import FEATURE_COLUMNS, FEATURE_SCHEMA_VERSION
    from classifier import SERVICE_CATEGORIES


MODEL_VERSION = "v1"
DATASET_GENERATOR_VERSION = "m03-synthetic-v1"
CLASS_IDS = list(SERVICE_CATEGORIES.keys())

# Class-specific observable signatures are only for synthetic-data generation.
# They are NOT exposed to the inference model as ground truth.
CLASS_PARAMS = {
    "01_reels": (35, 650, 0.70, 2.5),
    "02_video_480p": (28, 500, 0.70, 2.0),
    "03_video_1080p": (38, 900, 0.75, 3.5),
    "04_video_4k": (45, 1400, 0.85, 5.0),
    "05_ott": (34, 750, 0.72, 3.0),
    "06_live_stream": (45, 800, 0.80, 4.0),
    "07_video_call": (80, 180, 0.50, 0.8),
    "08_voice_call": (45, 120, 0.45, 0.5),
    "09_messaging": (3, 300, 0.30, 0.1),
    "10_browsing": (18, 700, 0.35, 0.7),
    "11_online_gaming": (55, 220, 0.25, 0.4),
    "12_cloud_gaming": (65, 900, 0.45, 5.0),
    "13_ar_vr": (75, 1100, 0.55, 8.0),
    "14_remote_desktop": (42, 600, 0.40, 1.8),
    "15_online_exam": (20, 450, 0.30, 0.5),
    "16_file_download": (70, 1200, 0.20, 8.0),
    "17_backup": (65, 1000, 0.15, 10.0),
    "18_software_update": (60, 1100, 0.18, 8.0),
    "19_p2p": (80, 950, 0.25, 7.0),
    "20_upload": (70, 900, 0.22, 6.0),
    "21_emergency": (35, 300, 0.20, 0.2),
    "22_disaster_stream": (50, 900, 0.75, 4.0),
    "23_medical_telemetry": (12, 180, 0.12, 0.05),
    "24_public_broadcast": (55, 950, 0.65, 5.0),
    "25_operator_control": (8, 160, 0.08, 0.02),
}


class FeatureSchemaValidator:
    """Pipeline transformer that rejects missing/extra columns and reorders columns."""

    def __init__(self, expected_columns: list[str] | None = None):
        self.expected_columns = expected_columns or list(FEATURE_COLUMNS)

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(X)
        missing = [c for c in self.expected_columns if c not in X.columns]
        extra = [c for c in X.columns if c not in self.expected_columns]
        if missing:
            raise ValueError(f"Missing required classifier features: {missing}")
        if extra:
            raise ValueError(f"Unexpected classifier features: {extra}")
        out = X.loc[:, self.expected_columns].copy()
        for col in self.expected_columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
        return out


def _seed_everything(seed: int) -> None:
    np.random.seed(seed)


def _clip_positive(x: np.ndarray, low: float = 1e-5) -> np.ndarray:
    return np.maximum(x, low)


def _synthetic_row(
    class_id: str,
    scenario: str,
    session_id: int,
    tick: int,
    rng: np.random.Generator,
) -> dict[str, Any]:
    packet_rate, packet_size, burst, rate = CLASS_PARAMS[class_id]

    scenario_multiplier = {
        "normal": 1.00,
        "rush_hour": 1.15,
        "flash_crowd": 1.35,
        "mass_event": 1.55,
        "outage": 0.70,
        "recovery": 0.90,
    }[scenario]

    # Scenario/session effects create correlated adjacent ticks; group splitting
    # prevents leakage from those near-duplicates.
    session_factor = float(rng.lognormal(mean=0.0, sigma=0.15))
    time_factor = 1.0 + 0.08 * np.sin(tick / 9.0)
    noise = float(rng.lognormal(mean=0.0, sigma=0.10))

    pps = _clip_positive(
        rng.normal(packet_rate, max(2.0, packet_rate * 0.12))
        * scenario_multiplier
        * session_factor
        * time_factor
    )
    size = _clip_positive(rng.normal(packet_size, packet_size * 0.12))
    size_std = _clip_positive(rng.normal(size * (0.15 + burst * 0.25), size * 0.08))
    duration = _clip_positive(rng.lognormal(np.log(max(0.2, rate)), 0.45))
    burst_frequency = _clip_positive(
        rng.normal(burst * (1.0 + 0.3 * (scenario in {"flash_crowd", "mass_event"})), 0.08)
    )
    ul_dl_ratio = _clip_positive(rng.lognormal(np.log(0.2 + burst * 0.4), 0.20))
    interarrival = _clip_positive(1.0 / pps)
    interarrival_std = _clip_positive(interarrival * (0.35 + burst * 0.55) * noise)
    retransmission = np.clip(
        rng.beta(1.2 + burst * 2, 35) + (scenario == "outage") * 0.02,
        0,
        1,
    )
    rolling1 = _clip_positive(pps * size * 8 / 1e6 * rng.normal(1.0, 0.08))
    rolling5 = _clip_positive(rolling1 * rng.normal(1.0, 0.06))
    rolling10 = _clip_positive(rolling5 * rng.normal(1.0, 0.05))

    return {
        "packet_rate": pps,
        "packet_size_mean": size,
        "packet_size_std": size_std,
        "flow_duration": duration,
        "burst_frequency": burst_frequency,
        "ul_dl_ratio": ul_dl_ratio,
        "interarrival_mean": interarrival,
        "interarrival_std": interarrival_std,
        "retransmission_proxy": retransmission,
        "rolling_rate_1s": rolling1,
        "rolling_rate_5s": rolling5,
        "rolling_rate_10s": rolling10,
        "class_id": class_id,
        "scenario": scenario,
        "session_id": f"{class_id}-{scenario}-session-{session_id}",
        "tick": tick,
    }


def generate_dataset(
    *,
    seed: int,
    samples_per_class: int = 220,
) -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    """Generate varied scenarios with grouped session/scenario identities."""
    rng = np.random.default_rng(seed)
    scenarios = ["normal", "rush_hour", "flash_crowd", "mass_event", "outage", "recovery"]
    rows: list[dict[str, Any]] = []

    for class_id in CLASS_IDS:
        for i in range(samples_per_class):
            class_index = CLASS_IDS.index(class_id)
            scenario = scenarios[(i + seed + class_index) % len(scenarios)]
            session_id = i // 6  # six adjacent ticks can be near duplicates
            tick = i % 6
            rows.append(_synthetic_row(class_id, scenario, session_id, tick, rng))

    frame = pd.DataFrame(rows)
    y = frame.pop("class_id").to_numpy()
    groups = frame["session_id"].to_numpy()
    frame = frame.drop(columns=["scenario", "session_id", "tick"])
    return frame, y, groups


def group_split(
    X: pd.DataFrame,
    y: np.ndarray,
    groups: np.ndarray,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, np.ndarray, np.ndarray, np.ndarray]:
    """70/15/15 grouped split with class coverage in every partition.

    Grouping is mandatory to prevent adjacent ticks from the same synthetic
    session/scenario crossing train/calibration/test boundaries. Candidate
    grouped splits are retried until all classes are represented in each
    partition, which is important for 25-class calibration.
    """
    all_classes = set(np.unique(y))

    for attempt in range(100):
        split_seed = seed + attempt * 101
        gss = GroupShuffleSplit(n_splits=1, test_size=0.15, random_state=split_seed)
        train_cal_idx, test_idx = next(gss.split(X, y, groups=groups))

        X_train_cal = X.iloc[train_cal_idx]
        y_train_cal = y[train_cal_idx]
        g_train_cal = groups[train_cal_idx]

        gss2 = GroupShuffleSplit(
            n_splits=1,
            test_size=0.1764705882,
            random_state=split_seed + 17,
        )
        train_idx_local, cal_idx_local = next(
            gss2.split(X_train_cal, y_train_cal, groups=g_train_cal)
        )
        train_idx = X_train_cal.index[train_idx_local]
        cal_idx = X_train_cal.index[cal_idx_local]

        if (
            set(y[train_idx]) == all_classes
            and set(y[cal_idx]) == all_classes
            and set(y[test_idx]) == all_classes
        ):
            return (
                X.loc[train_idx].reset_index(drop=True),
                X.loc[cal_idx].reset_index(drop=True),
                X.iloc[test_idx].reset_index(drop=True),
                y[train_idx],
                y[cal_idx],
                y[test_idx],
            )

    raise RuntimeError(
        "Unable to create a grouped train/calibration/test split with all "
        "classes represented. Increase samples_per_class."
    )


def make_pipeline(params: dict[str, Any], seed: int) -> Pipeline:
    # RandomForest does not require scaling, so the spec's "scaling only if
    # required" rule means no scaler is inserted here.
    rf = RandomForestClassifier(
        n_estimators=int(params["n_estimators"]),
        max_depth=params["max_depth"],
        min_samples_leaf=int(params["min_samples_leaf"]),
        max_features=params["max_features"],
        class_weight="balanced_subsample",
        random_state=seed,
        n_jobs=-1,
    )
    return Pipeline(
        [
            ("feature_validation", FeatureSchemaValidator(list(FEATURE_COLUMNS))),
            ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
            ("classifier", rf),
        ]
    )


def choose_params(seed: int) -> list[dict[str, Any]]:
    space = {
        "n_estimators": [180, 260, 340],
        "max_depth": [None, 12, 20, 30],
        "min_samples_leaf": [1, 2, 4],
        "max_features": ["sqrt", "log2", 0.7],
    }
    return list(ParameterSampler(space, n_iter=5, random_state=seed))


def _calibrated_model(base: Pipeline, X_cal: pd.DataFrame, y_cal: np.ndarray):
    if FrozenEstimator is not None:
        # scikit-learn 1.8+: FrozenEstimator prevents refitting. A single
        # self-prediction fold uses the disjoint calibration set only to fit
        # the sigmoid calibrator; the RF was already fitted on X_train.
        frozen = FrozenEstimator(base)
        idx = np.arange(len(X_cal))
        calibrator = CalibratedClassifierCV(
            estimator=frozen,
            method="sigmoid",
            cv=[(idx, idx)],
            ensemble=False,
        )
    else:
        # Compatibility fallback for older scikit-learn versions.
        calibrator = CalibratedClassifierCV(
            estimator=base,
            method="sigmoid",
            cv="prefit",
        )
    calibrator.fit(X_cal, y_cal)
    return calibrator


def _choose_unknown_threshold(
    y_true: np.ndarray,
    probabilities: np.ndarray,
    classes: np.ndarray,
) -> float:
    """Choose threshold on calibration data using coverage × macro-F1.

    Unknown is a deployment abstention state, not a training label. The selected
    threshold is therefore learned only from held-out calibration data.
    """
    best = (0.0, 0.50)
    for threshold in np.linspace(0.20, 0.90, 71):
        confidence = probabilities.max(axis=1)
        known_mask = confidence >= threshold
        coverage = float(known_mask.mean())
        if known_mask.sum() < len(np.unique(y_true)) * 2:
            continue
        pred = classes[np.argmax(probabilities, axis=1)]
        score = f1_score(
            y_true[known_mask],
            pred[known_mask],
            labels=classes,
            average="macro",
            zero_division=0,
        )
        objective = score * coverage
        if objective > best[0]:
            best = (objective, float(threshold))
    return float(best[1])


def _brier_multiclass(y_true: np.ndarray, probabilities: np.ndarray, classes: np.ndarray) -> float:
    """Multiclass Brier score, averaged over class indicators."""
    y_onehot = np.zeros_like(probabilities, dtype=float)
    class_to_idx = {str(c): i for i, c in enumerate(classes)}
    for i, label in enumerate(y_true):
        y_onehot[i, class_to_idx[str(label)]] = 1.0
    return float(np.mean(np.sum((probabilities - y_onehot) ** 2, axis=1)))


def _evaluate(
    model,
    ood_detector,
    ood_threshold: float,
    X: pd.DataFrame,
    y: np.ndarray,
    unknown_threshold: float,
) -> dict[str, Any]:
    probabilities = np.asarray(model.predict_proba(X), dtype=float)
    classes = np.asarray(model.classes_)
    predictions = classes[np.argmax(probabilities, axis=1)]
    confidence = probabilities.max(axis=1)

    estimator = getattr(model, "estimator", None)
    if estimator is None:
        estimator = getattr(model, "estimator_", None)
    transformed = estimator[:-1].transform(X)
    ood_scores = np.asarray(ood_detector.decision_function(transformed))
    ood_mask = ood_scores < ood_threshold
    low_conf_mask = confidence < unknown_threshold
    unknown_mask = ood_mask | low_conf_mask

    final_predictions = predictions.astype(object)
    final_predictions[unknown_mask] = "UNKNOWN"

    precision, recall, f1, support = precision_recall_fscore_support(
        y, predictions, labels=classes, zero_division=0
    )
    cm = confusion_matrix(y, predictions, labels=classes)

    return {
        "macro_f1": float(f1_score(y, predictions, labels=classes, average="macro")),
        "accuracy": float(accuracy_score(y, predictions)),
        "brier_score": _brier_multiclass(y, probabilities, classes),
        "per_class": {
            str(c): {
                "precision": float(p),
                "recall": float(r),
                "f1": float(f),
                "support": int(s),
            }
            for c, p, r, f, s in zip(classes, precision, recall, f1, support)
        },
        "confusion_matrix": cm.tolist(),
        "confusion_labels": [str(c) for c in classes],
        "ood_rate": float(ood_mask.mean()),
        "low_confidence_rate": float(low_conf_mask.mean()),
        "unknown_rate": float(unknown_mask.mean()),
        "known_coverage_after_unknown": float((~unknown_mask).mean()),
        "confidence_mean": float(confidence.mean()),
        "confidence_p05": float(np.quantile(confidence, 0.05)),
        "confidence_p50": float(np.quantile(confidence, 0.50)),
        "confidence_p95": float(np.quantile(confidence, 0.95)),
        "threshold": float(unknown_threshold),
    }


def _train_one_seed(
    X: pd.DataFrame,
    y: np.ndarray,
    groups: np.ndarray,
    seed: int,
    *,
    samples_per_class: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    X_train, X_cal, X_test, y_train, y_cal, y_test = group_split(X, y, groups, seed)

    best_model = None
    best_params = None
    best_score = -np.inf

    for params in choose_params(seed):
        candidate = make_pipeline(params, seed)
        candidate.fit(X_train, y_train)
        p = candidate.predict_proba(X_cal)
        pred = candidate.classes_[np.argmax(p, axis=1)]
        score = f1_score(y_cal, pred, average="macro")
        if score > best_score:
            best_score = score
            best_model = candidate
            best_params = params

    assert best_model is not None

    calibrated = _calibrated_model(best_model, X_cal, y_cal)

    # OOD model is fit only on train features, not calibration/test data.
    transformed_train = best_model[:-1].transform(X_train)
    ood = IsolationForest(
        n_estimators=300,
        contamination=0.03,
        random_state=seed,
        n_jobs=-1,
    )
    ood.fit(transformed_train)
    train_scores = ood.decision_function(transformed_train)
    ood_threshold = float(np.quantile(train_scores, 0.03))

    cal_probs = calibrated.predict_proba(X_cal)
    unknown_threshold = _choose_unknown_threshold(
        y_cal, cal_probs, np.asarray(calibrated.classes_)
    )

    metrics = _evaluate(
        calibrated,
        ood,
        ood_threshold,
        X_test,
        y_test,
        unknown_threshold,
    )
    metrics.update(
        {
            "seed": seed,
            "best_params": best_params,
            "calibration_samples": int(len(X_cal)),
            "train_samples": int(len(X_train)),
            "test_samples": int(len(X_test)),
            "group_counts": {
                "train": int(pd.Series(groups).iloc[X.index.isin(X_train.index)].nunique()),
                "calibration": int(pd.Series(groups).iloc[X.index.isin(X_cal.index)].nunique()),
                "test": int(pd.Series(groups).iloc[X.index.isin(X_test.index)].nunique()),
            },
        }
    )
    return (
        {
            "model": calibrated,
            "base_model": best_model,
            "ood_detector": ood,
            "ood_threshold": ood_threshold,
            "unknown_threshold": unknown_threshold,
            "best_params": best_params,
        },
        metrics,
    )


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def load_config(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    try:
        import yaml
    except ImportError as exc:
        raise RuntimeError(
            "PyYAML is required when using --config. Install pyyaml or omit --config."
        ) from exc
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def train_and_export(
    *,
    artifact_dir: str | Path = "artifacts/classifier/v1",
    seed: int = 42,
    seeds: list[int] | None = None,
    samples_per_class: int = 220,
    xgboost_enabled: bool = False,
) -> dict[str, Any]:
    """Train multiple seeded datasets, choose the reproducible best model, export artifacts."""
    seeds = seeds or [seed, seed + 7, seed + 19]

    seed_results: list[dict[str, Any]] = []
    best_bundle = None
    best_metric = -np.inf

    for current_seed in seeds:
        _seed_everything(current_seed)
        X, y, groups = generate_dataset(
            seed=current_seed,
            samples_per_class=samples_per_class,
        )
        bundle, metrics = _train_one_seed(
            X, y, groups, current_seed, samples_per_class=samples_per_class
        )
        seed_results.append(metrics)

        if metrics["macro_f1"] > best_metric:
            best_metric = metrics["macro_f1"]
            best_bundle = bundle

    assert best_bundle is not None

    # Optional XGBoost is deliberately opt-in: RF remains the deterministic baseline.
    xgb_status = {
        "installed": XGBClassifier is not None,
        "enabled": bool(xgboost_enabled and XGBClassifier is not None),
        "used_for_primary_artifact": False,
    }

    artifact_dir = Path(artifact_dir)
    artifact_dir.mkdir(parents=True, exist_ok=True)

    model_artifact = {
        "model_version": MODEL_VERSION,
        "dataset_generator_version": DATASET_GENERATOR_VERSION,
        "feature_schema_version": FEATURE_SCHEMA_VERSION,
        "feature_columns": list(FEATURE_COLUMNS),
        "class_ids": list(CLASS_IDS),
        "service_categories": dict(SERVICE_CATEGORIES),
        "model": best_bundle["model"],
        "base_model": best_bundle["base_model"],
        "ood_detector": best_bundle["ood_detector"],
        "ood_threshold": best_bundle["ood_threshold"],
        "unknown_threshold": best_bundle["unknown_threshold"],
        "seed": int(seed),
        "training_seeds": [int(s) for s in seeds],
        "synthetic_to_real_warning": (
            "TRAINED AND EVALUATED ON SYNTHETIC FLOW METADATA. "
            "Performance does not establish generalization to real encrypted traffic "
            "or real application identification. Real-world deployment requires "
            "authorized telemetry, external validation and drift monitoring."
        ),
    }

    model_path = artifact_dir / "model.joblib"
    joblib.dump(model_artifact, model_path)

    report = {
        "model_version": MODEL_VERSION,
        "dataset_generator_version": DATASET_GENERATOR_VERSION,
        "feature_schema_version": FEATURE_SCHEMA_VERSION,
        "feature_columns": list(FEATURE_COLUMNS),
        "class_ids": list(CLASS_IDS),
        "training_seeds": [int(s) for s in seeds],
        "best_seed": int(seed),
        "best_test_macro_f1": float(best_metric),
        "seed_evaluations": seed_results,
        "xgboost": xgb_status,
        "split_strategy": (
            "Grouped train/calibration/test split by synthetic session/scenario. "
            "Adjacent ticks from the same session cannot cross partitions."
        ),
        "metrics": [
            "macro_f1",
            "per_class_precision_recall_f1",
            "confusion_matrix",
            "multiclass_brier_score",
            "ood_rate",
            "low_confidence_rate",
            "unknown_rate",
        ],
        "unknown_threshold": float(best_bundle["unknown_threshold"]),
        "ood_threshold": float(best_bundle["ood_threshold"]),
        "provenance": {
            "python": sys.version,
            "platform": platform.platform(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scikit_learn": __import__("sklearn").__version__,
            "created_utc": datetime.now(timezone.utc).isoformat(),
        },
        "synthetic_to_real_warning": model_artifact["synthetic_to_real_warning"],
    }
    metrics_path = artifact_dir / "metrics.json"
    _write_json(metrics_path, report)

    return {
        "model_path": str(model_path),
        "metrics_path": str(metrics_path),
        "best_seed": int(seed),
        "best_macro_f1": float(best_metric),
        "unknown_threshold": float(best_bundle["unknown_threshold"]),
        "ood_threshold": float(best_bundle["ood_threshold"]),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default=None)
    parser.add_argument("--artifact-dir", type=str, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--samples-per-class", type=int, default=None)
    args = parser.parse_args()

    config = load_config(args.config)
    ml_cfg = config.get("classifier", config.get("ml", config))

    seed = args.seed if args.seed is not None else int(ml_cfg.get("seed", 42))
    samples = (
        args.samples_per_class
        if args.samples_per_class is not None
        else int(ml_cfg.get("samples_per_class", 220))
    )
    artifact_dir = args.artifact_dir or ml_cfg.get(
        "artifact_dir", "artifacts/classifier/v1"
    )
    seeds = ml_cfg.get("seeds", [seed, seed + 7, seed + 19])

    result = train_and_export(
        artifact_dir=artifact_dir,
        seed=seed,
        seeds=[int(s) for s in seeds],
        samples_per_class=samples,
        xgboost_enabled=bool(ml_cfg.get("xgboost_enabled", False)),
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
