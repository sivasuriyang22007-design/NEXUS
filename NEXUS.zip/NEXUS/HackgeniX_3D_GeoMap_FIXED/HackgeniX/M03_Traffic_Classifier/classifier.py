"""
NEXUS M03 - Traffic classifier inference.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import joblib
import numpy as np
import pandas as pd

try:
    from .feature_extractor import (
        FEATURE_COLUMNS,
        validate_feature_frame,
    )
except ImportError:
    from feature_extractor import (
        FEATURE_COLUMNS,
        validate_feature_frame,
    )


UNKNOWN_CLASS_ID = "UNKNOWN"


SERVICE_CATEGORIES = {

    "01_reels": "VIDEO_STREAMING",
    "02_video_480p": "VIDEO_STREAMING",
    "03_video_1080p": "VIDEO_STREAMING",
    "04_video_4k": "VIDEO_STREAMING",

    "05_ott": "VIDEO_STREAMING",
    "06_live_stream": "VIDEO_STREAMING",

    "07_video_call": "REAL_TIME_COMMUNICATION",
    "08_voice_call": "REAL_TIME_COMMUNICATION",

    "09_messaging": "INTERACTIVE",
    "10_browsing": "INTERACTIVE",
    "11_online_gaming": "INTERACTIVE",

    "12_cloud_gaming": "REAL_TIME_INTERACTIVE",
    "13_ar_vr": "REAL_TIME_INTERACTIVE",
    "14_remote_desktop": "REAL_TIME_INTERACTIVE",

    "15_online_exam": "INTERACTIVE_CRITICAL",

    "16_file_download": "ELASTIC_TRANSFER",
    "17_backup": "BACKGROUND_TRANSFER",
    "18_software_update": "BACKGROUND_TRANSFER",
    "19_p2p": "BACKGROUND_TRANSFER",
    "20_upload": "ELASTIC_TRANSFER",

    "21_emergency": "AUTHORIZED_PRIORITY",
    "22_disaster_stream": "AUTHORIZED_PRIORITY",
    "23_medical_telemetry": "AUTHORIZED_PRIORITY",

    "24_public_broadcast": "EVENT_BROADCAST",
    "25_operator_control": "CONTROL_PLANE",
}


@dataclass(frozen=True)
class ClassPrediction:

    class_id: str
    confidence: float
    top_k: list[dict[str, float | str]]
    service_category: str


class TrafficClassifier:

    def __init__(
        self,
        artifact: Mapping[str, Any]
    ):

        self.artifact = dict(
            artifact
        )

        self.model = self.artifact["model"]

        self.ood_detector = (
            self.artifact.get(
                "ood_detector"
            )
        )

        self.ood_threshold = float(
            self.artifact.get(
                "ood_threshold",
                -np.inf
            )
        )

        self.unknown_threshold = float(
            self.artifact.get(
                "unknown_threshold",
                0.5
            )
        )

        self.feature_columns = list(
            self.artifact.get(
                "feature_columns",
                FEATURE_COLUMNS
            )
        )

        self.class_ids = list(
            self.artifact[
                "class_ids"
            ]
        )

        self.service_categories = dict(
            self.artifact.get(
                "service_categories",
                SERVICE_CATEGORIES
            )
        )

        self.version = str(
            self.artifact.get(
                "model_version",
                "v1"
            )
        )

    @classmethod
    def load(
        cls,
        path: str | Path
    ) -> "TrafficClassifier":

        return cls(
            joblib.load(path)
        )

    def _ordered(
        self,
        feature_batch
    ) -> pd.DataFrame:

        return validate_feature_frame(
            feature_batch,
            required_columns=self.feature_columns,
            allow_extra=False,
        )

    def _ood_scores(
        self,
        x: pd.DataFrame
    ) -> np.ndarray:

        if self.ood_detector is None:
            return np.full(
                len(x),
                np.inf,
                dtype=float
            )

        estimator = getattr(
            self.model,
            "estimator",
            None
        )

        if estimator is None:
            estimator = getattr(
                self.model,
                "estimator_",
                None
            )

        if estimator is None:
            raise RuntimeError(
                "Persisted calibrated model "
                "has no base estimator."
            )

        # Apply feature validation + imputation,
        # but not the RandomForest itself.
        transformed = (
            estimator[:-1]
            .transform(x)
        )

        return np.asarray(
            self.ood_detector
            .decision_function(
                transformed
            ),
            dtype=float,
        )

    def predict_classes(
        self,
        feature_batch,
        *,
        top_k: int = 3
    ) -> list[dict[str, Any]]:

        if top_k < 1:
            raise ValueError(
                "top_k must be >= 1"
            )

        x = self._ordered(
            feature_batch
        )

        probabilities = np.asarray(
            self.model.predict_proba(x),
            dtype=float
        )

        # Numerical normalization.
        row_sums = probabilities.sum(
            axis=1,
            keepdims=True
        )

        probabilities = np.divide(
            probabilities,
            np.where(
                row_sums == 0,
                1.0,
                row_sums
            )
        )

        classes = list(
            self.model.classes_
        )

        ood_scores = (
            self._ood_scores(x)
        )

        results = []

        for i, row in enumerate(
            probabilities
        ):

            order = np.argsort(
                row
            )[::-1]

            best_idx = int(
                order[0]
            )

            confidence = float(
                row[best_idx]
            )

            is_ood = bool(
                ood_scores[i]
                < self.ood_threshold
            )

            is_low_conf = (
                confidence
                < self.unknown_threshold
            )

            if is_ood or is_low_conf:

                class_id = (
                    UNKNOWN_CLASS_ID
                )

                category = (
                    self._fallback_category(
                        row,
                        classes
                    )
                )

            else:

                class_id = str(
                    classes[best_idx]
                )

                category = (
                    self.service_categories
                    .get(
                        class_id,
                        "UNKNOWN_SERVICE"
                    )
                )

            ranked = [

                {
                    "class_id":
                        str(classes[int(j)]),

                    "probability":
                        float(row[int(j)]),
                }

                for j in order[:top_k]
            ]

            results.append(
                {
                    "class_id":
                        class_id,

                    "confidence":
                        confidence,

                    "top_k":
                        ranked,

                    "service_category":
                        category,

                    "ood":
                        is_ood,

                    "low_confidence":
                        is_low_conf,

                    "model_version":
                        self.version,
                }
            )

        return results

    def _fallback_category(
        self,
        probabilities: np.ndarray,
        classes: Sequence[str]
    ) -> str:

        category_scores = {}

        for class_id, probability in zip(
            classes,
            probabilities
        ):

            category = (
                self.service_categories
                .get(
                    str(class_id),
                    "UNKNOWN_SERVICE"
                )
            )

            category_scores[category] = (
                category_scores.get(
                    category,
                    0.0
                )
                + float(probability)
            )

        if not category_scores:
            return "UNKNOWN_SERVICE"

        return max(
            category_scores.items(),
            key=lambda item: item[1]
        )[0]


def predict_classes(
    feature_batch,
    *,
    artifact_path:
        str | Path =
        "artifacts/classifier/v1/model.joblib",
    top_k: int = 3,
):

    classifier = (
        TrafficClassifier.load(
            artifact_path
        )
    )

    return classifier.predict_classes(
        feature_batch,
        top_k=top_k
    )