def reserve_minimums(groups, capacity):
    """
    Reserve policy-authorized minimum service.
    """

    minimum_total = sum(
        group["min_service"] for group in groups
    )

    if minimum_total <= capacity:
        return {
            "feasible": True,
            "allocation": {
                group["name"]: group["min_service"]
                for group in groups
            },
            "remaining": capacity - minimum_total
        }

    # Minimum guarantees cannot all fit.
    return {
        "feasible": False,
        "allocation": {},
        "remaining": capacity,
        "required": minimum_total
    }


def calculate_priority(group):
    """
    Calculate heuristic priority.

    Higher priority means the group receives
    more of the remaining capacity.
    """

    return (
        group["weight"]
        * group["urgency"]
        * group["queue_age"]
        * group["forecast_risk"]
    )


def allocate_remaining_capacity(groups, allocation, remaining):
    """
    Weighted proportional allocation.
    """

    scores = {}

    for group in groups:
        scores[group["name"]] = calculate_priority(group)

    total_score = sum(scores.values())

    if total_score <= 0:
        return allocation

    for group in groups:

        name = group["name"]

        share = (
            remaining
            * scores[name]
            / total_score
        )

        allocation[name] += share

    return allocation


def apply_quotas(groups, allocation):
    """
    Make sure no group exceeds its maximum quota.
    """

    for group in groups:

        name = group["name"]

        if allocation[name] > group["max_service"]:
            allocation[name] = group["max_service"]

        if allocation[name] < 0:
            allocation[name] = 0

    return allocation


def apply_starvation_protection(groups, allocation):
    """
    Give additional attention to groups that have
    waited for a long time.
    """

    for group in groups:

        name = group["name"]

        if group["starvation_counter"] >= 5:

            bonus = min(
                5.0,
                group["demand"] - allocation[name]
            )

            if bonus > 0:
                allocation[name] += bonus

    return allocation


def smooth_allocation(previous, current, max_change=20.0):
    """
    Prevent sudden allocation oscillations.
    """

    if previous is None:
        return current

    result = {}

    for name in current:

        old_value = previous.get(name, 0.0)
        new_value = current[name]

        difference = new_value - old_value

        if difference > max_change:
            new_value = old_value + max_change

        elif difference < -max_change:
            new_value = old_value - max_change

        result[name] = max(0.0, new_value)

    return result


def project_to_constraints(
    allocation,
    groups,
    capacity,
    previous=None
):
    """
    Deterministic constraint projector.

    PPO or any other AI proposal must pass through
    this function before becoming a final allocation.
    """

    # 1. Non-negative allocation
    for name in allocation:
        allocation[name] = max(0.0, allocation[name])

    # 2. Maximum quotas
    allocation = apply_quotas(
        groups,
        allocation
    )

    # 3. Rate-limit sudden changes
    allocation = smooth_allocation(
        previous,
        allocation
    )

    # 4. Capacity constraint
    total = sum(allocation.values())

    if total > capacity:

        scale = capacity / total

        for name in allocation:
            allocation[name] *= scale

    # 5. Final non-negative check
    for name in allocation:
        allocation[name] = max(
            0.0,
            allocation[name]
        )

    return allocation