"""
M07_QoE_Monitor - metrics_collector.py

Central metric aggregation, distribution, SLA denominator, starvation,
backlog, demand-shedding, confidence-interval and data-quality utilities.

Standard library only.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from math import sqrt
from statistics import mean, pstdev
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence


METRIC_SCHEMA_VERSION = "7.1"
METRIC_FORMULA_VERSION = "qoe-metrics-1.0"


def percentile(values: Sequence[float], p: float) -> float:
    """Linear-interpolated percentile. p is in [0, 100]."""
    if not values:
        return 0.0
    xs = sorted(float(x) for x in values)
    if len(xs) == 1:
        return xs[0]
    p = max(0.0, min(100.0, float(p)))
    rank = (len(xs) - 1) * p / 100.0
    lo = int(rank)
    hi = min(lo + 1, len(xs) - 1)
    frac = rank - lo
    return xs[lo] + (xs[hi] - xs[lo]) * frac


def confidence_interval_mean(
    values: Sequence[float],
    z: float = 1.96,
) -> tuple[float, float]:
    """Approximate two-sided CI for a mean using a normal critical value."""
    xs = [float(x) for x in values]
    if not xs:
        return (0.0, 0.0)
    if len(xs) == 1:
        return (xs[0], xs[0])
    m = mean(xs)
    se = pstdev(xs) / sqrt(len(xs))
    return (m - z * se, m + z * se)


def jain_index(values: Sequence[float], eps: float = 1e-12) -> float:
    """Jain fairness index."""
    xs = [max(0.0, float(x)) for x in values]
    if not xs:
        return 1.0
    numerator = sum(xs) ** 2
    denominator = len(xs) * sum(x * x for x in xs)
    if denominator <= eps:
        return 1.0
    return numerator / denominator


@dataclass
class MetricRecord:
    timestamp: float
    user_id: str
    cell_id: str = "cell_0"
    traffic_class: str = "generic"
    active: bool = True

    latency_ms: float = 0.0
    jitter_ms: float = 0.0
    loss_fraction: float = 0.0
    delivered_mbps: float = 0.0
    offered_mbps: float = 0.0

    qoe: Optional[float] = None
    backlog_bytes: float = 0.0
    unfinished_bytes: float = 0.0
    demand_shed_bytes: float = 0.0

    deadline_met: Optional[bool] = None
    sla_violated: Optional[bool] = None

    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MetricSummary:
    count: int
    active_count: int
    mean: float
    std: float
    p50: float
    p90: float
    p95: float
    p99: float
    min: float
    max: float
    confidence_interval_95: tuple[float, float]


class MetricsCollector:
    """
    Central collector.

    The collector keeps inactive sessions out of SLA/QoE denominators by
    default. Raw records are retained so distributions are available rather
    than only network-wide averages.
    """

    def __init__(self, metric_formula_version: str = METRIC_FORMULA_VERSION):
        self.metric_formula_version = metric_formula_version
        self.schema_version = METRIC_SCHEMA_VERSION
        self.records: List[MetricRecord] = []
        self._last_timestamp: Dict[str, float] = {}

    def add(self, record: MetricRecord) -> None:
        if record.timestamp < self._last_timestamp.get(record.user_id, float("-inf")):
            record.metadata["late_event"] = True
        else:
            record.metadata.setdefault("late_event", False)
        self._last_timestamp[record.user_id] = max(
            record.timestamp, self._last_timestamp.get(record.user_id, record.timestamp)
        )
        self.records.append(record)

    def add_many(self, records: Iterable[MetricRecord]) -> None:
        for record in records:
            self.add(record)

    def _active(self, records: Optional[Iterable[MetricRecord]] = None) -> List[MetricRecord]:
        rows = list(self.records if records is None else records)
        return [r for r in rows if r.active]

    def summarize(
        self,
        metric: str,
        records: Optional[Iterable[MetricRecord]] = None,
        active_only: bool = True,
    ) -> MetricSummary:
        rows = self._active(records) if active_only else list(
            self.records if records is None else records
        )
        values = [float(getattr(r, metric)) for r in rows if getattr(r, metric, None) is not None]
        if not values:
            return MetricSummary(0, len(rows), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                 0.0, 0.0, (0.0, 0.0))
        return MetricSummary(
            count=len(values),
            active_count=len(rows),
            mean=mean(values),
            std=pstdev(values) if len(values) > 1 else 0.0,
            p50=percentile(values, 50),
            p90=percentile(values, 90),
            p95=percentile(values, 95),
            p99=percentile(values, 99),
            min=min(values),
            max=max(values),
            confidence_interval_95=confidence_interval_mean(values),
        )

    def group_summary(
        self,
        metric: str,
        group_by: str = "traffic_class",
    ) -> Dict[str, MetricSummary]:
        groups: Dict[str, List[MetricRecord]] = {}
        for row in self._active():
            key = str(getattr(row, group_by, "unknown"))
            groups.setdefault(key, []).append(row)
        return {key: self.summarize(metric, rows) for key, rows in groups.items()}

    def sla_rate(
        self,
        records: Optional[Iterable[MetricRecord]] = None,
    ) -> float:
        rows = self._active(records)
        evaluated = [r for r in rows if r.sla_violated is not None]
        if not evaluated:
            return 1.0
        return 1.0 - sum(bool(r.sla_violated) for r in evaluated) / len(evaluated)

    def starvation_events(
        self,
        minimum_rate_mbps: float,
        consecutive_ticks: int = 3,
    ) -> List[Dict[str, Any]]:
        """Detect active users receiving less than minimum for N consecutive ticks."""
        by_user: Dict[str, List[MetricRecord]] = {}
        for row in self.records:
            if row.active:
                by_user.setdefault(row.user_id, []).append(row)

        events: List[Dict[str, Any]] = []
        for user_id, rows in by_user.items():
            rows.sort(key=lambda r: r.timestamp)
            run = []
            for row in rows:
                if row.delivered_mbps < minimum_rate_mbps and row.backlog_bytes > 0:
                    run.append(row)
                else:
                    if len(run) >= consecutive_ticks:
                        events.append(self._starvation_event(user_id, run))
                    run = []
            if len(run) >= consecutive_ticks:
                events.append(self._starvation_event(user_id, run))
        return events

    @staticmethod
    def _starvation_event(user_id: str, rows: Sequence[MetricRecord]) -> Dict[str, Any]:
        return {
            "user_id": user_id,
            "start": rows[0].timestamp,
            "end": rows[-1].timestamp,
            "ticks": len(rows),
            "age": max(0.0, rows[-1].timestamp - rows[0].timestamp),
            "minimum_observed_mbps": min(r.delivered_mbps for r in rows),
            "backlog_bytes": max(r.backlog_bytes for r in rows),
        }

    def totals(self) -> Dict[str, float]:
        rows = self.records
        return {
            "offered_mbps_sum": sum(r.offered_mbps for r in rows),
            "delivered_mbps_sum": sum(r.delivered_mbps for r in rows),
            "backlog_bytes_max": max((r.backlog_bytes for r in rows), default=0.0),
            "unfinished_bytes_sum": sum(r.unfinished_bytes for r in rows),
            "demand_shed_bytes_sum": sum(r.demand_shed_bytes for r in rows),
        }

    def distribution(self, metric: str) -> Dict[str, float]:
        summary = self.summarize(metric)
        return {
            "mean": summary.mean,
            "std": summary.std,
            "p50": summary.p50,
            "p90": summary.p90,
            "p95": summary.p95,
            "p99": summary.p99,
            "min": summary.min,
            "max": summary.max,
            "ci95_low": summary.confidence_interval_95[0],
            "ci95_high": summary.confidence_interval_95[1],
        }

    def validate_schema(self, record: MetricRecord) -> List[str]:
        errors: List[str] = []
        if not record.user_id:
            errors.append("user_id is required")
        if record.timestamp < 0:
            errors.append("timestamp must be >= 0")
        if record.loss_fraction < 0 or record.loss_fraction > 1:
            errors.append("loss_fraction must be in [0,1]")
        for name in ("latency_ms", "jitter_ms", "delivered_mbps", "offered_mbps",
                     "backlog_bytes", "unfinished_bytes", "demand_shed_bytes"):
            if float(getattr(record, name)) < 0:
                errors.append(f"{name} must be >= 0")
        return errors

    def data_quality_report(self) -> Dict[str, Any]:
        errors = []
        late = 0
        for row in self.records:
            row_errors = self.validate_schema(row)
            if row_errors:
                errors.append({"user_id": row.user_id, "errors": row_errors})
            late += bool(row.metadata.get("late_event", False))
        return {
            "schema_version": self.schema_version,
            "formula_version": self.metric_formula_version,
            "records": len(self.records),
            "invalid_records": len(errors),
            "late_events": late,
            "duplicate_timestamps": self._duplicate_timestamp_count(),
            "errors": errors[:100],
        }

    def _duplicate_timestamp_count(self) -> int:
        seen = set()
        duplicates = 0
        for row in self.records:
            key = (row.user_id, row.timestamp)
            if key in seen:
                duplicates += 1
            seen.add(key)
        return duplicates


def aggregate_across_seeds(
    seed_summaries: Sequence[Mapping[str, float]],
    metric_key: str,
) -> Dict[str, float]:
    values = [float(s[metric_key]) for s in seed_summaries if metric_key in s]
    if not values:
        return {"mean": 0.0, "p50": 0.0, "p95": 0.0, "ci95_low": 0.0, "ci95_high": 0.0}
    ci = confidence_interval_mean(values)
    return {
        "mean": mean(values),
        "p50": percentile(values, 50),
        "p95": percentile(values, 95),
        "ci95_low": ci[0],
        "ci95_high": ci[1],
    }


if __name__ == "__main__":
    c = MetricsCollector()
    c.add(MetricRecord(0.0, "u1", latency_ms=20, qoe=0.9))
    c.add(MetricRecord(1.0, "u1", latency_ms=40, qoe=0.8))
    print("MetricsCollector self-check:", c.distribution("latency_ms"))
