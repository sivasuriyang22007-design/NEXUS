# M09 Integration & Dashboard
Additive integration layer; existing M01-M10 source files are not modified.

## Run
From `HackgeniX`:
`python integration.py`

Launch:
`python M09_Dashboard/backend/server.py`

Open `http://127.0.0.1:8080`.

## 3D User GeoMap
The dashboard includes a WebGL 3D globe with **2,500 synthetic telecom users**. Users are geographically distributed across multiple countries and rendered as clickable points. Selecting a point shows user ID, country, latitude/longitude, QoE, demand, granted bandwidth, latency, packet loss, priority, cell and status.

The 2,500-user dataset is deterministic (seed 42) and stored in `M09_Dashboard/backend/geo_users.json`. The existing M01-M10 source files and original integration logic remain unchanged.

The globe uses Three.js from a public CDN; an internet connection is required for the Three.js scripts when viewing the dashboard.
