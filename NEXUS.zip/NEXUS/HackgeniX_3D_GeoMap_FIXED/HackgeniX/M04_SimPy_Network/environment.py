# M04_SimPy_Network/environment.py

from __future__ import annotations

import simpy


class SimulationEnvironment:
    """
    Creates and manages the SimPy simulation clock.

    Modes:
        offline  -> accelerated simulation
        realtime -> wall-clock paced simulation
    """

    def __init__(
        self,
        mode: str = "offline",
        realtime_factor: float = 1.0,
        strict: bool = False,
    ):
        self.mode = mode.lower()

        if self.mode == "realtime":
            self.env = simpy.rt.RealtimeEnvironment(
                factor=realtime_factor,
                strict=strict,
            )
        else:
            self.env = simpy.Environment()

    @property
    def now(self) -> float:
        """Current simulated time in seconds."""
        return float(self.env.now)

    def timeout(self, seconds: float):
        """Create a SimPy timeout event."""
        return self.env.timeout(max(0.0, float(seconds)))

    def process(self, generator):
        """Register a SimPy process."""
        return self.env.process(generator)

    def run(self, until=None):
        """Run the simulation."""
        return self.env.run(until=until)

    def step(self):
        """Execute one SimPy event."""
        return self.env.step()