"""
M07_QoE_Monitor - throughput_monitor.py

Throughput, utilization, backlog, unfinished work and demand-shedding
monitoring. Standard library only.
"""

from __future__ import annotations

from dataclasses import dataclass
from statistics import mean, pstdev
from typing import Dict, List

from metrics_collector import percentile


@dataclass
class ThroughputSample:
    timestamp: float
    user_id: str
    offered_mbps: float
    delivered_mbps: float
    backlog_bytes: float = 0.0
    unfinished_bytes: float = 0.0
    demand_shed_bytes: float = 0.0
    active: bool = True


class ThroughputMonitor:
    def __init__(self):
        self.samples: List[ThroughputSample] = []

    def add(self, sample: ThroughputSample) -> None:
        for name in (
            "offered_mbps", "delivered_mbps", "backlog_bytes",
            "unfinished_bytes", "demand_shed_bytes"
        ):
            if float(getattr(sample, name)) < 0:
                raise ValueError(f"{name} must be non-negative")
        self.samples.append(sample)

    def add_value(
        self,
        timestamp: float,
        user_id: str,
        offered_mbps: float,
        delivered_mbps: float,
        backlog_bytes: float = 0.0,
        unfinished_bytes: float = 0.0,
        demand_shed_bytes: float = 0.0,
        active: bool = True,
    ) -> ThroughputSample:
        sample = ThroughputSample(
            timestamp, user_id, offered_mbps, delivered_mbps,
            backlog_bytes, unfinished_bytes, demand_shed_bytes, active
        )
        self.add(sample)
        return sample

    def delivered(self) -> List[float]:
        return [s.delivered_mbps for s in self.samples if s.active]

    def summary(self) -> Dict[str, float]:
        xs = self.delivered()
        offered = [s.offered_mbps for s in self.samples if s.active]
        if not xs:
            return {k: 0.0 for k in (
                "mean", "std", "p50", "p95", "max", "min",
                "utilization", "throughput_variability",
                "backlog_bytes", "unfinished_bytes",
                "demand_shed_bytes", "completion_ratio"
            )}

        total_offered = sum(offered)
        total_delivered = sum(xs)
        total_unfinished = sum(s.unfinished_bytes for s in self.samples if s.active)
        return {
            "mean": mean(xs),
            "std": pstdev(xs) if len(xs) > 1 else 0.0,
            "p50": percentile(xs, 50),
            "p95": percentile(xs, 95),
            "max": max(xs),
            "min": min(xs),
            "utilization": total_delivered / max(total_offered, 1e-12),
            "throughput_variability": (
                pstdev(xs) / max(mean(xs), 1e-12) if len(xs) > 1 else 0.0
            ),
            "backlog_bytes": sum(s.backlog_bytes for s in self.samples if s.active),
            "unfinished_bytes": total_unfinished,
            "demand_shed_bytes": sum(
                s.demand_shed_bytes for s in self.samples if s.active
            ),
            "completion_ratio": total_delivered / max(total_delivered + total_unfinished, 1e-12),
        }

    def temporal_features(self, window: int = 5) -> Dict[str, float]:
        xs = self.delivered()
        tail = xs[-max(1, window):]
        if not tail:
            return {
                "rolling_throughput": 0.0,
                "throughput_trend": 0.0,
                "throughput_drop_rate": 0.0,
                "throughput_volatility": 0.0,
                "backlog_growth": 0.0,
                "demand_shed_rate": 0.0,
            }

        trend = 0.0
        if len(tail) >= 2:
            trend = (tail[-1] - tail[0]) / (len(tail) - 1)

        drops = 0
        for a, b in zip(tail, tail[1:]):
            if b < a:
                drops += 1

        rows = self.samples[-len(tail):]
        backlog_growth = 0.0
        if len(rows) >= 2:
            backlog_growth = rows[-1].backlog_bytes - rows[0].backlog_bytes

        offered = sum(r.offered_mbps for r in rows)
        shed = sum(r.demand_shed_bytes for r in rows)

        return {
            "rolling_throughput": mean(tail),
            "throughput_trend": trend,
            "throughput_drop_rate": drops / max(len(tail) - 1, 1),
            "throughput_volatility": pstdev(tail) if len(tail) > 1 else 0.0,
            "backlog_growth": backlog_growth,
            "demand_shed_rate": shed / max(offered, 1e-12),
        }

    def satisfaction(self, target_mbps: float, eps: float = 1e-12) -> float:
        """Configured target is an evaluation/QoE value, not an observer feature."""
        delivered = mean(self.delivered()) if self.delivered() else 0.0
        return max(0.0, min(1.0, delivered / max(target_mbps, eps)))


if __name__ == "__main__":
    m = ThroughputMonitor()
    for i, value in enumerate((5, 7, 6, 3, 4)):
        m.add_value(i, "u1", 8, value, backlog_bytes=max(0, 100 - i * 10))
    print("ThroughputMonitor self-check:", m.summary())
