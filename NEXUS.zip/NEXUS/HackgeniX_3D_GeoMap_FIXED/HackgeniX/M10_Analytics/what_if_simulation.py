"""Isolated what-if scenario cloning and deterministic perturbations."""
from __future__ import annotations

from dataclasses import replace
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from M10_Analytics.comparison import TickInput, compare_policies


@dataclass(frozen=True)
class WhatIfConfig:
    users_multiplier: float = 1.0
    arrivals_multiplier: float = 1.0
    event_duration_ticks: int = 0
    capacity_multiplier: float = 1.0
    forced_failure_cells: tuple[str, ...] = ()
    policy_toggles: dict[str, Any] | None = None
    seed: int = 42


def clone_trace(trace: Sequence[TickInput]) -> list[TickInput]:
    """Deep clone so a what-if cannot mutate live simulation state."""
    return deepcopy(list(trace))


def apply_what_if(trace: Sequence[TickInput], config: WhatIfConfig) -> list[TickInput]:
    if config.users_multiplier < 0 or config.arrivals_multiplier < 0 or config.capacity_multiplier < 0:
        raise ValueError("Multipliers cannot be negative")
    cloned = clone_trace(trace)
    affected = set(config.forced_failure_cells)
    out = []

    for x in cloned:
        demands = {
            k: max(0.0, v * config.arrivals_multiplier)
            for k, v in x.demands_mbps.items()
        }

        # Event duration is represented as an explicit demand multiplier window.
        if config.event_duration_ticks > 0 and x.tick < config.event_duration_ticks:
            demands = {k: v * config.users_multiplier for k, v in demands.items()}

        capacity = x.capacity_mbps * config.capacity_multiplier
        if x.cell_id in affected:
            capacity = 0.0

        state = deepcopy(x.state)
        state["what_if"] = True
        state["what_if_config"] = {
            "users_multiplier": config.users_multiplier,
            "arrivals_multiplier": config.arrivals_multiplier,
            "event_duration_ticks": config.event_duration_ticks,
            "capacity_multiplier": config.capacity_multiplier,
            "forced_failure_cells": sorted(affected),
            "policy_toggles": config.policy_toggles or {},
        }
        out.append(
            TickInput(
                tick=x.tick,
                cell_id=x.cell_id,
                capacity_mbps=max(0.0, capacity),
                demands_mbps=demands,
                state=state,
            )
        )
    return out


def run_what_if(
    trace: Sequence[TickInput],
    config: WhatIfConfig,
    policies: Sequence[str] = ("fixed_equal", "round_robin", "weighted_fair", "static_qos"),
) -> dict[str, Any]:
    scenario_trace = apply_what_if(trace, config)
    result = compare_policies(scenario_trace, policies=policies, seed=config.seed)
    result["scenario"] = {
        "type": "what_if",
        "isolated_clone": True,
        "config": {
            "users_multiplier": config.users_multiplier,
            "arrivals_multiplier": config.arrivals_multiplier,
            "event_duration_ticks": config.event_duration_ticks,
            "capacity_multiplier": config.capacity_multiplier,
            "forced_failure_cells": list(config.forced_failure_cells),
            "policy_toggles": config.policy_toggles or {},
            "seed": config.seed,
        },
    }
    return result
