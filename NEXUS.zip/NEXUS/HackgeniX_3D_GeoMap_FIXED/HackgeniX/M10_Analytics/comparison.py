"""Paired policy comparison on identical workload traces/seeds."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping, Sequence
import math
import statistics
import random

from M10_Analytics.baseline_schedulers import allocate, AllocationResult


@dataclass(frozen=True)
class TickInput:
    tick: int
    cell_id: str
    capacity_mbps: float
    demands_mbps: dict[str, float]
    state: dict[str, Any]


@dataclass
class TickOutcome:
    policy: str
    tick: int
    cell_id: str
    capacity_mbps: float
    offered_mbps: float
    granted_mbps: float
    unsatisfied_mbps: float
    grants_mbps: dict[str, float]


def run_policy(policy: str, trace: Sequence[TickInput]) -> list[TickOutcome]:
    outcomes = []
    for x in trace:
        result = allocate(policy, x.demands_mbps, x.capacity_mbps, x.state)
        offered = sum(x.demands_mbps.values())
        granted = sum(result.grants_mbps.values())
        outcomes.append(
            TickOutcome(
                policy=policy,
                tick=x.tick,
                cell_id=x.cell_id,
                capacity_mbps=x.capacity_mbps,
                offered_mbps=offered,
                granted_mbps=granted,
                unsatisfied_mbps=max(0.0, offered - granted),
                grants_mbps=result.grants_mbps,
            )
        )
    return outcomes


def jain_fairness(values: Sequence[float]) -> float:
    xs = [max(0.0, float(x)) for x in values]
    if not xs or sum(x * x for x in xs) <= 0:
        return 1.0
    return (sum(xs) ** 2) / (len(xs) * sum(x * x for x in xs))


def _bootstrap_mean_ci(values: Sequence[float], seed: int = 42, samples: int = 1000) -> tuple[float, float]:
    xs = [float(x) for x in values if math.isfinite(float(x))]
    if not xs:
        return (float("nan"), float("nan"))
    if len(xs) == 1:
        return (xs[0], xs[0])
    rng = random.Random(seed)
    means = []
    for _ in range(samples):
        draw = [xs[rng.randrange(len(xs))] for _ in xs]
        means.append(statistics.fmean(draw))
    means.sort()
    lo = means[max(0, int(0.025 * len(means)) - 1)]
    hi = means[min(len(means) - 1, int(0.975 * len(means)))]
    return lo, hi


def summarize_outcomes(outcomes: Sequence[TickOutcome], seed: int = 42) -> dict[str, Any]:
    if not outcomes:
        return {}
    throughput = [x.granted_mbps for x in outcomes]
    utilization = [
        x.granted_mbps / x.capacity_mbps if x.capacity_mbps > 0 else 0.0
        for x in outcomes
    ]
    unsatisfied = [x.unsatisfied_mbps for x in outcomes]
    fairness_by_tick = [jain_fairness(list(x.grants_mbps.values())) for x in outcomes]
    ci_lo, ci_hi = _bootstrap_mean_ci(throughput, seed=seed)

    return {
        "policy": outcomes[0].policy,
        "ticks": len(outcomes),
        "mean_offered_mbps": statistics.fmean(x.offered_mbps for x in outcomes),
        "mean_granted_mbps": statistics.fmean(throughput),
        "mean_utilization": statistics.fmean(utilization),
        "p95_granted_mbps": _percentile(throughput, 95),
        "mean_unsatisfied_mbps": statistics.fmean(unsatisfied),
        "mean_jain_fairness": statistics.fmean(fairness_by_tick),
        "throughput_mean_ci95": {"lower": ci_lo, "upper": ci_hi},
        "capacity_violations": sum(
            1 for x in outcomes if x.granted_mbps > x.capacity_mbps + 1e-8
        ),
    }


def _percentile(values: Sequence[float], q: float) -> float:
    xs = sorted(float(x) for x in values)
    if not xs:
        return float("nan")
    if len(xs) == 1:
        return xs[0]
    pos = (len(xs) - 1) * q / 100.0
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return xs[lo]
    return xs[lo] + (xs[hi] - xs[lo]) * (pos - lo)


def compare_policies(
    trace: Sequence[TickInput],
    policies: Sequence[str] = ("fixed_equal", "round_robin", "weighted_fair", "static_qos"),
    seed: int = 42,
) -> dict[str, Any]:
    """Run every policy against exactly the same TickInput sequence."""
    results = {}
    for policy in policies:
        outcomes = run_policy(policy, trace)
        results[policy] = {
            "outcomes": outcomes,
            "summary": summarize_outcomes(outcomes, seed=seed),
        }
    return {
        "seed": seed,
        "trace_ticks": len(trace),
        "policies": results,
        "comparison_contract": {
            "same_trace": True,
            "same_seed": seed,
            "same_capacity_inputs": True,
            "predetermined_results": False,
        },
    }
