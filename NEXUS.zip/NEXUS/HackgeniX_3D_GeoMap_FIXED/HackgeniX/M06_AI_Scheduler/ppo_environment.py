import numpy as np
import gymnasium as gym

from reward_function import calculate_reward
from fairness import jain_fairness


class SchedulerEnv(gym.Env):

    def __init__(self):

        super().__init__()

        self.group_count = 5

        # Normalized state
        self.observation_space = gym.spaces.Box(
            low=0.0,
            high=1.0,
            shape=(20,),
            dtype=np.float32
        )

        # PPO produces weights for 5 groups
        self.action_space = gym.spaces.Box(
            low=0.5,
            high=1.5,
            shape=(self.group_count,),
            dtype=np.float32
        )

        self.state = None

    def reset(
        self,
        seed=None,
        options=None
    ):

        super().reset(seed=seed)

        self.state = self.np_random.random(
            20
        ).astype(np.float32)

        return self.state, {}

    def step(self, action):

        action = np.clip(
            action,
            0.5,
            1.5
        )

        # Simulated network response

        qoe = float(
            np.mean(action) / 1.5
        )

        latency = float(
            1.0 - abs(
                np.mean(action) - 1.0
            )
        )

        fairness = 1.0 - (
            np.std(action)
        )

        fairness = max(
            0.0,
            fairness
        )

        throughput = float(
            np.mean(action) / 1.5
        )

        packet_loss = max(
            0.0,
            np.mean(action) - 1.2
        )

        starvation = max(
            0.0,
            0.8 - np.min(action)
        )

        metrics = {

            "qoe": qoe,

            "latency": latency,

            "fairness": fairness,

            "throughput": throughput,

            "packet_loss": packet_loss,

            "starvation": starvation,

            "capacity_violation": 0.0,

            "oscillation": 0.0
        }

        reward = calculate_reward(
            metrics
        )

        self.state = self.np_random.random(
            20
        ).astype(np.float32)

        terminated = False

        truncated = False

        info = {
            "metrics": metrics
        }

        return (
            self.state,
            reward,
            terminated,
            truncated,
            info
        )