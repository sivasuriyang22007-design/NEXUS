# user.py

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple
from uuid import UUID
from datetime import datetime


@dataclass
class TrafficProfile:
    id: str
    name: str

    min_mbps: float
    target_mbps: float
    max_mbps: float

    latency_budget_ms: float

    packet_rate: float
    packet_size_bytes: int

    burst_score: float = 0.0
    priority_eligible: bool = False

    duration_seconds: float = 60.0

    def __post_init__(self):
        if self.min_mbps < 0:
            raise ValueError("min_mbps cannot be negative")

        if self.target_mbps < 0:
            raise ValueError("target_mbps cannot be negative")

        if self.max_mbps < 0:
            raise ValueError("max_mbps cannot be negative")

        if self.min_mbps > self.target_mbps:
            raise ValueError("min_mbps cannot exceed target_mbps")

        if self.target_mbps > self.max_mbps:
            raise ValueError("target_mbps cannot exceed max_mbps")

        if self.packet_rate <= 0:
            raise ValueError("packet_rate must be greater than zero")

        if self.packet_size_bytes <= 0:
            raise ValueError("packet_size_bytes must be greater than zero")

        if self.latency_budget_ms <= 0:
            raise ValueError("latency_budget_ms must be greater than zero")

        if not 0 <= self.burst_score <= 1:
            raise ValueError("burst_score must be between 0 and 1")


@dataclass
class Session:
    id: str
    user_id: str

    start_time: float
    end_time: float

    activity_id: str
    traffic_profile_id: str

    state: str = "ACTIVE"

    def is_active(self, tick: float) -> bool:
        return self.start_time <= tick < self.end_time


@dataclass
class User:
    id: str
    cell_id: str

    user_tier: str
    activity_id: str

    arrival_time: float
    departure_time: float

    priority_eligible: bool = False
    aging_counter: int = 0

    state: str = "IDLE"

    sessions: List[Session] = field(default_factory=list)

    def is_present(self, tick: float) -> bool:
        return self.arrival_time <= tick < self.departure_time

    def add_session(self, session: Session):
        self.sessions.append(session)


@dataclass
class Scenario:
    id: str
    name: str
    scenario_type: str

    duration_seconds: float

    cells: List[str]

    config: Dict

    seed: int

    exogenous_events: List[Dict] = field(default_factory=list)

    arrival_trace: Tuple[Dict, ...] = field(default_factory=tuple)

    def __post_init__(self):
        allowed = {
            "rush_hour",
            "flash_crowd",
            "mass_event",
            "outage",
            "emergency",
            "recovery"
        }

        if self.scenario_type not in allowed:
            raise ValueError(
                f"Invalid scenario type: {self.scenario_type}"
            )