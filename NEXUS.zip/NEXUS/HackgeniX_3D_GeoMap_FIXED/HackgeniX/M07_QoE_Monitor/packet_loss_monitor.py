"""
M07_QoE_Monitor - packet_loss_monitor.py

Packet loss, burst-loss, reordering and retransmission-proxy monitoring.
Standard library only.
"""

from __future__ import annotations

from dataclasses import dataclass
from statistics import mean, pstdev
from typing import Dict, List, Optional

from metrics_collector import percentile


@dataclass
class LossSample:
    timestamp: float
    user_id: str
    sent_packets: int
    lost_packets: int
    duplicate_packets: int = 0
    reordered_packets: int = 0
    retransmitted_packets: int = 0
    active: bool = True


class PacketLossMonitor:
    def __init__(self):
        self.samples: List[LossSample] = []

    def add(self, sample: LossSample) -> None:
        if sample.sent_packets < 0 or sample.lost_packets < 0:
            raise ValueError("packet counts must be non-negative")
        if sample.lost_packets > sample.sent_packets:
            raise ValueError("lost_packets cannot exceed sent_packets")
        self.samples.append(sample)

    def add_value(
        self,
        timestamp: float,
        user_id: str,
        sent_packets: int,
        lost_packets: int,
        duplicate_packets: int = 0,
        reordered_packets: int = 0,
        retransmitted_packets: int = 0,
        active: bool = True,
    ) -> LossSample:
        sample = LossSample(
            timestamp, user_id, sent_packets, lost_packets,
            duplicate_packets, reordered_packets, retransmitted_packets, active
        )
        self.add(sample)
        return sample

    @staticmethod
    def loss_fraction(sample: LossSample) -> float:
        if sample.sent_packets <= 0:
            return 0.0
        return sample.lost_packets / sample.sent_packets

    def fractions(self) -> List[float]:
        return [self.loss_fraction(s) for s in self.samples if s.active]

    def summary(self) -> Dict[str, float]:
        xs = self.fractions()
        if not xs:
            return {k: 0.0 for k in (
                "mean_loss", "p50_loss", "p95_loss", "max_loss",
                "burst_loss_rate", "retransmission_proxy",
                "reordering_rate", "duplicate_rate"
            )}

        sent = sum(s.sent_packets for s in self.samples if s.active)
        lost = sum(s.lost_packets for s in self.samples if s.active)
        duplicates = sum(s.duplicate_packets for s in self.samples if s.active)
        reordered = sum(s.reordered_packets for s in self.samples if s.active)
        retrans = sum(s.retransmitted_packets for s in self.samples if s.active)

        return {
            "mean_loss": mean(xs),
            "p50_loss": percentile(xs, 50),
            "p95_loss": percentile(xs, 95),
            "max_loss": max(xs),
            "burst_loss_rate": self.burst_loss_rate(),
            "retransmission_proxy": retrans / max(sent, 1),
            "reordering_rate": reordered / max(sent, 1),
            "duplicate_rate": duplicates / max(sent, 1),
            "total_loss_fraction": lost / max(sent, 1),
        }

    def burst_loss_rate(self, consecutive_loss_threshold: int = 2) -> float:
        rows = sorted((s for s in self.samples if s.active), key=lambda x: x.timestamp)
        if not rows:
            return 0.0
        burst_events = 0
        loss_run = 0
        opportunities = 0
        for s in rows:
            opportunities += 1
            if s.lost_packets > 0:
                loss_run += 1
            else:
                if loss_run >= consecutive_loss_threshold:
                    burst_events += 1
                loss_run = 0
        if loss_run >= consecutive_loss_threshold:
            burst_events += 1
        return burst_events / max(opportunities, 1)

    def max_consecutive_loss(self) -> int:
        current = best = 0
        for s in sorted(self.samples, key=lambda x: x.timestamp):
            if s.active and s.lost_packets > 0:
                current += 1
                best = max(best, current)
            else:
                current = 0
        return best

    def temporal_features(self, window: int = 5) -> Dict[str, float]:
        xs = self.fractions()
        tail = xs[-max(1, window):]
        if not tail:
            return {
                "loss_trend": 0.0,
                "loss_volatility": 0.0,
                "rolling_loss": 0.0,
                "loss_spike_frequency": 0.0,
                "max_consecutive_loss": 0.0,
            }
        trend = 0.0
        if len(tail) >= 2:
            trend = (tail[-1] - tail[0]) / (len(tail) - 1)
        spike_threshold = mean(tail) + 2.0 * (pstdev(tail) if len(tail) > 1 else 0.0)
        spikes = sum(x > spike_threshold for x in tail)
        return {
            "loss_trend": trend,
            "loss_volatility": pstdev(tail) if len(tail) > 1 else 0.0,
            "rolling_loss": mean(tail),
            "loss_spike_frequency": spikes / len(tail),
            "max_consecutive_loss": float(self.max_consecutive_loss()),
        }


if __name__ == "__main__":
    m = PacketLossMonitor()
    for i, lost in enumerate((0, 1, 2, 0, 1)):
        m.add_value(i, "u1", 100, lost)
    print("PacketLossMonitor self-check:", m.summary())
