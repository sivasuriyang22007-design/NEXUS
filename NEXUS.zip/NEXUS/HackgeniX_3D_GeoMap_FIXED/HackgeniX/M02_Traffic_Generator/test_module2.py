"""
TEMPORARY MODULE 2 INTEGRATION TEST

This file is only for testing.
Delete it after the test passes.
"""

import sys
import traceback


def test_imports():
    print("\n[1/6] Testing imports...")

    import traffic_generator
    import traffic_profiles
    import packet
    import flow_manager

    print("[PASS] traffic_generator")
    print("[PASS] traffic_profiles")
    print("[PASS] packet")
    print("[PASS] flow_manager")

    return (
        traffic_generator,
        traffic_profiles,
        packet,
        flow_manager,
    )


def test_profiles(traffic_profiles):
    print("\n[2/6] Testing traffic profiles...")

    profiles = traffic_profiles.get_default_profiles()

    assert isinstance(profiles, dict)
    assert len(profiles) > 0

    for name, profile in profiles.items():
        traffic_profiles.validate_profile(profile)

    print(f"[PASS] {len(profiles)} traffic profiles")


def test_packet(packet):
    print("\n[3/6] Testing packet system...")

    p = packet.Packet(
        user_id="user_0001",
        timestamp=1.0,
        size_bytes=800,
        direction="DL",
        flow_id="flow_0001",
        sequence_number=1,
    )

    p.validate()

    assert p.size_bytes == 800
    assert p.direction == "DL"

    print("[PASS] Packet creation")
    print("[PASS] Packet validation")


def test_flow_manager(flow_manager):
    print("\n[4/6] Testing flow manager...")

    manager = flow_manager.FlowManager(
        windows=(1, 5, 10)
    )

    assert manager.windows == (1, 5, 10)

    print("[PASS] FlowManager creation")
    print("[PASS] 1/5/10 second windows")


def test_feature_validation(flow_manager):
    print("\n[5/6] Testing observation validation...")

    manager = flow_manager.FlowManager()

    features = [
        {
            "user_id": "user_0001",
            "window_start": 0.0,
            "window_end": 1.0,
            "packet_rate": 10.0,
            "packet_size_mean": 800.0,
            "packet_size_std": 100.0,
            "flow_duration": 1.0,
            "burst_frequency": 0.0,
            "ul_dl_ratio": 0.5,
            "interarrival_mean": 0.1,
            "interarrival_std": 0.02,
            "requested_rate": 8000.0,
            "retransmission_proxy": 0.0,
            "rolling_rate": 8000.0,
        }
    ]

    result = manager.validate_observation(features)

    assert result.valid is True

    leakage = manager.detect_feature_leakage(features)

    assert leakage["leakage_detected"] is False

    print("[PASS] Observation validation")
    print("[PASS] Feature leakage detection")


def test_temporal_features(flow_manager):
    print("\n[6/6] Testing temporal sequence support...")

    manager = flow_manager.FlowManager()

    features = []

    for t in range(1, 6):
        features.append({
            "user_id": "user_0001",
            "window_start": float(t - 1),
            "window_end": float(t),

            "packet_rate": float(t),
            "packet_size_mean": 800.0,
            "packet_size_std": 100.0,
            "packet_size_min": 500.0,
            "packet_size_max": 1000.0,
            "packet_size_median": 800.0,

            "flow_duration": 1.0,
            "burst_frequency": 0.0,
            "burst_duration_mean": 0.0,
            "burst_intensity": 0.0,

            "ul_dl_ratio": 0.5,

            "interarrival_mean": 0.1,
            "interarrival_std": 0.02,

            "requested_rate": 8000.0,
            "retransmission_proxy": 0.0,
            "rolling_rate": 8000.0,

            "activity_ratio": 1.0,
            "idle_ratio": 0.0,
            "rate_change": 1.0,
            "traffic_entropy": 0.0,

            "total_bytes": 8000,
            "total_packets": 10,
            "late_event_count": 0,
        })

    sequences, users = manager.build_temporal_sequences(
        features,
        sequence_length=3,
    )

    assert len(sequences) == len(users)
    assert len(sequences) > 0

    print(
        f"[PASS] Temporal sequences: "
        f"{len(sequences)}"
    )


def main():

    print("=" * 70)
    print("MODULE 2 - INTEGRATION TEST")
    print("=" * 70)

    try:

        (
            traffic_generator,
            traffic_profiles,
            packet,
            flow_manager,
        ) = test_imports()

        test_profiles(
            traffic_profiles
        )

        test_packet(
            packet
        )

        test_flow_manager(
            flow_manager
        )

        test_feature_validation(
            flow_manager
        )

        test_temporal_features(
            flow_manager
        )

        print("\n" + "=" * 70)
        print("MODULE 2 TEST RESULT: ALL TESTS PASSED")
        print("=" * 70)
        print("\nYour four Module 2 programs can be integrated.")
        print("You can now delete test_module2.py.")

    except Exception as error:

        print("\n" + "=" * 70)
        print("MODULE 2 TEST FAILED")
        print("=" * 70)

        print("\nError:")
        print(error)

        print("\nDetailed traceback:")
        traceback.print_exc()

        print("\nDo NOT delete test_module2.py yet.")
        print("Fix the reported problem and run the test again.")

        sys.exit(1)


if __name__ == "__main__":
    main()