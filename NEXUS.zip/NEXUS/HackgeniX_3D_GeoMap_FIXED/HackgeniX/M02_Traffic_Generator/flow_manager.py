"""
M02_Traffic_Generator
flow_manager.py

Flow aggregation and ML-ready observation processing.

Capabilities
------------
- Flow aggregation
- 1 / 5 / 10 second windows
- Late/out-of-order handling
- Feature extraction
- Rolling statistics
- Schema validation
- Future-data leakage detection
- Temporal sequence construction
- Synthetic anomaly generation
- Distribution-shift detection
- Telemetry storage
- Optional scikit-learn benchmarking

Observer features intentionally exclude:
    - simulation ground truth
    - future values
    - application identity
    - configured QoS target
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from typing import (
    Any,
    Deque,
    Dict,
    Iterable,
    List,
    Optional,
    Sequence,
    Tuple,
)

import json
import math
import os
import statistics


# ============================================================================
# FEATURE STRUCTURES
# ============================================================================

@dataclass
class FeatureRow:
    """ML-safe observation feature row."""

    user_id: str

    window_start: float
    window_end: float

    packet_rate: float

    packet_size_mean: float
    packet_size_std: float
    packet_size_min: float
    packet_size_max: float
    packet_size_median: float

    flow_duration: float

    burst_frequency: float
    burst_duration_mean: float
    burst_intensity: float

    ul_dl_ratio: float

    interarrival_mean: float
    interarrival_std: float

    requested_rate: float

    retransmission_proxy: float

    rolling_rate: float

    activity_ratio: float
    idle_ratio: float

    rate_change: float

    traffic_entropy: float

    total_bytes: int
    total_packets: int

    late_event_count: int

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ValidatedFeatures:
    """Result of feature validation."""

    valid: bool

    rows: List[Dict[str, Any]]

    errors: List[str]

    warnings: List[str]


FeatureMatrix = List[Dict[str, Any]]


# ============================================================================
# FLOW MANAGER
# ============================================================================

class FlowManager:
    """
    Main observation and feature-extraction engine.
    """

    DEFAULT_WINDOWS = (1, 5, 10)

    OBSERVER_FEATURES = {
        "packet_rate",
        "packet_size_mean",
        "packet_size_std",
        "packet_size_min",
        "packet_size_max",
        "packet_size_median",
        "flow_duration",
        "burst_frequency",
        "burst_duration_mean",
        "burst_intensity",
        "ul_dl_ratio",
        "interarrival_mean",
        "interarrival_std",
        "requested_rate",
        "retransmission_proxy",
        "rolling_rate",
        "activity_ratio",
        "idle_ratio",
        "rate_change",
        "traffic_entropy",
        "total_bytes",
        "total_packets",
        "late_event_count",
    }

    FORBIDDEN_FEATURES = {
        "ground_truth",
        "label",
        "target",
        "future_value",
        "future_rate",
        "future_bytes",
        "qos_target",
        "configured_qos",
        "application_name",
        "app_name",
        "anomaly",
        "anomaly_type",
        "scenario_label",
    }

    def __init__(
        self,
        windows: Sequence[float] = DEFAULT_WINDOWS,
        max_lateness: float = 2.0,
        telemetry_directory: str = "telemetry",
    ) -> None:

        self.windows = tuple(
            sorted(
                float(window)
                for window in windows
            )
        )

        if not self.windows:
            raise ValueError(
                "At least one observation window is required."
            )

        if any(
            window <= 0
            for window in self.windows
        ):
            raise ValueError(
                "Windows must be greater than zero."
            )

        if max_lateness < 0:
            raise ValueError(
                "max_lateness cannot be negative."
            )

        self.max_lateness = max_lateness

        self.telemetry_directory = (
            telemetry_directory
        )

        self.buffers: Dict[
            str,
            Deque[Any]
        ] = defaultdict(
            lambda: deque(maxlen=10000)
        )

        self.last_timestamp: Dict[
            str,
            float
        ] = {}

        self.last_rate: Dict[
            str,
            float
        ] = defaultdict(float)

        self.feature_history: Dict[
            str,
            List[Dict[str, Any]]
        ] = defaultdict(list)

    # =========================================================================
    # PACKET NORMALIZATION
    # =========================================================================

    @staticmethod
    def _get(packet: Any, name: str, default: Any = None) -> Any:

        if isinstance(packet, dict):
            return packet.get(name, default)

        return getattr(
            packet,
            name,
            default,
        )

    # =========================================================================
    # LATE / OUT-OF-ORDER HANDLING
    # =========================================================================

    def handle_late_events(
        self,
        packets: Iterable[Any],
        current_time: Optional[float] = None,
    ) -> List[Any]:
        """
        Handle late/out-of-order events.

        Events within max_lateness are retained and sorted.
        Extremely late events are excluded from the current observation
        window rather than being incorrectly inserted into future data.
        """

        packets = list(packets)

        if not packets:
            return []

        if current_time is None:
            current_time = max(
                float(self._get(p, "timestamp", 0.0))
                for p in packets
            )

        accepted = []

        for packet in packets:

            timestamp = float(
                self._get(
                    packet,
                    "timestamp",
                    0.0,
                )
            )

            lateness = current_time - timestamp

            if lateness <= self.max_lateness:
                accepted.append(packet)

        accepted.sort(
            key=lambda packet: float(
                self._get(
                    packet,
                    "timestamp",
                    0.0,
                )
            )
        )

        return accepted

    # =========================================================================
    # FLOW AGGREGATION
    # =========================================================================

    def aggregate_flow_statistics(
        self,
        packets: Iterable[Any],
    ) -> Dict[str, Dict[str, Any]]:
        """
        Aggregate packet-level observations by user.

        Ground-truth simulation metadata is intentionally ignored.
        """

        grouped: Dict[
            str,
            List[Any]
        ] = defaultdict(list)

        for packet in packets:

            user_id = str(
                self._get(
                    packet,
                    "user_id",
                    "",
                )
            )

            if user_id:
                grouped[user_id].append(packet)

        result = {}

        for user_id, user_packets in grouped.items():

            user_packets = sorted(
                user_packets,
                key=lambda packet: float(
                    self._get(
                        packet,
                        "timestamp",
                        0.0,
                    )
                ),
            )

            sizes = [
                int(
                    self._get(
                        packet,
                        "size_bytes",
                        0,
                    )
                )
                for packet in user_packets
            ]

            timestamps = [
                float(
                    self._get(
                        packet,
                        "timestamp",
                        0.0,
                    )
                )
                for packet in user_packets
            ]

            ul_bytes = sum(
                int(
                    self._get(
                        packet,
                        "size_bytes",
                        0,
                    )
                )
                for packet in user_packets
                if str(
                    self._get(
                        packet,
                        "direction",
                        "",
                    )
                ).upper() == "UL"
            )

            dl_bytes = sum(
                int(
                    self._get(
                        packet,
                        "size_bytes",
                        0,
                    )
                )
                for packet in user_packets
                if str(
                    self._get(
                        packet,
                        "direction",
                        "",
                    )
                ).upper() == "DL"
            )

            result[user_id] = {
                "packets": user_packets,
                "packet_count": len(user_packets),
                "total_bytes": sum(sizes),
                "ul_bytes": ul_bytes,
                "dl_bytes": dl_bytes,
                "timestamps": timestamps,
                "sizes": sizes,
                "start_time": min(timestamps),
                "end_time": max(timestamps),
            }

        return result

    # =========================================================================
    # WINDOW FILTERING
    # =========================================================================

    def _window_packets(
        self,
        packets: Sequence[Any],
        window_end: float,
        window_size: float,
    ) -> List[Any]:
        """
        Return only events inside [window_start, window_end].

        Future events are explicitly excluded.
        """

        window_start = (
            window_end - window_size
        )

        result = []

        for packet in packets:

            timestamp = float(
                self._get(
                    packet,
                    "timestamp",
                    0.0,
                )
            )

            if (
                window_start
                <= timestamp
                <= window_end
            ):
                result.append(packet)

        return result

    # =========================================================================
    # STATISTICS
    # =========================================================================

    @staticmethod
    def _safe_mean(values: Sequence[float]) -> float:

        if not values:
            return 0.0

        return float(
            sum(values) / len(values)
        )

    @staticmethod
    def _safe_std(values: Sequence[float]) -> float:

        if len(values) < 2:
            return 0.0

        return float(
            statistics.stdev(values)
        )

    @staticmethod
    def _safe_median(values: Sequence[float]) -> float:

        if not values:
            return 0.0

        return float(
            statistics.median(values)
        )

    # =========================================================================
    # ENTROPY
    # =========================================================================

    @staticmethod
    def _traffic_entropy(
        packets: Sequence[Any],
    ) -> float:

        if not packets:
            return 0.0

        counts = defaultdict(int)

        for packet in packets:

            size = int(
                self_value(
                    packet,
                    "size_bytes",
                    0,
                )
            )

            # Bucket sizes to estimate distribution entropy.
            bucket = (
                (size // 100)
                * 100
            )

            counts[bucket] += 1

        total = len(packets)

        entropy = 0.0

        for count in counts.values():

            probability = count / total

            entropy -= (
                probability
                * math.log2(probability)
            )

        return entropy

    # =========================================================================
    # FEATURE EXTRACTION
    # =========================================================================

    def extract_flow_features(
        self,
        flow_batch: Any,
        windows: Optional[Sequence[float]] = None,
    ) -> FeatureMatrix:
        """
        Required API:

            extract_flow_features(flow_batch, windows)

        Extract only information available up to the observation timestamp.
        """

        windows = (
            tuple(windows)
            if windows is not None
            else self.windows
        )

        events = getattr(
            flow_batch,
            "events",
            None,
        )

        if events is None:

            if isinstance(flow_batch, dict):
                events = flow_batch.get(
                    "events",
                    [],
                )
            else:
                events = list(flow_batch)

        events = list(events)

        if not events:
            return []

        tick = getattr(
            flow_batch,
            "tick",
            None,
        )

        if tick is None and isinstance(
            flow_batch,
            dict,
        ):
            tick = flow_batch.get(
                "tick",
                0.0,
            )

        tick = float(tick or 0.0)

        grouped = defaultdict(list)

        for event in events:

            user_id = str(
                self._get(
                    event,
                    "user_id",
                    "",
                )
            )

            if user_id:
                grouped[user_id].append(event)

        rows: FeatureMatrix = []

        for window_size in windows:

            window_size = float(window_size)

            window_end = tick

            window_start = (
                window_end - window_size
            )

            for user_id, user_events in grouped.items():

                # CRITICAL:
                # Only events <= window_end are considered.
                window_events = [
                    event
                    for event in user_events
                    if (
                        window_start
                        <= float(
                            self._get(
                                event,
                                "timestamp",
                                0.0,
                            )
                        )
                        <= window_end
                    )
                ]

                if not window_events:
                    continue

                timestamps = sorted(
                    float(
                        self._get(
                            event,
                            "timestamp",
                            0.0,
                        )
                    )
                    for event in window_events
                )

                sizes = [
                    float(
                        self._get(
                            event,
                            "size_bytes",
                            0,
                        )
                    )
                    for event in window_events
                ]

                ul_packets = [
                    event
                    for event in window_events
                    if str(
                        self._get(
                            event,
                            "direction",
                            "",
                        )
                    ).upper() == "UL"
                ]

                dl_packets = [
                    event
                    for event in window_events
                    if str(
                        self._get(
                            event,
                            "direction",
                            "",
                        )
                    ).upper() == "DL"
                ]

                total_bytes = int(
                    sum(sizes)
                )

                packet_count = len(
                    window_events
                )

                packet_rate = (
                    packet_count
                    / window_size
                )

                bytes_rate = (
                    total_bytes
                    / window_size
                )

                interarrivals = [
                    timestamps[index]
                    - timestamps[index - 1]
                    for index in range(
                        1,
                        len(timestamps),
                    )
                ]

                # Basic burst definition:
                # inter-arrival below 25% of the observation window.
                burst_threshold = (
                    window_size * 0.25
                )

                bursts = [
                    value
                    for value in interarrivals
                    if value <= burst_threshold
                ]

                burst_frequency = (
                    len(bursts)
                    / window_size
                )

                flow_duration = (
                    max(timestamps)
                    - min(timestamps)
                    if len(timestamps) > 1
                    else 0.0
                )

                ul_bytes = sum(
                    float(
                        self._get(
                            packet,
                            "size_bytes",
                            0,
                        )
                    )
                    for packet in ul_packets
                )

                dl_bytes = sum(
                    float(
                        self._get(
                            packet,
                            "size_bytes",
                            0,
                        )
                    )
                    for packet in dl_packets
                )

                ul_dl_ratio = (
                    ul_bytes
                    / max(
                        1.0,
                        dl_bytes,
                    )
                )

                retransmission_values = [
                    float(
                        self._get(
                            packet,
                            "retransmission_proxy",
                            0.0,
                        )
                    )
                    for packet in window_events
                ]

                retransmission_proxy = (
                    self._safe_mean(
                        retransmission_values
                    )
                )

                previous_rate = (
                    self.last_rate[user_id]
                )

                rate_change = (
                    packet_rate
                    - previous_rate
                )

                self.last_rate[user_id] = (
                    packet_rate
                )

                active_seconds = min(
                    window_size,
                    max(
                        0.0,
                        flow_duration,
                    ),
                )

                activity_ratio = (
                    active_seconds
                    / window_size
                )

                activity_ratio = min(
                    1.0,
                    max(
                        0.0,
                        activity_ratio,
                    ),
                )

                idle_ratio = (
                    1.0
                    - activity_ratio
                )

                late_count = sum(
                    bool(
                        self._get(
                            event,
                            "late",
                            False,
                        )
                    )
                    for event in window_events
                )

                # Entropy is computed only from current-window data.
                entropy = self._calculate_entropy(
                    sizes
                )

                row = FeatureRow(
                    user_id=user_id,
                    window_start=window_start,
                    window_end=window_end,

                    packet_rate=packet_rate,

                    packet_size_mean=self._safe_mean(
                        sizes
                    ),

                    packet_size_std=self._safe_std(
                        sizes
                    ),

                    packet_size_min=min(sizes),

                    packet_size_max=max(sizes),

                    packet_size_median=self._safe_median(
                        sizes
                    ),

                    flow_duration=flow_duration,

                    burst_frequency=burst_frequency,

                    burst_duration_mean=self._safe_mean(
                        bursts
                    ),

                    burst_intensity=(
                        len(bursts)
                        / max(
                            1,
                            packet_count,
                        )
                    ),

                    ul_dl_ratio=ul_dl_ratio,

                    interarrival_mean=self._safe_mean(
                        interarrivals
                    ),

                    interarrival_std=self._safe_std(
                        interarrivals
                    ),

                    requested_rate=bytes_rate,

                    retransmission_proxy=retransmission_proxy,

                    rolling_rate=bytes_rate,

                    activity_ratio=activity_ratio,

                    idle_ratio=idle_ratio,

                    rate_change=rate_change,

                    traffic_entropy=entropy,

                    total_bytes=total_bytes,

                    total_packets=packet_count,

                    late_event_count=late_count,
                )

                row_dict = row.to_dict()

                rows.append(row_dict)

                self.feature_history[
                    user_id
                ].append(row_dict)

        return rows

    # =========================================================================
    # ENTROPY IMPLEMENTATION
    # =========================================================================

    @staticmethod
    def _calculate_entropy(
        sizes: Sequence[float],
    ) -> float:

        if not sizes:
            return 0.0

        buckets = defaultdict(int)

        for size in sizes:

            bucket = int(size // 100)

            buckets[bucket] += 1

        total = len(sizes)

        entropy = 0.0

        for count in buckets.values():

            probability = (
                count / total
            )

            entropy -= (
                probability
                * math.log2(probability)
            )

        return entropy

    # =========================================================================
    # VALIDATION
    # =========================================================================

    def validate_observation(
        self,
        features: FeatureMatrix,
    ) -> ValidatedFeatures:
        """
        Required API.

        Validate feature rows and detect obvious future/target leakage.
        """

        errors: List[str] = []
        warnings: List[str] = []

        if not isinstance(
            features,
            list,
        ):
            return ValidatedFeatures(
                valid=False,
                rows=[],
                errors=[
                    "Features must be a list."
                ],
                warnings=[],
            )

        validated_rows = []

        for index, row in enumerate(features):

            if not isinstance(
                row,
                dict,
            ):
                errors.append(
                    f"Row {index} is not a dictionary."
                )
                continue

            lower_keys = {
                str(key).lower()
                for key in row.keys()
            }

            forbidden = (
                lower_keys
                & self.FORBIDDEN_FEATURES
            )

            if forbidden:
                errors.append(
                    f"Row {index} contains "
                    f"forbidden fields: "
                    f"{sorted(forbidden)}"
                )

            if (
                "window_start" not in row
                or "window_end" not in row
            ):
                errors.append(
                    f"Row {index} missing "
                    "window boundaries."
                )

            if (
                "window_start" in row
                and "window_end" in row
                and row["window_end"]
                < row["window_start"]
            ):
                errors.append(
                    f"Row {index} has invalid "
                    "window ordering."
                )

            # Numeric sanity checking.
            for key, value in row.items():

                if isinstance(
                    value,
                    float,
                ):

                    if not math.isfinite(value):
                        errors.append(
                            f"Row {index}, feature "
                            f"'{key}' is NaN/Inf."
                        )

            validated_rows.append(row)

        return ValidatedFeatures(
            valid=len(errors) == 0,
            rows=validated_rows,
            errors=errors,
            warnings=warnings,
        )

    # =========================================================================
    # FUTURE DATA LEAKAGE DETECTION
    # =========================================================================

    def detect_feature_leakage(
        self,
        features: FeatureMatrix,
    ) -> Dict[str, Any]:
        """
        Detect feature names that imply future/target information.

        This checks feature schema rather than attempting to infer hidden
        information from arbitrary numeric values.
        """

        violations = []

        for row_index, row in enumerate(features):

            keys = {
                str(key).lower()
                for key in row.keys()
            }

            forbidden = (
                keys
                & self.FORBIDDEN_FEATURES
            )

            if forbidden:
                violations.append({
                    "row": row_index,
                    "fields": sorted(
                        forbidden
                    ),
                })

        return {
            "leakage_detected": bool(
                violations
            ),
            "violations": violations,
        }

    # =========================================================================
    # SEQUENCE CREATION
    # =========================================================================

    def build_temporal_sequences(
        self,
        features: FeatureMatrix,
        sequence_length: int = 10,
        feature_columns: Optional[
            Sequence[str]
        ] = None,
    ) -> Tuple[List[List[List[float]]], List[str]]:
        """
        Convert windowed observations into sequences suitable for
        LSTM/GRU/temporal CNN models.

        No future rows are included in each sequence.
        """

        if sequence_length <= 0:
            raise ValueError(
                "sequence_length must be > 0."
            )

        if not features:
            return [], []

        if feature_columns is None:
            feature_columns = [
                feature
                for feature in self.OBSERVER_FEATURES
                if feature not in {
                    "user_id",
                }
            ]

        feature_columns = list(
            feature_columns
        )

        grouped = defaultdict(list)

        for row in features:

            grouped[
                str(row["user_id"])
            ].append(row)

        sequences: List[
            List[List[float]]
        ] = []

        sequence_users: List[str] = []

        for user_id, rows in grouped.items():

            rows = sorted(
                rows,
                key=lambda row: (
                    row["window_end"]
                ),
            )

            for index in range(
                sequence_length,
                len(rows) + 1,
            ):

                sequence_rows = rows[
                    index - sequence_length:index
                ]

                # Explicitly ensure monotonic temporal ordering.
                times = [
                    row["window_end"]
                    for row in sequence_rows
                ]

                if any(
                    times[i]
                    > times[i + 1]
                    for i in range(
                        len(times) - 1
                    )
                ):
                    continue

                sequence = []

                for row in sequence_rows:

                    values = []

                    for feature in feature_columns:

                        value = row.get(
                            feature,
                            0.0,
                        )

                        if not isinstance(
                            value,
                            (int, float),
                        ):
                            value = 0.0

                        values.append(
                            float(value)
                        )

                    sequence.append(values)

                sequences.append(sequence)
                sequence_users.append(user_id)

        return sequences, sequence_users

    # =========================================================================
    # DATASET GENERATION
    # =========================================================================

    def generate_sequence_dataset(
        self,
        features: FeatureMatrix,
        sequence_length: int = 10,
        feature_columns: Optional[
            Sequence[str]
        ] = None,
    ) -> Dict[str, Any]:

        sequences, users = (
            self.build_temporal_sequences(
                features,
                sequence_length,
                feature_columns,
            )
        )

        return {
            "X": sequences,
            "users": users,
            "sequence_length": sequence_length,
            "feature_columns": list(
                feature_columns
                or [
                    feature
                    for feature
                    in self.OBSERVER_FEATURES
                    if feature != "user_id"
                ]
            ),
        }

    # =========================================================================
    # DISTRIBUTION SHIFT
    # =========================================================================

    def detect_distribution_shift(
        self,
        baseline: Sequence[float],
        current: Sequence[float],
        threshold: float = 0.20,
    ) -> Dict[str, Any]:
        """
        Simple distribution-shift detector based on mean and standard
        deviation changes.

        This is intentionally lightweight and does not require SciPy.
        """

        if not baseline or not current:
            return {
                "shift_detected": False,
                "reason": "Insufficient data",
            }

        baseline_mean = (
            sum(baseline)
            / len(baseline)
        )

        current_mean = (
            sum(current)
            / len(current)
        )

        baseline_std = (
            statistics.pstdev(baseline)
            if len(baseline) > 1
            else 0.0
        )

        current_std = (
            statistics.pstdev(current)
            if len(current) > 1
            else 0.0
        )

        mean_change = (
            abs(
                current_mean
                - baseline_mean
            )
            / max(
                abs(baseline_mean),
                1e-9,
            )
        )

        std_change = (
            abs(
                current_std
                - baseline_std
            )
            / max(
                abs(baseline_std),
                1e-9,
            )
        )

        detected = (
            mean_change > threshold
            or std_change > threshold
        )

        return {
            "shift_detected": detected,
            "baseline_mean": baseline_mean,
            "current_mean": current_mean,
            "baseline_std": baseline_std,
            "current_std": current_std,
            "mean_change": mean_change,
            "std_change": std_change,
            "threshold": threshold,
        }

    # =========================================================================
    # ANOMALY GENERATION
    # =========================================================================

    def generate_anomalies(
        self,
        features: FeatureMatrix,
        seed: int = 42,
        probability: float = 0.02,
        magnitude: float = 5.0,
    ) -> List[Dict[str, Any]]:
        """
        Generate an offline anomaly-evaluation dataset.

        IMPORTANT:
        The generated anomaly marker is returned separately from observer
        features and must not be fed into the deployed model.
        """

        import random

        if not 0 <= probability <= 1:
            raise ValueError(
                "probability must be between 0 and 1."
            )

        rng = random.Random(seed)

        results = []

        anomaly_types = [
            "traffic_spike",
            "packet_size_spike",
            "burst_spike",
            "ul_dl_shift",
            "rate_drop",
        ]

        for row in features:

            modified = dict(row)

            anomaly = None

            if rng.random() < probability:

                anomaly = rng.choice(
                    anomaly_types
                )

                if anomaly == "traffic_spike":

                    modified[
                        "packet_rate"
                    ] *= magnitude

                    modified[
                        "rolling_rate"
                    ] *= magnitude

                elif anomaly == "packet_size_spike":

                    modified[
                        "packet_size_mean"
                    ] *= magnitude

                    modified[
                        "packet_size_max"
                    ] *= magnitude

                elif anomaly == "burst_spike":

                    modified[
                        "burst_frequency"
                    ] *= magnitude

                    modified[
                        "burst_intensity"
                    ] *= magnitude

                elif anomaly == "ul_dl_shift":

                    modified[
                        "ul_dl_ratio"
                    ] *= magnitude

                elif anomaly == "rate_drop":

                    modified[
                        "packet_rate"
                    ] /= magnitude

                    modified[
                        "rolling_rate"
                    ] /= magnitude

            results.append({
                "features": modified,
                "ground_truth_anomaly": anomaly,
            })

        return results

    # =========================================================================
    # ML BENCHMARKING
    # =========================================================================

    def benchmark_ml_models(
        self,
        X: Sequence[Sequence[float]],
        y: Sequence[Any],
    ) -> List[Dict[str, Any]]:
        """
        Benchmark available scikit-learn models.

        Scikit-learn is optional. The method reports a useful message when
        it is not installed instead of breaking the traffic generator.
        """

        try:
            from sklearn.model_selection import train_test_split
            from sklearn.metrics import (
                accuracy_score,
                precision_score,
                recall_score,
                f1_score,
            )
            from sklearn.linear_model import LogisticRegression
            from sklearn.ensemble import (
                RandomForestClassifier,
                GradientBoostingClassifier,
            )

        except ImportError:

            return [{
                "status": "unavailable",
                "reason": (
                    "scikit-learn is not installed."
                ),
            }]

        if len(X) < 10:
            return [{
                "status": "insufficient_data",
                "reason": (
                    "At least 10 samples are recommended."
                ),
            }]

        X_train, X_test, y_train, y_test = (
            train_test_split(
                X,
                y,
                test_size=0.25,
                random_state=42,
                stratify=y
                if len(set(y)) > 1
                else None,
            )
        )

        models = {
            "logistic_regression":
                LogisticRegression(
                    max_iter=1000
                ),

            "random_forest":
                RandomForestClassifier(
                    n_estimators=100,
                    random_state=42,
                ),

            "gradient_boosting":
                GradientBoostingClassifier(
                    random_state=42,
                ),
        }

        results = []

        for name, model in models.items():

            try:

                model.fit(
                    X_train,
                    y_train,
                )

                predictions = model.predict(
                    X_test
                )

                results.append({
                    "model": name,
                    "status": "success",
                    "accuracy": accuracy_score(
                        y_test,
                        predictions,
                    ),
                    "precision": precision_score(
                        y_test,
                        predictions,
                        average="weighted",
                        zero_division=0,
                    ),
                    "recall": recall_score(
                        y_test,
                        predictions,
                        average="weighted",
                        zero_division=0,
                    ),
                    "f1": f1_score(
                        y_test,
                        predictions,
                        average="weighted",
                        zero_division=0,
                    ),
                })

            except Exception as exc:

                results.append({
                    "model": name,
                    "status": "failed",
                    "error": str(exc),
                })

        return results

    # =========================================================================
    # TELEMETRY STORAGE
    # =========================================================================

    def store_telemetry_batch(
        self,
        batch: Any,
        run_id: str,
        tick: float,
    ) -> None:
        """
        Required telemetry-storage API.

        Stores only observation data required for later processing.
        """

        os.makedirs(
            self.telemetry_directory,
            exist_ok=True,
        )

        events = getattr(
            batch,
            "events",
            [],
        )

        record = {
            "run_id": run_id,
            "tick": tick,
            "events": [],
        }

        for event in events:

            # Do not store simulation ground-truth anomaly labels.
            record["events"].append({
                "user_id": self._get(
                    event,
                    "user_id",
                ),
                "timestamp": self._get(
                    event,
                    "timestamp",
                ),
                "size_bytes": self._get(
                    event,
                    "size_bytes",
                ),
                "direction": self._get(
                    event,
                    "direction",
                ),
                "flow_id": self._get(
                    event,
                    "flow_id",
                ),
                "sequence_number": self._get(
                    event,
                    "sequence_number",
                ),
            })

        filename = os.path.join(
            self.telemetry_directory,
            f"{run_id}.jsonl",
        )

        with open(
            filename,
            "a",
            encoding="utf-8",
        ) as file:

            file.write(
                json.dumps(record)
                + "\n"
            )


# ============================================================================
# STANDALONE API FUNCTIONS
# ============================================================================

_DEFAULT_MANAGER = FlowManager()


def extract_flow_features(
    flow_batch: Any,
    windows: Sequence[float],
) -> FeatureMatrix:

    return _DEFAULT_MANAGER.extract_flow_features(
        flow_batch,
        windows,
    )


def validate_observation(
    features: FeatureMatrix,
) -> ValidatedFeatures:

    return _DEFAULT_MANAGER.validate_observation(
        features
    )


def store_telemetry_batch(
    batch: Any,
    run_id: str,
    tick: float,
) -> None:

    _DEFAULT_MANAGER.store_telemetry_batch(
        batch,
        run_id,
        tick,
    )


def validate_schema(
    features: FeatureMatrix,
) -> ValidatedFeatures:

    return _DEFAULT_MANAGER.validate_observation(
        features
    )


def detect_feature_leakage(
    features: FeatureMatrix,
) -> Dict[str, Any]:

    return _DEFAULT_MANAGER.detect_feature_leakage(
        features
    )


def build_temporal_sequences(
    features: FeatureMatrix,
    sequence_length: int = 10,
) -> Tuple[
    List[List[List[float]]],
    List[str],
]:

    return _DEFAULT_MANAGER.build_temporal_sequences(
        features,
        sequence_length,
    )


def generate_sequence_dataset(
    features: FeatureMatrix,
    sequence_length: int = 10,
) -> Dict[str, Any]:

    return _DEFAULT_MANAGER.generate_sequence_dataset(
        features,
        sequence_length,
    )


def detect_distribution_shift(
    baseline: Sequence[float],
    current: Sequence[float],
    threshold: float = 0.20,
) -> Dict[str, Any]:

    return _DEFAULT_MANAGER.detect_distribution_shift(
        baseline,
        current,
        threshold,
    )


def generate_anomalies(
    features: FeatureMatrix,
    seed: int = 42,
    probability: float = 0.02,
) -> List[Dict[str, Any]]:

    return _DEFAULT_MANAGER.generate_anomalies(
        features,
        seed=seed,
        probability=probability,
    )


def benchmark_ml_models(
    X: Sequence[Sequence[float]],
    y: Sequence[Any],
) -> List[Dict[str, Any]]:

    return _DEFAULT_MANAGER.benchmark_ml_models(
        X,
        y,
    )


def aggregate_flow_statistics(
    packets: Iterable[Any],
) -> Dict[str, Dict[str, Any]]:

    return _DEFAULT_MANAGER.aggregate_flow_statistics(
        packets
    )


def handle_late_events(
    packets: Iterable[Any],
    current_time: Optional[float] = None,
) -> List[Any]:

    return _DEFAULT_MANAGER.handle_late_events(
        packets,
        current_time,
    )


# ============================================================================
# SELF TEST
# ============================================================================

def run_self_test() -> bool:

    print("=" * 70)
    print("M02 Flow Manager - Self Test")
    print("=" * 70)

    # Import locally so this file can still be inspected independently.
    from traffic_generator import (
        GeneratorConfig,
        TrafficGenerator,
    )

    config = GeneratorConfig(
        duration_seconds=10,
        tick_seconds=1,
        users=3,
        seed=42,
        default_arrival_process="poisson",
    )

    generator = TrafficGenerator(config)

    manager = FlowManager(
        windows=(1, 5, 10)
    )

    all_features = []

    total_generated_bytes = 0

    for batch in generator.stream():

        total_generated_bytes += (
            batch.total_bytes
        )

        features = manager.extract_flow_features(
            batch,
            windows=(1, 5, 10),
        )

        all_features.extend(features)

        validation = manager.validate_observation(
            features
        )

        assert validation.valid, (
            validation.errors
        )

    print("[PASS] Feature extraction")

    validation = manager.validate_observation(
        all_features
    )

    assert validation.valid

    print("[PASS] Feature validation")

    leakage = manager.detect_feature_leakage(
        all_features
    )

    assert not leakage["leakage_detected"]

    print("[PASS] Feature leakage check")

    sequences, users = (
        manager.build_temporal_sequences(
            all_features,
            sequence_length=2,
        )
    )

    assert len(sequences) == len(users)

    print("[PASS] Temporal sequence generation")

    if all_features:

        anomaly_data = (
            manager.generate_anomalies(
                all_features,
                seed=42,
            )
        )

        assert len(
            anomaly_data
        ) == len(all_features)

    print("[PASS] Anomaly dataset generation")

    shift = manager.detect_distribution_shift(
        [1, 2, 3, 4, 5],
        [10, 11, 12, 13, 14],
    )

    assert shift["shift_detected"]

    print("[PASS] Distribution shift detection")

    print()
    print("Feature rows:", len(all_features))
    print(
        "Generated bytes:",
        total_generated_bytes,
    )

    print()
    print("ALL FLOW MANAGER TESTS PASSED")
    print("=" * 70)

    return True


# ============================================================================
# HELPER
# ============================================================================

def self_value(
    obj: Any,
    name: str,
    default: Any = None,
) -> Any:

    if isinstance(obj, dict):
        return obj.get(name, default)

    return getattr(
        obj,
        name,
        default,
    )


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    run_self_test()

