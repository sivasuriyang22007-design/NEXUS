"""
M02_Traffic_Generator
=====================

Traffic generation engine for synthetic network-observation experiments.

Features
--------
- Poisson arrivals
- On/Off burst arrivals
- Periodic arrivals
- Self-similar-inspired arrivals
- Multi-user traffic simulation
- Streaming/tick-based generation
- Configurable packet-size and session behavior
- Synthetic anomaly scenarios
- Reproducible random seeds
- Late/out-of-order event simulation
- No future information is used by generated observations

The module is intentionally self-contained so it can be tested before
integration with:

    traffic_profiles.py
    packet.py
    flow_manager.py
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence
import math
import random
import time


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class TrafficEvent:
    """Represents one synthetic traffic event."""

    user_id: str
    timestamp: float
    size_bytes: int
    direction: str = "DL"
    flow_id: str = ""
    arrival_process: str = "poisson"
    anomaly: Optional[str] = None
    sequence_number: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert the event into a serializable dictionary."""
        return asdict(self)


@dataclass
class UserState:
    """State maintained for one simulated user."""

    user_id: str

    arrival_process: str = "poisson"

    packet_rate: float = 10.0
    packet_size_mean: float = 800.0
    packet_size_std: float = 200.0

    ul_ratio: float = 0.25

    session_mean: float = 60.0
    session_std: float = 20.0

    burst_probability: float = 0.05
    burst_multiplier: float = 4.0

    periodic_interval: float = 5.0

    active: bool = True
    session_end: float = 60.0

    last_arrival: float = 0.0
    sequence_number: int = 0

    on_state: bool = True
    next_state_change: float = 0.0

    anomaly: Optional[str] = None

    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FlowBatch:
    """Collection of events generated during one simulation tick."""

    tick: float
    events: List[TrafficEvent]
    run_id: str

    @property
    def total_bytes(self) -> int:
        return sum(event.size_bytes for event in self.events)

    @property
    def total_packets(self) -> int:
        return len(self.events)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tick": self.tick,
            "run_id": self.run_id,
            "total_packets": self.total_packets,
            "total_bytes": self.total_bytes,
            "events": [event.to_dict() for event in self.events],
        }


@dataclass
class AnomalyConfig:
    """Configuration for synthetic anomaly generation."""

    enabled: bool = False

    spike_probability: float = 0.01
    spike_multiplier: float = 5.0

    packet_size_multiplier: float = 3.0

    burst_multiplier: float = 5.0

    retransmission_probability: float = 0.0

    duration_seconds: float = 5.0


@dataclass
class GeneratorConfig:
    """Global traffic-generator configuration."""

    duration_seconds: float = 60.0

    tick_seconds: float = 1.0

    users: int = 10

    seed: int = 42

    default_arrival_process: str = "poisson"

    packet_rate: float = 10.0

    packet_size_mean: float = 800.0

    packet_size_std: float = 200.0

    ul_ratio: float = 0.25

    session_mean: float = 60.0

    session_std: float = 20.0

    enable_anomalies: bool = False

    anomaly_config: AnomalyConfig = field(default_factory=AnomalyConfig)


# ============================================================================
# TRAFFIC GENERATOR
# ============================================================================

class TrafficGenerator:
    """
    Synthetic traffic generator.

    The generator supports four arrival processes:

        poisson
        on_off
        periodic
        self_similar

    Example
    -------
    generator = TrafficGenerator(
        GeneratorConfig(
            duration_seconds=30,
            users=5,
            seed=123
        )
    )

    for batch in generator.stream():
        print(batch.total_packets)
    """

    SUPPORTED_PROCESSES = {
        "poisson",
        "on_off",
        "periodic",
        "self_similar",
    }

    SUPPORTED_ANOMALIES = {
        "traffic_spike",
        "packet_size_spike",
        "burst_spike",
        "ul_dl_shift",
        "retransmission_spike",
    }

    def __init__(
        self,
        config: Optional[GeneratorConfig] = None,
        *,
        run_id: Optional[str] = None,
    ) -> None:

        self.config = config or GeneratorConfig()

        self._validate_config()

        self.seed = self.config.seed

        # Dedicated RNG means other modules cannot accidentally change
        # reproducibility by consuming Python's global random state.
        self.rng = random.Random(self.seed)

        self.run_id = run_id or self._create_run_id()

        self.current_time = 0.0

        self.users: List[UserState] = []

        self.total_packets_generated = 0
        self.total_bytes_generated = 0

        self._create_users()

    # ----------------------------------------------------------------------
    # CONFIGURATION
    # ----------------------------------------------------------------------

    def _validate_config(self) -> None:
        if self.config.duration_seconds <= 0:
            raise ValueError("duration_seconds must be > 0")

        if self.config.tick_seconds <= 0:
            raise ValueError("tick_seconds must be > 0")

        if self.config.users <= 0:
            raise ValueError("users must be > 0")

        if self.config.packet_rate < 0:
            raise ValueError("packet_rate cannot be negative")

        if self.config.packet_size_mean <= 0:
            raise ValueError("packet_size_mean must be > 0")

        if self.config.packet_size_std < 0:
            raise ValueError("packet_size_std cannot be negative")

        self._validate_process(self.config.default_arrival_process)

    def _validate_process(self, process: str) -> None:
        process = process.lower()

        if process not in self.SUPPORTED_PROCESSES:
            raise ValueError(
                f"Unsupported arrival process '{process}'. "
                f"Supported: {sorted(self.SUPPORTED_PROCESSES)}"
            )

    # ----------------------------------------------------------------------
    # RUN ID / REPRODUCIBILITY
    # ----------------------------------------------------------------------

    def _create_run_id(self) -> str:
        """
        Create a deterministic run identifier.

        It intentionally depends on the configured seed instead of the
        wall-clock time so experiments can be reproduced.
        """
        return f"traffic_run_seed_{self.seed}"

    def reset(self) -> None:
        """Reset the generator to its initial reproducible state."""

        self.rng = random.Random(self.seed)

        self.current_time = 0.0

        self.total_packets_generated = 0
        self.total_bytes_generated = 0

        self.users.clear()

        self._create_users()

    # ----------------------------------------------------------------------
    # USER CREATION
    # ----------------------------------------------------------------------

    def _create_users(self) -> None:

        for index in range(self.config.users):

            process = self.config.default_arrival_process

            # Give different users slightly different characteristics while
            # keeping the complete experiment deterministic.
            rate_factor = self.rng.uniform(0.7, 1.3)

            packet_rate = max(
                0.01,
                self.config.packet_rate * rate_factor
            )

            size_factor = self.rng.uniform(0.8, 1.2)

            packet_mean = max(
                64.0,
                self.config.packet_size_mean * size_factor
            )

            session_duration = max(
                self.config.tick_seconds,
                self.rng.gauss(
                    self.config.session_mean,
                    max(0.1, self.config.session_std),
                ),
            )

            user = UserState(
                user_id=f"user_{index + 1:04d}",
                arrival_process=process,
                packet_rate=packet_rate,
                packet_size_mean=packet_mean,
                packet_size_std=self.config.packet_size_std,
                ul_ratio=min(
                    1.0,
                    max(0.0, self.config.ul_ratio)
                ),
                session_mean=self.config.session_mean,
                session_std=self.config.session_std,
                session_end=session_duration,
                periodic_interval=max(
                    self.config.tick_seconds,
                    self.rng.uniform(2.0, 10.0)
                ),
                next_state_change=self.rng.uniform(1.0, 5.0),
            )

            self.users.append(user)

    # ----------------------------------------------------------------------
    # PACKET SIZE
    # ----------------------------------------------------------------------

    def _generate_packet_size(
        self,
        user: UserState,
        multiplier: float = 1.0,
    ) -> int:

        # Gaussian is used as a simple configurable distribution.
        # Clamp to a realistic positive minimum.
        value = self.rng.gauss(
            user.packet_size_mean * multiplier,
            max(1.0, user.packet_size_std),
        )

        return max(64, int(round(value)))

    # ----------------------------------------------------------------------
    # DIRECTION
    # ----------------------------------------------------------------------

    def _generate_direction(self, user: UserState) -> str:

        return (
            "UL"
            if self.rng.random() < user.ul_ratio
            else "DL"
        )

    # ----------------------------------------------------------------------
    # ARRIVAL PROCESSES
    # ----------------------------------------------------------------------

    def _poisson_count(
        self,
        rate: float,
        interval: float,
    ) -> int:
        """
        Generate a Poisson-distributed packet count.

        Uses Knuth's algorithm and therefore does not require SciPy.
        """

        if rate <= 0 or interval <= 0:
            return 0

        lam = rate * interval

        if lam <= 0:
            return 0

        # For moderate lambda this exact algorithm is simple and portable.
        # For extremely large lambda use a Gaussian approximation.
        if lam > 100:
            value = self.rng.gauss(lam, math.sqrt(lam))
            return max(0, int(round(value)))

        limit = math.exp(-lam)

        count = 0
        product = 1.0

        while product > limit:
            count += 1
            product *= self.rng.random()

        return count - 1

    def _generate_poisson_arrivals(
        self,
        user: UserState,
        t: float,
        interval: float,
    ) -> int:

        return self._poisson_count(
            user.packet_rate,
            interval,
        )

    def _update_on_off_state(
        self,
        user: UserState,
        t: float,
    ) -> None:

        if t >= user.next_state_change:

            user.on_state = not user.on_state

            if user.on_state:
                duration = self.rng.uniform(1.0, 5.0)
            else:
                duration = self.rng.uniform(1.0, 10.0)

            user.next_state_change = t + duration

    def _generate_on_off_arrivals(
        self,
        user: UserState,
        t: float,
        interval: float,
    ) -> int:

        self._update_on_off_state(user, t)

        if not user.on_state:
            return 0

        rate = user.packet_rate

        if user.anomaly == "burst_spike":
            rate *= 5.0

        return self._poisson_count(
            rate,
            interval,
        )

    def _generate_periodic_arrivals(
        self,
        user: UserState,
        t: float,
        interval: float,
    ) -> int:

        period = max(
            self.config.tick_seconds,
            user.periodic_interval,
        )

        previous_phase = (
            (t - interval) % period
        )

        current_phase = t % period

        # Generate a packet when the simulation crosses the periodic point.
        crossed = (
            current_phase < previous_phase
            or abs(current_phase) < 1e-9
            or abs(previous_phase) < 1e-9
        )

        return 1 if crossed else 0

    def _generate_self_similar_arrivals(
        self,
        user: UserState,
        t: float,
        interval: float,
    ) -> int:

        """
        Self-similar-inspired traffic.

        This is intentionally an approximation rather than a claim of exact
        long-range-dependent traffic. A slowly varying multiplier is combined
        with Poisson sampling.
        """

        phase = (
            math.sin(t / 7.0)
            + 0.5 * math.sin(t / 17.0)
            + 0.25 * math.sin(t / 31.0)
        )

        multiplier = max(
            0.05,
            1.0 + 0.6 * phase
        )

        rate = user.packet_rate * multiplier

        return self._poisson_count(
            rate,
            interval,
        )

    def _generate_arrival_count(
        self,
        user: UserState,
        t: float,
        interval: float,
    ) -> int:

        process = user.arrival_process.lower()

        if process == "poisson":
            return self._generate_poisson_arrivals(
                user,
                t,
                interval,
            )

        if process == "on_off":
            return self._generate_on_off_arrivals(
                user,
                t,
                interval,
            )

        if process == "periodic":
            return self._generate_periodic_arrivals(
                user,
                t,
                interval,
            )

        if process == "self_similar":
            return self._generate_self_similar_arrivals(
                user,
                t,
                interval,
            )

        raise ValueError(
            f"Unknown arrival process: {process}"
        )

    # ----------------------------------------------------------------------
    # ANOMALY SUPPORT
    # ----------------------------------------------------------------------

    def _select_anomaly(
        self,
        user: UserState,
    ) -> Optional[str]:

        if not self.config.enable_anomalies:
            return None

        probability = self.config.anomaly_config.spike_probability

        if self.rng.random() >= probability:
            return None

        anomaly = self.rng.choice(
            list(self.SUPPORTED_ANOMALIES)
        )

        return anomaly

    def generate_anomalies(
        self,
        user: UserState,
    ) -> Optional[str]:
        """
        Select a synthetic anomaly for a user.

        The anomaly is simulation metadata and must not be included as an
        observer feature when evaluating leakage-safe ML models.
        """

        anomaly = self._select_anomaly(user)

        user.anomaly = anomaly

        return anomaly

    # ----------------------------------------------------------------------
    # EVENT GENERATION
    # ----------------------------------------------------------------------

    def _create_event(
        self,
        user: UserState,
        timestamp: float,
        sequence_number: int,
    ) -> TrafficEvent:

        anomaly = user.anomaly

        size_multiplier = 1.0

        if anomaly == "packet_size_spike":
            size_multiplier = (
                self.config.anomaly_config.packet_size_multiplier
            )

        size = self._generate_packet_size(
            user,
            multiplier=size_multiplier,
        )

        direction = self._generate_direction(user)

        if anomaly == "ul_dl_shift":
            direction = (
                "UL"
                if direction == "DL"
                else "DL"
            )

        flow_id = (
            f"{user.user_id}_flow_"
            f"{int(timestamp * 1000)}"
        )

        return TrafficEvent(
            user_id=user.user_id,
            timestamp=timestamp,
            size_bytes=size,
            direction=direction,
            flow_id=flow_id,
            arrival_process=user.arrival_process,
            anomaly=anomaly,
            sequence_number=sequence_number,
        )

    # ----------------------------------------------------------------------
    # REQUIRED API
    # ----------------------------------------------------------------------

    def generate_tick_arrivals(
        self,
        user_states: Sequence[UserState],
        t: float,
        rng: Optional[random.Random] = None,
    ) -> FlowBatch:
        """
        Required Module 2 API.

        Generate traffic for all users during one simulation tick.

        Parameters
        ----------
        user_states:
            Iterable of UserState objects.

        t:
            Current simulation time.

        rng:
            Optional RNG. If omitted, the generator's deterministic RNG is
            used.

        Returns
        -------
        FlowBatch
        """

        active_rng = rng or self.rng

        # Keep the generator's random behavior aligned with the supplied RNG.
        original_rng = self.rng
        self.rng = active_rng

        try:
            events: List[TrafficEvent] = []

            interval = self.config.tick_seconds

            for user in user_states:

                if not user.active:
                    continue

                if t > user.session_end:
                    user.active = False
                    continue

                # Determine whether this user receives an anomaly during this
                # tick. Existing anomaly state is cleared each tick so that
                # anomalies remain localized.
                self.generate_anomalies(user)

                count = self._generate_arrival_count(
                    user,
                    t,
                    interval,
                )

                # Traffic spike anomaly affects packet count.
                if user.anomaly == "traffic_spike":
                    count = int(
                        count
                        * self.config.anomaly_config.spike_multiplier
                    )

                # Burst anomaly affects packet count.
                if user.anomaly == "burst_spike":
                    count = int(
                        count
                        * self.config.anomaly_config.burst_multiplier
                    )

                count = max(0, count)

                for _ in range(count):

                    # Spread packet timestamps inside the current tick.
                    if count == 1:
                        offset = self.rng.uniform(
                            0,
                            interval
                        )
                    else:
                        offset = self.rng.uniform(
                            0,
                            interval
                        )

                    timestamp = (
                        max(
                            0.0,
                            t - interval + offset
                        )
                    )

                    user.sequence_number += 1

                    event = self._create_event(
                        user,
                        timestamp,
                        user.sequence_number,
                    )

                    events.append(event)

                    user.last_arrival = timestamp

                    self.total_packets_generated += 1
                    self.total_bytes_generated += event.size_bytes

            # Sort events by event time before returning the normal batch.
            events.sort(
                key=lambda event: (
                    event.timestamp,
                    event.user_id,
                    event.sequence_number,
                )
            )

            return FlowBatch(
                tick=t,
                events=events,
                run_id=self.run_id,
            )

        finally:
            self.rng = original_rng

    # ----------------------------------------------------------------------
    # STREAMING
    # ----------------------------------------------------------------------

    def stream(
        self,
        *,
        duration: Optional[float] = None,
        tick_seconds: Optional[float] = None,
    ) -> Iterator[FlowBatch]:
        """
        Stream traffic batch-by-batch.

        This does not require storing the entire simulation in memory.
        """

        duration = (
            self.config.duration_seconds
            if duration is None
            else duration
        )

        tick_seconds = (
            self.config.tick_seconds
            if tick_seconds is None
            else tick_seconds
        )

        if duration <= 0:
            raise ValueError("duration must be > 0")

        if tick_seconds <= 0:
            raise ValueError("tick_seconds must be > 0")

        t = 0.0

        while t < duration:

            batch = self.generate_tick_arrivals(
                self.users,
                t + tick_seconds,
                self.rng,
            )

            self.current_time = t + tick_seconds

            yield batch

            t += tick_seconds

    # ----------------------------------------------------------------------
    # FULL SIMULATION
    # ----------------------------------------------------------------------

    def simulate(
        self,
        *,
        duration: Optional[float] = None,
        tick_seconds: Optional[float] = None,
    ) -> List[FlowBatch]:
        """
        Run the complete simulation and return all batches.

        Use stream() instead when the simulation is large.
        """

        return list(
            self.stream(
                duration=duration,
                tick_seconds=tick_seconds,
            )
        )

    # ----------------------------------------------------------------------
    # LATE / OUT-OF-ORDER EVENTS
    # ----------------------------------------------------------------------

    def inject_late_events(
        self,
        batch: FlowBatch,
        probability: float = 0.05,
    ) -> FlowBatch:
        """
        Create a test batch containing some late/out-of-order events.

        This is useful for testing flow_manager.py's event-buffer logic.
        """

        if not 0 <= probability <= 1:
            raise ValueError(
                "probability must be between 0 and 1"
            )

        events = list(batch.events)

        for event in events:

            if self.rng.random() < probability:

                # Move timestamp backwards by a small deterministic amount.
                delay = self.rng.uniform(
                    0.001,
                    max(
                        0.002,
                        self.config.tick_seconds / 2
                    ),
                )

                event.timestamp = max(
                    0.0,
                    event.timestamp - delay
                )

        # Deliberately shuffle to simulate out-of-order arrival.
        self.rng.shuffle(events)

        return FlowBatch(
            tick=batch.tick,
            events=events,
            run_id=batch.run_id,
        )

    # ----------------------------------------------------------------------
    # STATISTICS
    # ----------------------------------------------------------------------

    def statistics(self) -> Dict[str, Any]:
        """Return generator-level statistics."""

        return {
            "run_id": self.run_id,
            "seed": self.seed,
            "users": len(self.users),
            "duration_seconds": self.config.duration_seconds,
            "tick_seconds": self.config.tick_seconds,
            "arrival_process": self.config.default_arrival_process,
            "total_packets_generated": (
                self.total_packets_generated
            ),
            "total_bytes_generated": (
                self.total_bytes_generated
            ),
        }


# ============================================================================
# REQUIRED STANDALONE API
# ============================================================================

def generate_tick_arrivals(
    user_states: Sequence[UserState],
    t: float,
    rng: random.Random,
    *,
    tick_seconds: float = 1.0,
    run_id: str = "standalone_run",
) -> FlowBatch:
    """
    Standalone implementation of the required API.

    This allows flow_manager.py to call the function without having to
    instantiate a TrafficGenerator itself.
    """

    generator = TrafficGenerator(
        GeneratorConfig(
            duration_seconds=max(
                tick_seconds,
                t + tick_seconds
            ),
            tick_seconds=tick_seconds,
            users=max(1, len(user_states)),
            seed=0,
        ),
        run_id=run_id,
    )

    generator.users = list(user_states)
    generator.rng = rng

    return generator.generate_tick_arrivals(
        generator.users,
        t,
        rng,
    )


# ============================================================================
# FACTORY HELPERS
# ============================================================================

def create_default_generator(
    users: int = 10,
    duration: float = 60.0,
    seed: int = 42,
    arrival_process: str = "poisson",
) -> TrafficGenerator:
    """Create a generator with sensible defaults."""

    return TrafficGenerator(
        GeneratorConfig(
            users=users,
            duration_seconds=duration,
            seed=seed,
            default_arrival_process=arrival_process,
        )
    )


def create_profiled_generator(
    users: int = 10,
    duration: float = 60.0,
    seed: int = 42,
    arrival_processes: Optional[Sequence[str]] = None,
) -> TrafficGenerator:
    """
    Create a generator and distribute arrival processes among users.

    Example:

        [
            "poisson",
            "on_off",
            "periodic",
            "self_similar"
        ]
    """

    generator = TrafficGenerator(
        GeneratorConfig(
            users=users,
            duration_seconds=duration,
            seed=seed,
        )
    )

    processes = list(
        arrival_processes
        or [
            "poisson",
            "on_off",
            "periodic",
            "self_similar",
        ]
    )

    if not processes:
        raise ValueError(
            "arrival_processes cannot be empty"
        )

    for index, user in enumerate(generator.users):
        process = processes[index % len(processes)]

        generator._validate_process(process)

        user.arrival_process = process

    return generator


# ============================================================================
# SELF TEST
# ============================================================================

def run_self_test() -> bool:
    """
    Run a lightweight test without requiring any external package.

    This temporary self-test can remain in the file because it is useful
    for checking Module 2 during integration.
    """

    print("=" * 70)
    print("M02 Traffic Generator - Self Test")
    print("=" * 70)

    # --------------------------------------------------------------
    # Test 1: Reproducibility
    # --------------------------------------------------------------

    config = GeneratorConfig(
        duration_seconds=5,
        tick_seconds=1,
        users=3,
        seed=12345,
        default_arrival_process="poisson",
    )

    generator_a = TrafficGenerator(config)
    results_a = generator_a.simulate()

    generator_b = TrafficGenerator(config)
    results_b = generator_b.simulate()

    signature_a = [
        (
            e.user_id,
            e.timestamp,
            e.size_bytes,
            e.direction,
        )
        for batch in results_a
        for e in batch.events
    ]

    signature_b = [
        (
            e.user_id,
            e.timestamp,
            e.size_bytes,
            e.direction,
        )
        for batch in results_b
        for e in batch.events
    ]

    assert signature_a == signature_b, (
        "Reproducibility test failed"
    )

    print("[PASS] Reproducibility")

    # --------------------------------------------------------------
    # Test 2: All arrival processes
    # --------------------------------------------------------------

    generator = create_profiled_generator(
        users=8,
        duration=5,
        seed=999,
    )

    batches = generator.simulate()

    assert len(batches) == 5

    print("[PASS] Arrival processes")

    # --------------------------------------------------------------
    # Test 3: Event validity
    # --------------------------------------------------------------

    all_events = [
        event
        for batch in batches
        for event in batch.events
    ]

    for event in all_events:

        assert event.size_bytes >= 64

        assert event.direction in {
            "UL",
            "DL",
        }

        assert event.timestamp >= 0

        assert event.user_id

    print("[PASS] Event validation")

    # --------------------------------------------------------------
    # Test 4: Late event generation
    # --------------------------------------------------------------

    if batches:

        late_batch = generator.inject_late_events(
            batches[0],
            probability=0.5,
        )

        assert (
            len(late_batch.events)
            == len(batches[0].events)
        )

    print("[PASS] Late/out-of-order event generation")

    # --------------------------------------------------------------
    # Test 5: Statistics
    # --------------------------------------------------------------

    stats = generator.statistics()

    assert stats["seed"] == 999
    assert stats["users"] == 8

    print("[PASS] Statistics")

    # --------------------------------------------------------------
    # Summary
    # --------------------------------------------------------------

    print()
    print("Generated packets :", stats["total_packets_generated"])
    print("Generated bytes   :", stats["total_bytes_generated"])
    print("Run ID            :", stats["run_id"])
    print()
    print("ALL TRAFFIC GENERATOR TESTS PASSED")
    print("=" * 70)

    return True


# ============================================================================
# COMMAND-LINE EXECUTION
# ============================================================================

if __name__ == "__main__":
    run_self_test()
