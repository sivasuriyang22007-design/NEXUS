"""
M02_Traffic_Generator
traffic_profiles.py

Traffic profiles for synthetic network-observation experiments.

This module defines configurable user behavior without depending on
real application names.

Supported profile types:
    - light
    - normal
    - heavy
    - bursty
    - periodic
    - intermittent
    - bulk_transfer
    - variable

The profiles are intentionally generic so they can be used for
observer/ML experiments without exposing application identity.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Any
import random


# ============================================================================
# PROFILE DATA STRUCTURE
# ============================================================================

@dataclass
class TrafficProfile:
    """Configuration describing one generic traffic behavior."""

    name: str

    packet_rate: float

    packet_size_mean: float

    packet_size_std: float

    ul_ratio: float

    session_mean: float

    session_std: float

    burst_probability: float

    burst_multiplier: float

    periodic_interval: float

    idle_probability: float = 0.0

    retransmission_probability: float = 0.0

    description: str = ""

    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ============================================================================
# DEFAULT PROFILES
# ============================================================================

def light_profile() -> TrafficProfile:
    return TrafficProfile(
        name="light",
        packet_rate=3.0,
        packet_size_mean=500.0,
        packet_size_std=120.0,
        ul_ratio=0.30,
        session_mean=30.0,
        session_std=10.0,
        burst_probability=0.02,
        burst_multiplier=2.0,
        periodic_interval=10.0,
        idle_probability=0.30,
        retransmission_probability=0.01,
        description="Low-volume intermittent traffic.",
    )


def normal_profile() -> TrafficProfile:
    return TrafficProfile(
        name="normal",
        packet_rate=10.0,
        packet_size_mean=800.0,
        packet_size_std=200.0,
        ul_ratio=0.25,
        session_mean=60.0,
        session_std=20.0,
        burst_probability=0.05,
        burst_multiplier=3.0,
        periodic_interval=5.0,
        idle_probability=0.10,
        retransmission_probability=0.02,
        description="Moderate and relatively stable traffic.",
    )


def heavy_profile() -> TrafficProfile:
    return TrafficProfile(
        name="heavy",
        packet_rate=35.0,
        packet_size_mean=1200.0,
        packet_size_std=300.0,
        ul_ratio=0.35,
        session_mean=180.0,
        session_std=40.0,
        burst_probability=0.10,
        burst_multiplier=4.0,
        periodic_interval=3.0,
        idle_probability=0.03,
        retransmission_probability=0.04,
        description="High-volume sustained traffic.",
    )


def bursty_profile() -> TrafficProfile:
    return TrafficProfile(
        name="bursty",
        packet_rate=8.0,
        packet_size_mean=900.0,
        packet_size_std=250.0,
        ul_ratio=0.40,
        session_mean=90.0,
        session_std=25.0,
        burst_probability=0.30,
        burst_multiplier=7.0,
        periodic_interval=4.0,
        idle_probability=0.20,
        retransmission_probability=0.03,
        description="Traffic dominated by intermittent bursts.",
    )


def periodic_profile() -> TrafficProfile:
    return TrafficProfile(
        name="periodic",
        packet_rate=5.0,
        packet_size_mean=700.0,
        packet_size_std=150.0,
        ul_ratio=0.20,
        session_mean=120.0,
        session_std=30.0,
        burst_probability=0.03,
        burst_multiplier=2.0,
        periodic_interval=5.0,
        idle_probability=0.05,
        retransmission_probability=0.01,
        description="Traffic with recurring temporal activity.",
    )


def intermittent_profile() -> TrafficProfile:
    return TrafficProfile(
        name="intermittent",
        packet_rate=4.0,
        packet_size_mean=650.0,
        packet_size_std=180.0,
        ul_ratio=0.45,
        session_mean=45.0,
        session_std=20.0,
        burst_probability=0.10,
        burst_multiplier=3.0,
        periodic_interval=12.0,
        idle_probability=0.50,
        retransmission_probability=0.02,
        description="Longer idle periods with occasional activity.",
    )


def bulk_transfer_profile() -> TrafficProfile:
    return TrafficProfile(
        name="bulk_transfer",
        packet_rate=50.0,
        packet_size_mean=1400.0,
        packet_size_std=100.0,
        ul_ratio=0.50,
        session_mean=300.0,
        session_std=60.0,
        burst_probability=0.08,
        burst_multiplier=2.0,
        periodic_interval=2.0,
        idle_probability=0.01,
        retransmission_probability=0.05,
        description="Large sustained data transfers.",
    )


def variable_profile() -> TrafficProfile:
    return TrafficProfile(
        name="variable",
        packet_rate=15.0,
        packet_size_mean=850.0,
        packet_size_std=400.0,
        ul_ratio=0.35,
        session_mean=100.0,
        session_std=50.0,
        burst_probability=0.20,
        burst_multiplier=5.0,
        periodic_interval=7.0,
        idle_probability=0.20,
        retransmission_probability=0.03,
        description="Highly variable traffic characteristics.",
    )


# ============================================================================
# PROFILE REGISTRY
# ============================================================================

def get_default_profiles() -> Dict[str, TrafficProfile]:
    """Return all built-in generic traffic profiles."""

    profiles = [
        light_profile(),
        normal_profile(),
        heavy_profile(),
        bursty_profile(),
        periodic_profile(),
        intermittent_profile(),
        bulk_transfer_profile(),
        variable_profile(),
    ]

    return {
        profile.name: profile
        for profile in profiles
    }


def get_profile(name: str) -> TrafficProfile:
    """Get a profile by name."""

    profiles = get_default_profiles()

    key = name.strip().lower()

    if key not in profiles:
        raise ValueError(
            f"Unknown traffic profile '{name}'. "
            f"Available profiles: {sorted(profiles)}"
        )

    return profiles[key]


# ============================================================================
# PROFILE VALIDATION
# ============================================================================

def validate_profile(profile: TrafficProfile) -> None:
    """Validate profile parameters."""

    if not profile.name:
        raise ValueError("Profile name cannot be empty.")

    if profile.packet_rate < 0:
        raise ValueError("packet_rate cannot be negative.")

    if profile.packet_size_mean <= 0:
        raise ValueError(
            "packet_size_mean must be greater than zero."
        )

    if profile.packet_size_std < 0:
        raise ValueError(
            "packet_size_std cannot be negative."
        )

    if not 0 <= profile.ul_ratio <= 1:
        raise ValueError(
            "ul_ratio must be between 0 and 1."
        )

    if profile.session_mean <= 0:
        raise ValueError(
            "session_mean must be greater than zero."
        )

    if profile.session_std < 0:
        raise ValueError(
            "session_std cannot be negative."
        )

    probabilities = {
        "burst_probability": profile.burst_probability,
        "idle_probability": profile.idle_probability,
        "retransmission_probability":
            profile.retransmission_probability,
    }

    for name, value in probabilities.items():

        if not 0 <= value <= 1:
            raise ValueError(
                f"{name} must be between 0 and 1."
            )

    if profile.burst_multiplier < 1:
        raise ValueError(
            "burst_multiplier must be >= 1."
        )

    if profile.periodic_interval <= 0:
        raise ValueError(
            "periodic_interval must be greater than zero."
        )


# ============================================================================
# RANDOMIZED PROFILE CREATION
# ============================================================================

def randomize_profile(
    profile: TrafficProfile,
    rng: Optional[random.Random] = None,
    variation: float = 0.20,
) -> TrafficProfile:
    """
    Create a deterministic randomized version of a profile.

    variation=0.20 means approximately +/-20 percent variation.
    """

    rng = rng or random.Random()

    if not 0 <= variation <= 1:
        raise ValueError(
            "variation must be between 0 and 1."
        )

    def vary(value: float) -> float:
        factor = rng.uniform(
            1.0 - variation,
            1.0 + variation,
        )
        return value * factor

    result = TrafficProfile(
        name=f"{profile.name}_variant",
        packet_rate=max(
            0.01,
            vary(profile.packet_rate),
        ),
        packet_size_mean=max(
            64.0,
            vary(profile.packet_size_mean),
        ),
        packet_size_std=max(
            1.0,
            vary(profile.packet_size_std),
        ),
        ul_ratio=min(
            1.0,
            max(
                0.0,
                vary(profile.ul_ratio),
            ),
        ),
        session_mean=max(
            1.0,
            vary(profile.session_mean),
        ),
        session_std=max(
            0.0,
            vary(profile.session_std),
        ),
        burst_probability=min(
            1.0,
            max(
                0.0,
                vary(profile.burst_probability),
            ),
        ),
        burst_multiplier=max(
            1.0,
            vary(profile.burst_multiplier),
        ),
        periodic_interval=max(
            0.1,
            vary(profile.periodic_interval),
        ),
        idle_probability=min(
            1.0,
            max(
                0.0,
                vary(profile.idle_probability),
            ),
        ),
        retransmission_probability=min(
            1.0,
            max(
                0.0,
                vary(profile.retransmission_probability),
            ),
        ),
        description=profile.description,
        metadata=dict(profile.metadata),
    )

    validate_profile(result)

    return result


# ============================================================================
# USER PROFILE ASSIGNMENT
# ============================================================================

def assign_profiles(
    user_count: int,
    profile_names: Optional[List[str]] = None,
    seed: int = 42,
) -> Dict[str, TrafficProfile]:
    """
    Assign traffic profiles to users.

    Returns:
        {
            "user_0001": TrafficProfile(...),
            ...
        }
    """

    if user_count <= 0:
        raise ValueError(
            "user_count must be greater than zero."
        )

    rng = random.Random(seed)

    available = get_default_profiles()

    if profile_names is None:
        names = list(available.keys())
    else:
        names = [
            name.strip().lower()
            for name in profile_names
        ]

        for name in names:
            if name not in available:
                raise ValueError(
                    f"Unknown profile: {name}"
                )

    assignments: Dict[str, TrafficProfile] = {}

    for index in range(user_count):

        selected_name = names[index % len(names)]

        base = available[selected_name]

        assignments[
            f"user_{index + 1:04d}"
        ] = randomize_profile(
            base,
            rng=rng,
            variation=0.10,
        )

    return assignments


# ============================================================================
# SCENARIO GENERATORS
# ============================================================================

def create_scenario(
    scenario: str,
    user_count: int,
    seed: int = 42,
) -> Dict[str, TrafficProfile]:
    """
    Create predefined simulation scenarios.

    Supported scenarios:
        balanced
        burst_heavy
        periodic
        high_volume
        mixed
        anomaly_ready
    """

    scenario = scenario.strip().lower()

    scenario_map = {
        "balanced": [
            "light",
            "normal",
            "normal",
            "heavy",
        ],
        "burst_heavy": [
            "bursty",
            "bursty",
            "normal",
            "intermittent",
        ],
        "periodic": [
            "periodic",
            "periodic",
            "normal",
        ],
        "high_volume": [
            "heavy",
            "bulk_transfer",
            "bulk_transfer",
        ],
        "mixed": [
            "light",
            "normal",
            "heavy",
            "bursty",
            "periodic",
            "intermittent",
            "bulk_transfer",
            "variable",
        ],
        "anomaly_ready": [
            "normal",
            "bursty",
            "variable",
        ],
    }

    if scenario not in scenario_map:
        raise ValueError(
            f"Unknown scenario '{scenario}'. "
            f"Available: {sorted(scenario_map)}"
        )

    return assign_profiles(
        user_count=user_count,
        profile_names=scenario_map[scenario],
        seed=seed,
    )


# ============================================================================
# PROFILE SUMMARY
# ============================================================================

def summarize_profiles(
    profiles: Dict[str, TrafficProfile],
) -> Dict[str, Any]:
    """Return simple statistics about assigned profiles."""

    if not profiles:
        return {
            "users": 0,
            "profile_counts": {},
            "average_packet_rate": 0.0,
            "average_packet_size": 0.0,
        }

    counts: Dict[str, int] = {}

    total_rate = 0.0
    total_size = 0.0

    for profile in profiles.values():

        counts[profile.name] = (
            counts.get(profile.name, 0) + 1
        )

        total_rate += profile.packet_rate
        total_size += profile.packet_size_mean

    count = len(profiles)

    return {
        "users": count,
        "profile_counts": counts,
        "average_packet_rate": total_rate / count,
        "average_packet_size": total_size / count,
    }


# ============================================================================
# SELF TEST
# ============================================================================

def run_self_test() -> bool:

    print("=" * 70)
    print("M02 Traffic Profiles - Self Test")
    print("=" * 70)

    profiles = get_default_profiles()

    assert len(profiles) == 8

    for profile in profiles.values():
        validate_profile(profile)

    print("[PASS] Default profiles")

    assignments = assign_profiles(
        user_count=20,
        seed=123,
    )

    assert len(assignments) == 20

    print("[PASS] User profile assignment")

    scenario = create_scenario(
        "mixed",
        user_count=20,
        seed=123,
    )

    assert len(scenario) == 20

    print("[PASS] Scenario generation")

    summary = summarize_profiles(scenario)

    assert summary["users"] == 20

    print("[PASS] Profile statistics")

    print()
    print("Users:", summary["users"])
    print("Average packet rate:",
          round(summary["average_packet_rate"], 2))
    print("Average packet size:",
          round(summary["average_packet_size"], 2))

    print()
    print("ALL TRAFFIC PROFILE TESTS PASSED")
    print("=" * 70)

    return True


if __name__ == "__main__":
    run_self_test()
