"""Optional multi-horizon temporal regressor; no training on inference path."""
import torch
from torch import nn

FEATURES = ("offered_mbps", "delivered_mbps", "queue_mbits",
            "active_users", "active_sessions", "capacity_mbps",
            "event_demand_mbps", "future_capacity_mbps")
HORIZONS = (5, 10, 30)

class GRUForecaster(nn.Module):
    def __init__(self, input_size=len(FEATURES), hidden_size=32, layers=1):
        super().__init__()
        self.gru = nn.GRU(input_size, hidden_size, layers, batch_first=True)
        self.head = nn.Sequential(nn.Linear(hidden_size, 32), nn.ReLU(),
                                  nn.Linear(32, len(HORIZONS)))

    def forward(self, x):
        if x.ndim != 3 or x.shape[-1] != self.gru.input_size:
            raise ValueError("Expected [batch, history, features]")
        output, _ = self.gru(x)
        return torch.nn.functional.softplus(self.head(output[:, -1, :]))
