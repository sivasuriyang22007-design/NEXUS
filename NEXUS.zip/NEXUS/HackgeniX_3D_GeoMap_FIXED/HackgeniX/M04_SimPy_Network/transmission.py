# M04_SimPy_Network/transmission.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class TransmissionRecord:
    packet_id: str
    flow_id: str
    user_id: str

    created_at: float
    queued_at: Optional[float]
    transmitted_at: float
    delivered_at: Optional[float]

    packet_bits: int
    allocated_mbps: float

    queue_delay_ms: float
    transmission_delay_ms: float
    propagation_delay_ms: float
    total_delay_ms: float

    dropped: bool = False
    drop_reason: Optional[str] = None


class Transmission:
    """
    Represents the actual transmission of a packet over a link.
    """

    def __init__(
        self,
        packet: Any,
        start_time: float,
        allocated_mbps: float,
        propagation_delay_ms: float,
    ):
        self.packet = packet
        self.start_time = float(start_time)

        self.allocated_mbps = max(
            0.000001,
            float(allocated_mbps),
        )

        self.propagation_delay_ms = max(
            0.0,
            float(propagation_delay_ms),
        )

    def packet_bits(self) -> int:
        if hasattr(self.packet, "size_bits"):
            return int(self.packet.size_bits)

        if hasattr(self.packet, "size_bytes"):
            return int(self.packet.size_bytes) * 8

        if hasattr(self.packet, "size"):
            return int(self.packet.size) * 8

        if isinstance(self.packet, dict):
            if "size_bits" in self.packet:
                return int(self.packet["size_bits"])

            if "size_bytes" in self.packet:
                return int(self.packet["size_bytes"]) * 8

            if "size" in self.packet:
                return int(self.packet["size"]) * 8

        raise ValueError("Packet size not found")

    def serialization_delay_seconds(self) -> float:
        bits = self.packet_bits()

        capacity_bps = self.allocated_mbps * 1_000_000

        return bits / capacity_bps

    def total_delay_seconds(self) -> float:
        return (
            self.serialization_delay_seconds()
            + self.propagation_delay_ms / 1000.0
        )

    def build_record(
        self,
        delivered_at: float,
        queue_delay_ms: float = 0.0,
    ) -> TransmissionRecord:

        packet_id = str(
            getattr(self.packet, "packet_id", "unknown")
        )

        flow_id = str(
            getattr(self.packet, "flow_id", "unknown")
        )

        user_id = str(
            getattr(self.packet, "user_id", "unknown")
        )

        created_at = float(
            getattr(self.packet, "created_at", self.start_time)
        )

        tx_delay_ms = (
            self.serialization_delay_seconds() * 1000.0
        )

        propagation_ms = self.propagation_delay_ms

        total_delay_ms = (
            queue_delay_ms
            + tx_delay_ms
            + propagation_ms
        )

        return TransmissionRecord(
            packet_id=packet_id,
            flow_id=flow_id,
            user_id=user_id,
            created_at=created_at,
            queued_at=self.start_time,
            transmitted_at=self.start_time,
            delivered_at=delivered_at,
            packet_bits=self.packet_bits(),
            allocated_mbps=self.allocated_mbps,
            queue_delay_ms=queue_delay_ms,
            transmission_delay_ms=tx_delay_ms,
            propagation_delay_ms=propagation_ms,
            total_delay_ms=total_delay_ms,
        )