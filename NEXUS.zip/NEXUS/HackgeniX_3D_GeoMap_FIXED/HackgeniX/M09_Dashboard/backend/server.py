from __future__ import annotations
import json, subprocess, sys, socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
DATA=Path(__file__).resolve().parent/"dashboard_data.json"
GEO=Path(__file__).resolve().parent/"geo_users.json"
INDEX=ROOT/"M09_Dashboard"/"frontend"/"index.html"

CONFIG_PATH = Path(__file__).resolve().parent / "admin_config.json"
DEFAULT_CONFIG = {
    "qoe_target": 0.70,
    "max_latency_ms": 55.0,
    "loss_threshold_pct": 2.0,
    "ema_alpha": 0.30,
    "active_policy": "ai_safety_allocator",
    "congestion_guard": True,
    "auto_reroute": True,
    "rf_power_boost_dbm": 3.0,
    "cell_overload_pct": 90.0,
}

def get_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return dict(DEFAULT_CONFIG)

def save_config(cfg: dict) -> None:
    merged = {**DEFAULT_CONFIG, **cfg}
    CONFIG_PATH.write_text(json.dumps(merged, indent=2), encoding="utf-8")

# In-memory event request store (dynamic — powers the Event Requests page)
EVENTS = [
    {"id": "EVT-001", "title": "Maintenance Window", "priority": "high", "status": "pending", "date": "2025-08-10"},
    {"id": "EVT-002", "title": "Capacity Upgrade", "priority": "medium", "status": "approved", "date": "2025-08-09"},
    {"id": "EVT-003", "title": "Emergency Reroute", "priority": "critical", "status": "pending", "date": "2025-08-08"},
    {"id": "EVT-004", "title": "Decommission Cell-19", "priority": "low", "status": "pending", "date": "2025-08-07"},
    {"id": "EVT-005", "title": "Spectrum Realloc", "priority": "medium", "status": "rejected", "date": "2025-08-05"},
]
_EVENT_SEQ = [5]
_LAST_AUTO_EVENT_BUCKET = [-1]
_AUTO_EVENT_TEMPLATES = [
    ("Cell Overload Alert", "high"), ("Scheduled Firmware Update", "low"),
    ("Congestion Reroute Request", "critical"), ("Capacity Expansion", "medium"),
    ("SLA Breach Investigation", "high"), ("Spectrum Reallocation", "medium"),
]

def _next_event_id():
    _EVENT_SEQ[0] += 1
    return f"EVT-{_EVENT_SEQ[0]:03d}"

def _maybe_auto_generate_event():
    """Deterministically drop a new pending event every ~40s so the Events
    page feels alive even with nobody clicking anything."""
    import time
    bucket = int(time.time() // 40)
    if bucket != _LAST_AUTO_EVENT_BUCKET[0]:
        _LAST_AUTO_EVENT_BUCKET[0] = bucket
        title, priority = _AUTO_EVENT_TEMPLATES[bucket % len(_AUTO_EVENT_TEMPLATES)]
        ev = {
            "id": _next_event_id(), "title": title, "priority": priority,
            "status": "pending", "date": time.strftime("%Y-%m-%d"),
        }
        EVENTS.insert(0, ev)
        if len(EVENTS) > 40:
            EVENTS.pop()
        return ev
    return None

# In-memory audit log feed
AUDIT_LOGS = [
    {"ts": "23:20:12", "module": "M06_AI_Scheduler", "level": "INFO", "msg": "Safety policy allocator initialized across 180 cells with baseline constraints."},
    {"ts": "23:20:14", "module": "M05_Congestion_Predictor", "level": "INFO", "msg": "EMA-v1 predictor calibrated. Multi-horizon windows: 5s, 10s, 30s."},
    {"ts": "23:20:18", "module": "M07_QoE_Monitor", "level": "WARN", "msg": "CELL-042 utilization exceeded 92%. Active SLA degradation risk."},
    {"ts": "23:20:25", "module": "M08_Priority_System", "level": "INFO", "msg": "Priority preemption applied for 14 Premium users on CELL-115."},
    {"ts": "23:20:31", "module": "M04_SimPy_Network", "level": "INFO", "msg": "SimPy discrete-event telemetry synchronized with trace tick stream."},
    {"ts": "23:20:44", "module": "M03_Traffic_Classifier", "level": "INFO", "msg": "eMBB/URLLC flow separation verified. Zero packet drops on critical slice."},
    {"ts": "23:21:02", "module": "M10_Analytics", "level": "INFO", "msg": "Jain fairness evaluated: 0.7864 mean across scheduled virtual users."},
    {"ts": "23:21:15", "module": "M09_Dashboard", "level": "INFO", "msg": "Holographic 3D GeoMap engine connected. 2,500 user points active."},
]

class Handler(BaseHTTPRequestHandler):
    def send(self, status, body, ctype="text/html; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send(204, b"")

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/api/dashboard":
            if not DATA.exists():
                self.send(404, json.dumps({"error": "Run integration.py first"}), "application/json")
            else:
                self.send(200, DATA.read_bytes(), "application/json")
        elif path == "/api/users":
            if not GEO.exists():
                self.send(404, json.dumps({"error": "geo_users.json missing"}), "application/json")
            else:
                self.send(200, GEO.read_bytes(), "application/json")
        elif path == "/api/health":
            self.send(200, b'{"status":"ok","engine":"nexus-v7.1","3d":"online"}', "application/json")
        elif path == "/api/admin/config":
            self.send(200, json.dumps(get_config()), "application/json")
        elif path == "/api/admin/logs":
            self.send(200, json.dumps({"logs": AUDIT_LOGS}), "application/json")
        elif path == "/api/realtime":
            # Lightweight continuous metrics for 2000+ simulated values (no model impact)
            import time, random, math
            t = time.time()
            cells = 42
            users = 8421 + int(80 * math.sin(t / 8))
            load = 72 + 12 * math.sin(t / 5) + random.uniform(-2, 2)
            latency = 11 + 4 * math.sin(t / 3) + random.uniform(-1, 1)
            cong = "LOW" if load < 80 else ("MEDIUM" if load < 90 else "HIGH")
            new_event = _maybe_auto_generate_event()
            events_pending = sum(1 for e in EVENTS if e["status"] == "pending")

            # Live feed for Line Network page: per-link utilization + per-node table
            link_loads = [round(min(99, max(5, 45 + 40 * abs(math.sin(t / 4 + i * 0.5)) + random.uniform(-4, 4))), 1) for i in range(8)]
            node_metrics = []
            for i in range(8):
                nload = round(min(99, max(5, 35 + 55 * abs(math.sin(t / 3.5 + i * 0.7)) + random.uniform(-5, 5))), 1)
                status = "crit" if nload > 85 else ("warn" if nload > 70 else "ok")
                node_metrics.append({
                    "id": f"Node-{i+1}",
                    "status": status,
                    "load": nload,
                    "latency_ms": round(max(1, 3 + 8 * abs(math.sin(t / 2 + i)) + random.uniform(0, 1.5)), 1)
                })

            # Live feed for AI Scheduler page: granted vs offered
            sched_granted = round(80 + 40 * abs(math.sin(t / 4)) + random.uniform(-5, 5), 1)
            sched_offered = round(sched_granted + 15 + 10 * abs(math.sin(t / 6)), 1)

            # Live feed for Prediction & Drift page
            forecast_point = round(120 + 30 * math.sin(t / 10) + random.uniform(-5, 5), 1)
            drift_point = round(max(0, 0.05 + 0.02 * math.sin(t / 6) + random.uniform(0, 0.03)), 3)

            # Live feed for Resource Allocation page
            alloc_base = [45, 25, 18, 12]
            alloc_raw = [max(4, b + 6 * math.sin(t / 7 + i) + random.uniform(-2, 2)) for i, b in enumerate(alloc_base)]
            alloc_sum = sum(alloc_raw)
            alloc_breakdown = [round(a / alloc_sum * 100, 1) for a in alloc_raw]
            alloc_bars = [round(min(99, max(5, 50 + 45 * abs(math.sin(t / 3 + i * 0.6)) + random.uniform(-4, 4))), 1) for i in range(5)]

            # Live feed for Line Network KPI strip
            links_active = 96 + int(24 * abs(math.sin(t / 9)))
            avg_hop_latency = round(sum(n["latency_ms"] for n in node_metrics) / len(node_metrics), 1)

            # Live feed for Prediction & Drift KPI strip + predictor status table
            fc5 = round(forecast_point + random.uniform(-2, 2), 1)
            fc10 = round(forecast_point + 12 + 4 * math.sin(t / 6), 1)
            fc30 = round(forecast_point + 26 + 6 * math.sin(t / 4), 1)
            mae5 = round(2.5 + 2.2 * abs(math.sin(t / 5)), 1)
            mae10 = round(5.0 + 3.5 * abs(math.sin(t / 6)), 1)
            mae30 = round(10.0 + 6.0 * abs(math.sin(t / 7)), 1)
            predictor_status = [
                {"horizon": "5s", "source": "EMA-v1 + GRU", "mae": mae5, "status": "low" if mae5 < 6 else ("medium" if mae5 < 9 else "high")},
                {"horizon": "10s", "source": "EMA-v1 + GRU", "mae": mae10, "status": "low" if mae10 < 8 else ("medium" if mae10 < 11 else "high")},
                {"horizon": "30s", "source": "EMA-v1", "mae": mae30, "status": "low" if mae30 < 12 else ("medium" if mae30 < 16 else "high")},
            ]

            # Live feed for AI Scheduler efficiency ring + Resource unsatisfied demand
            scheduler_efficiency = round(min(99.5, max(70, sched_granted / max(1, sched_offered) * 100)), 1)
            unsatisfied_mbps = round(max(0, sched_offered - sched_granted), 1)

            payload = {
                "ts": time.strftime("%H:%M:%S"),
                "total_cells": cells,
                "active_users": users,
                "network_load_pct": round(min(99.5, max(40, load)), 1),
                "avg_latency_ms": round(max(5, latency), 1),
                "congestion_level": cong,
                "qoe": round(0.82 + 0.08 * math.sin(t / 7) + random.uniform(-0.02, 0.02), 3),
                "fairness": round(0.78 + 0.04 * math.sin(t / 9), 3),
                "throughput_mbps": round(980 + 80 * math.sin(t / 4) + random.uniform(-20, 20), 1),
                "packet_loss_pct": round(max(0.05, 0.4 + 0.3 * math.sin(t / 6) + random.uniform(-0.1, 0.1)), 2),
                "events_pending": events_pending,
                "cell_loads": [round(40 + 50 * abs(math.sin(t / 3 + i * 0.4)) + random.uniform(-5, 5), 1) for i in range(12)],
                "top_cells": [{"id": f"Cell {i+1}", "load": round(55 + 35 * abs(math.sin(t / 2 + i)), 0)} for i in range(5)],
                "scheduler": {
                    "tasks": 1240 + int(30 * math.sin(t / 5)),
                    "success_rate": round(96 + 2.5 * math.sin(t / 8), 1),
                    "avg_time_ms": round(18 + 6 * math.sin(t / 4), 1)
                },
                "link_loads": link_loads,
                "node_metrics": node_metrics,
                "scheduler_point": {"granted": sched_granted, "offered": sched_offered},
                "forecast_point": forecast_point,
                "drift_point": drift_point,
                "alloc_breakdown": alloc_breakdown,
                "alloc_bars": alloc_bars,
                "links_active": links_active,
                "avg_hop_latency_ms": avg_hop_latency,
                "forecast_5s": fc5, "forecast_10s": fc10, "forecast_30s": fc30,
                "predictor_status": predictor_status,
                "scheduler_efficiency": scheduler_efficiency,
                "unsatisfied_mbps": unsatisfied_mbps,
                "new_event": new_event,
            }
            self.send(200, json.dumps(payload), "application/json")
        elif path == "/api/events":
            self.send(200, json.dumps({"events": EVENTS, "pending": sum(1 for e in EVENTS if e["status"] == "pending")}), "application/json")
        elif path == "/api/reports":
            import time
            reports = [
                {"id": "policy-comparison", "name": "Policy Comparison (M10)", "type": "Analytics", "period": "Last 60 ticks"},
                {"id": "qoe-summary", "name": "QoE Summary", "type": "Performance", "period": "24h"},
                {"id": "fairness-index", "name": "Fairness Index Report", "type": "Analytics", "period": "7d"},
                {"id": "congestion-forecast", "name": "Congestion Forecast Log", "type": "Prediction", "period": "Realtime"},
                {"id": "resource-audit", "name": "Resource Allocation Audit", "type": "Compliance", "period": "30d"},
            ]
            self.send(200, json.dumps({"reports": reports, "generated_total": 24 + len(AUDIT_LOGS), "last_export": time.strftime("%H:%M:%S")}), "application/json")
        elif path.startswith("/api/reports/") and path.endswith("/download"):
            import time
            rid = path.split("/")[3]
            cfg = get_config()
            dash = {}
            if DATA.exists():
                try:
                    dash = json.loads(DATA.read_text(encoding="utf-8"))
                except Exception:
                    dash = {}
            report = {
                "report_id": rid,
                "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "active_config": cfg,
                "recent_audit_log": AUDIT_LOGS[:15],
                "source_snapshot": {k: dash[k] for k in list(dash.keys())[:20]} if isinstance(dash, dict) else dash,
                "event_backlog": EVENTS,
            }
            self.send(200, json.dumps(report, indent=2, default=str), "application/json")
        elif path in ("/", "/index.html"):
            self.send(200, INDEX.read_bytes())
        else:
            # Check for other frontend assets if any
            target = ROOT / "M09_Dashboard" / "frontend" / path.lstrip("/")
            if target.is_file():
                ext = target.suffix.lower()
                ctype = "application/javascript" if ext == ".js" else ("text/css" if ext == ".css" else "application/octet-stream")
                self.send(200, target.read_bytes(), ctype)
            else:
                self.send(404, "Not found")

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length > 0 else b"{}"
        try:
            payload = json.loads(body) if body else {}
        except Exception:
            payload = {}

        if path == "/api/admin/whatif":
            try:
                sys.path.insert(0, str(ROOT))
                sys.path.insert(0, str(ROOT / "M10_Analytics"))
                from M10_Analytics.what_if_simulation import WhatIfConfig, run_what_if
                from M10_Analytics.comparison import TickInput

                trace_file = ROOT / "datasets" / "sample_trace.json"
                if not trace_file.exists():
                    self.send(500, json.dumps({"error": "sample_trace.json not found"}), "application/json")
                    return

                raw_trace = json.loads(trace_file.read_text(encoding="utf-8"))
                inputs = [
                    TickInput(
                        tick=int(x["tick"]),
                        cell_id=str(x["cell_id"]),
                        capacity_mbps=float(x["capacity_mbps"]),
                        demands_mbps={str(k): float(v) for k, v in x["demands_mbps"].items()},
                        state=dict(x.get("state", {})),
                    )
                    for x in raw_trace[:30]
                ]

                cfg = WhatIfConfig(
                    users_multiplier=float(payload.get("users_multiplier", 1.0)),
                    arrivals_multiplier=float(payload.get("arrivals_multiplier", 1.0)),
                    capacity_multiplier=float(payload.get("capacity_multiplier", 1.0)),
                    forced_failure_cells=tuple(payload.get("forced_failure_cells", [])),
                    seed=int(payload.get("seed", 42)),
                )
                res = run_what_if(inputs, cfg)
                import time
                ts_str = time.strftime("%H:%M:%S")
                AUDIT_LOGS.insert(0, {
                    "ts": ts_str,
                    "module": "M10_WhatIf_Engine",
                    "level": "INFO",
                    "msg": f"What-If run: users={cfg.users_multiplier}x, arr={cfg.arrivals_multiplier}x, cap={cfg.capacity_multiplier}x, failures={list(cfg.forced_failure_cells)}"
                })
                if len(AUDIT_LOGS) > 50:
                    AUDIT_LOGS.pop()
                self.send(200, json.dumps(res, default=str), "application/json")
            except Exception as e:
                self.send(500, json.dumps({"error": str(e)}), "application/json")

        elif path == "/api/events/action":
            try:
                import time
                eid = payload.get("id")
                action = payload.get("action")
                status = {"approve": "approved", "reject": "rejected"}.get(action)
                found = None
                if status:
                    for e in EVENTS:
                        if e["id"] == eid:
                            e["status"] = status
                            found = e
                            break
                if found:
                    AUDIT_LOGS.insert(0, {
                        "ts": time.strftime("%H:%M:%S"), "module": "M09_Events",
                        "level": "INFO", "msg": f"Event {eid} ({found['title']}) {status} by admin."
                    })
                    self.send(200, json.dumps({"status": "ok", "event": found, "pending": sum(1 for e in EVENTS if e['status']=='pending')}), "application/json")
                else:
                    self.send(404, json.dumps({"error": "event not found or invalid action"}), "application/json")
            except Exception as e:
                self.send(500, json.dumps({"error": str(e)}), "application/json")

        elif path == "/api/events/create":
            try:
                import time
                ev = {
                    "id": _next_event_id(),
                    "title": payload.get("title", "New Request") or "New Request",
                    "priority": payload.get("priority", "medium"),
                    "status": "pending",
                    "date": time.strftime("%Y-%m-%d"),
                }
                EVENTS.insert(0, ev)
                AUDIT_LOGS.insert(0, {
                    "ts": time.strftime("%H:%M:%S"), "module": "M09_Events",
                    "level": "INFO", "msg": f"New event request created: {ev['title']} ({ev['id']})."
                })
                self.send(200, json.dumps({"status": "ok", "event": ev, "pending": sum(1 for e in EVENTS if e['status']=='pending')}), "application/json")
            except Exception as e:
                self.send(500, json.dumps({"error": str(e)}), "application/json")

        elif path == "/api/admin/config":
            try:
                curr = get_config()
                curr.update(payload)
                save_config(curr)
                import time
                ts_str = time.strftime("%H:%M:%S")
                AUDIT_LOGS.insert(0, {
                    "ts": ts_str,
                    "module": "M09_Admin_Panel",
                    "level": "INFO",
                    "msg": f"Admin updated configuration: {list(payload.keys())}"
                })
                self.send(200, json.dumps({"status": "ok", "config": curr}), "application/json")
            except Exception as e:
                self.send(500, json.dumps({"error": str(e)}), "application/json")

        elif path == "/api/admin/rerun":
            try:
                cmd = [sys.executable, str(ROOT / "integration.py"), "--no-serve"]
                ticks = payload.get("ticks", 0)
                if ticks and int(ticks) > 0:
                    cmd.extend(["--ticks", str(ticks)])
                res = subprocess.run(cmd, capture_output=True, text=True, check=True)
                import time
                ts_str = time.strftime("%H:%M:%S")
                AUDIT_LOGS.insert(0, {
                    "ts": ts_str,
                    "module": "M09_Integration",
                    "level": "INFO",
                    "msg": "Integration pipeline re-executed. Telemetry refreshed."
                })
                self.send(200, json.dumps({"status": "ok", "output": res.stdout}), "application/json")
            except Exception as e:
                self.send(500, json.dumps({"error": str(e)}), "application/json")

        elif path == "/api/admin/login":
            user = payload.get("username", "").strip()
            pwd = payload.get("password", "").strip()
            import time
            ts_str = time.strftime("%H:%M:%S")
            if user == "admin" and pwd == "admin":
                AUDIT_LOGS.insert(0, {
                    "ts": ts_str,
                    "module": "SECURITY_AUTH",
                    "level": "INFO",
                    "msg": "Admin user authenticated successfully. Clearance Level 4 granted."
                })
                if len(AUDIT_LOGS) > 50: AUDIT_LOGS.pop()
                self.send(200, json.dumps({
                    "status": "ok",
                    "token": "nexus-admin-token-authenticated",
                    "user": "admin",
                    "role": "Super Administrator"
                }), "application/json")
            else:
                AUDIT_LOGS.insert(0, {
                    "ts": ts_str,
                    "module": "SECURITY_AUTH",
                    "level": "ALERT",
                    "msg": f"Failed admin login attempt for user '{user}'. Access denied."
                })
                if len(AUDIT_LOGS) > 50: AUDIT_LOGS.pop()
                self.send(401, json.dumps({
                    "error": "Invalid administrative credentials. Access denied."
                }), "application/json")


        elif path == "/api/admin/log":
            try:
                import time
                entry = {
                    "ts": time.strftime("%H:%M:%S"),
                    "module": payload.get("module", "ADMIN"),
                    "level": payload.get("level", "INFO"),
                    "msg": payload.get("msg", "Action performed.")
                }
                AUDIT_LOGS.insert(0, entry)
                if len(AUDIT_LOGS) > 50: AUDIT_LOGS.pop()
                self.send(200, json.dumps({"status": "ok"}), "application/json")
            except Exception as e:
                self.send(500, json.dumps({"error": str(e)}), "application/json")

        else:
            self.send(404, "Endpoint not found")

    def log_message(self, fmt, *args):
        # Silent or concise logging
        pass


def free_port(start=8080):
    for port in range(start,start+20):
        with socket.socket() as s:
            try: s.bind(("127.0.0.1",port)); return port
            except OSError: continue
    raise OSError("No free local port found in 8080-8099")

def start_server(port: int | None = None, open_browser: bool = True):
    if port is None:
        port = free_port()
    url = f"http://127.0.0.1:{port}"
    s = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print("\n" + "=" * 54)
    print("  [NEXUS] 3D GeoMap Dashboard running at:")
    print(f"     --> {url} <--")
    print("  Keep this terminal open. Press Ctrl+C to stop.")
    print("=" * 54 + "\n")
    if open_browser:
        import webbrowser
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        s.serve_forever()
    except KeyboardInterrupt:
        print("\nDashboard stopped.")
    finally:
        s.server_close()

if __name__=="__main__":
    if not DATA.exists():
        subprocess.run([sys.executable,str(ROOT/"integration.py"),"--no-serve"],check=True)
    start_server(open_browser=True)
