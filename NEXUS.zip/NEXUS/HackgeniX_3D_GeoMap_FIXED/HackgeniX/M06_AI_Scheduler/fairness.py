def jain_fairness(values):
    values = [max(0.0, float(v)) for v in values]

    if not values:
        return 1.0

    total = sum(values)
    square_sum = sum(v * v for v in values)

    if square_sum == 0:
        return 1.0

    n = len(values)

    return (total * total) / (n * square_sum)