import pytest
from shared.schemas import CellObservation, TickMetrics
from M10_Analytics.baseline_schedulers import allocate,POLICIES
from M10_Analytics.comparison import compare,trace_hash
from M10_Analytics.what_if_simulation import apply_changes,WhatIf

def test_capacity_all_policies():
    obs=CellObservation('A',10,{'voice':8,'video':9,'bulk':15},min_mbps={'voice':8,'video':8,'bulk':8})
    for policy in POLICIES:
        d=allocate(obs,policy)
        assert sum(d.granted_mbps.values()) <= 10+1e-8
        assert all(x>=0 for x in d.granted_mbps.values())
        assert d.unsatisfied_minimums

def test_empty_zero_capacity():
    for policy in POLICIES:
        assert sum(allocate(CellObservation('A',0,{'a':4}),policy).granted_mbps.values()) == 0

def test_whatif_isolated():
    trace={'ticks':[{'cells':{'a':{'capacity_mbps':100,'arrivals_mbits':30}}}]}
    changed=apply_changes(trace,WhatIf(capacity_multiplier=.5,arrival_multiplier=2))
    assert trace['ticks'][0]['cells']['a']['capacity_mbps']==100
    assert changed['ticks'][0]['cells']['a']=={'capacity_mbps':50,'arrivals_mbits':60}
    with pytest.raises(ValueError): apply_changes(trace,WhatIf(user_multiplier=2))

def test_paired_trace():
    class Adapter:
        def run(self,trace,policy,seed):
            return [TickMetrics(0,'a',12,9,10,3,0,qoe_proxy=.6)]
    results=compare(Adapter(),{'seed':42},42,'demo')
    assert len(results)==4
    assert len({r.trace_id for r in results})==1
    assert all(r.metrics['delivered_mbps_mean']==9 for r in results)

def test_no_invented_data():
    class Empty:
        def run(self,**kwargs): return []
    with pytest.raises(ValueError): compare(Empty(),{},42,'demo')
