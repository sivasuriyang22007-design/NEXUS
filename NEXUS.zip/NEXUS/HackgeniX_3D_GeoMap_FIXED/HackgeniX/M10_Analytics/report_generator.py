"""Truthful CSV/JSON/PDF analytics reports for NEXUS comparisons."""
from __future__ import annotations

from pathlib import Path
import csv
import json
from typing import Any, Mapping, Sequence

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet
except Exception:
    SimpleDocTemplate = None


def _json_default(obj: Any):
    if hasattr(obj, "__dict__"):
        return obj.__dict__
    raise TypeError(f"Not JSON serializable: {type(obj)!r}")


def export_json(result: Mapping[str, Any], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2, default=_json_default), encoding="utf-8")
    return path


def export_summary_csv(result: Mapping[str, Any], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    policies = result.get("policies", {})
    rows = []
    for policy, data in policies.items():
        summary = data.get("summary", {})
        rows.append({"policy": policy, **summary})
    if not rows:
        path.write_text("", encoding="utf-8")
        return path

    keys = sorted({k for row in rows for k in row.keys()})
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
    return path


def export_pdf(result: Mapping[str, Any], path: str | Path, title: str = "NEXUS Analytics Report") -> Path:
    if SimpleDocTemplate is None:
        raise RuntimeError("PDF export requires reportlab")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(str(path), pagesize=A4)
    styles = getSampleStyleSheet()
    story = [
        Paragraph(title, styles["Title"]),
        Paragraph(
            "NEXUS Module 10 report. Values are computed from supplied simulation/comparison data; "
            "forecasts and what-if results are not presented as measured production outcomes.",
            styles["BodyText"],
        ),
        Spacer(1, 12),
    ]

    rows = [["Policy", "Mean offered", "Mean granted", "Utilization", "Unsatisfied", "Jain fairness"]]
    for policy, data in result.get("policies", {}).items():
        s = data.get("summary", {})
        rows.append([
            policy,
            f"{s.get('mean_offered_mbps', 0):.3f}",
            f"{s.get('mean_granted_mbps', 0):.3f}",
            f"{s.get('mean_utilization', 0):.3f}",
            f"{s.get('mean_unsatisfied_mbps', 0):.3f}",
            f"{s.get('mean_jain_fairness', 0):.3f}",
        ])

    table = Table(rows, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
    ]))
    story.append(table)
    story.append(Spacer(1, 12))
    story.append(Paragraph(
        f"Trace ticks: {result.get('trace_ticks', 'n/a')} | Seed: {result.get('seed', 'n/a')} | "
        "Same trace/capacity inputs: "
        f"{result.get('comparison_contract', {}).get('same_trace', False)}",
        styles["BodyText"],
    ))
    doc.build(story)
    return path


def plot_policy_summary(result: Mapping[str, Any], path: str | Path) -> Path:
    """Optional chart for a report; no chart is generated if matplotlib is unavailable."""
    if plt is None:
        raise RuntimeError("Chart export requires matplotlib")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    policies = list(result.get("policies", {}).keys())
    values = [
        result["policies"][p]["summary"].get("mean_granted_mbps", 0.0)
        for p in policies
    ]
    fig, ax = plt.subplots(figsize=(9, 4.8))
    ax.bar(policies, values)
    ax.set_ylabel("Mean granted rate (Mbps)")
    ax.set_title("Computed comparison: mean granted throughput")
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return path


def export_report_bundle(result: Mapping[str, Any], output_dir: str | Path) -> dict[str, str]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "json": export_json(result, output_dir / "comparison.json"),
        "csv": export_summary_csv(result, output_dir / "comparison_summary.csv"),
        "pdf": export_pdf(result, output_dir / "comparison_report.pdf"),
    }
    if plt is not None:
        paths["chart"] = plot_policy_summary(result, output_dir / "comparison_granted_throughput.png")
    return {k: str(v) for k, v in paths.items()}
