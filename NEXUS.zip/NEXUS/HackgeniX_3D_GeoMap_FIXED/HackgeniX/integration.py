"""
NEXUS integration layer.

This file is additive: it composes M01-M10 public APIs into one reproducible
pipeline, produces JSON consumed by the M09 dashboard, and launches the
interactive 3D GeoMap dashboard in your browser.

Run:
    python integration.py                 # Runs pipeline & launches dashboard in browser
    python integration.py --no-serve      # Generates data only without starting server
    python integration.py --port 8085     # Specifies custom dashboard port
    python integration.py --ticks 30 --seed 42
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
for module_dir in (
    "M01_Virtual_Users", "M02_Traffic_Generator", "M03_Traffic_Classifier",
    "M04_SimPy_Network", "M05_Congestion_Predictor", "M06_AI_Scheduler",
    "M07_QoE_Monitor", "M08_Priority_System", "M09_Dashboard",
    "M09_Dashboard/backend", "M10_Analytics",
):
    sys.path.insert(0, str(ROOT / module_dir))
sys.path.insert(0, str(ROOT))

from M10_Analytics.comparison import TickInput, compare_policies
from M05_Congestion_Predictor.load_monitor import LoadSample
from M05_Congestion_Predictor.predictor import CongestionPredictor
from M07_QoE_Monitor.qoe_calculator import calculate_activity_qoe, jain_index
from M07_QoE_Monitor.metrics_collector import MetricRecord, MetricsCollector


def load_trace(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        rows = json.load(f)
    if not isinstance(rows, list) or not rows:
        raise ValueError("Trace must be a non-empty JSON list")
    return rows


def _round_dict(d: dict[str, Any], digits: int = 3) -> dict[str, Any]:
    out = {}
    for k, v in d.items():
        out[k] = round(v, digits) if isinstance(v, (int, float)) else v
    return out


def build_dashboard_data(trace: list[dict[str, Any]], seed: int = 42) -> dict[str, Any]:
    trace = trace[:]
    inputs = [
        TickInput(
            tick=int(x["tick"]),
            cell_id=str(x["cell_id"]),
            capacity_mbps=float(x["capacity_mbps"]),
            demands_mbps={str(k): float(v) for k, v in x["demands_mbps"].items()},
            state=dict(x.get("state", {})),
        )
        for x in trace
    ]

    comparison = compare_policies(inputs, seed=seed)
    # Keep the raw trace small and use the weighted-fair policy as the
    # dashboard's live allocation stream. All policy summaries remain visible.
    wf_outcomes = comparison["policies"]["weighted_fair"]["outcomes"]

    monitor = CongestionPredictor(history_length=min(30, max(1, len(inputs))))
    history: list[LoadSample] = []
    forecast_rows = []
    for x in inputs:
        offered = sum(x.demands_mbps.values())
        capacity = x.capacity_mbps
        delivered = min(offered, capacity)
        history.append(
            LoadSample(
                time_s=float(x.tick),
                offered_mbps=offered,
                delivered_mbps=delivered,
                queue_mbits=max(0.0, offered - capacity),
                active_users=len(x.demands_mbps),
                active_sessions=len(x.demands_mbps),
                capacity_mbps=capacity,
            )
        )
        fc = monitor.predict(history, cell_id=x.cell_id, now_s=float(x.tick))
        forecast_rows.append({
            "tick": x.tick,
            "cell_id": x.cell_id,
            "predicted_demand_mbps": _round_dict(fc.predicted_demand_mbps),
            "expected_utilization": _round_dict(fc.expected_utilization),
            "source": fc.predictor_source,
            "error": fc.error_state,
        })

    collector = MetricsCollector()
    allocation_rows = []
    qoe_values = []
    fairness_values = []
    for outcome in wf_outcomes:
        demands = outcome.grants_mbps
        fairness = jain_index(list(demands.values()))
        fairness_values.append(fairness)
        for user_id, granted in demands.items():
            requested = float(outcome.capacity_mbps if user_id not in inputs[outcome.tick].demands_mbps
                              else inputs[outcome.tick].demands_mbps[user_id])
            offered = max(0.0, requested)
            loss = max(0.0, offered - granted) / offered if offered else 0.0
            traffic_class = "streaming" if user_id == "u1" else ("interactive" if user_id == "u2" else "download")
            if traffic_class == "streaming":
                q = calculate_activity_qoe(traffic_class, {
                    "delivered_mbps": granted, "target_mbps": max(requested, 1.0),
                    "stall_probability": loss, "startup_delay_ms": loss * 1000,
                })["qoe"]
            elif traffic_class == "interactive":
                q = calculate_activity_qoe(traffic_class, {
                    "latency_ms": 20 + loss * 150, "jitter_ms": loss * 30,
                    "loss_fraction": loss,
                })["qoe"]
            else:
                q = calculate_activity_qoe(traffic_class, {
                    "completion_time_s": 10 + loss * 50,
                    "target_completion_s": 10, "progress_ratio": min(1, granted / max(requested, 1.0)),
                })["qoe"]
            qoe_values.append(q)
            collector.add(MetricRecord(
                timestamp=float(outcome.tick), user_id=user_id,
                cell_id=outcome.cell_id, traffic_class=traffic_class,
                latency_ms=20 + loss * 150, loss_fraction=loss,
                delivered_mbps=granted, offered_mbps=offered, qoe=q,
                backlog_bytes=max(0.0, (offered - granted) * 125000),
                sla_violated=(q < 0.70),
            ))
        allocation_rows.append({
            "tick": outcome.tick,
            "capacity_mbps": outcome.capacity_mbps,
            "offered_mbps": round(outcome.offered_mbps, 3),
            "granted_mbps": round(outcome.granted_mbps, 3),
            "utilization_pct": round(100 * outcome.granted_mbps / outcome.capacity_mbps, 2)
                if outcome.capacity_mbps else 0,
            "unsatisfied_mbps": round(outcome.unsatisfied_mbps, 3),
            "grants_mbps": _round_dict(outcome.grants_mbps),
            "jain_fairness": round(fairness, 4),
        })

    policy_summaries = {}
    for name, payload in comparison["policies"].items():
        policy_summaries[name] = payload["summary"]

    return {
        "meta": {
            "name": "NEXUS Integrated Network Intelligence",
            "version": "integration-v1.0",
            "seed": seed,
            "ticks": len(inputs),
            "trace_contract": comparison["comparison_contract"],
        },
        "kpis": {
            "mean_offered_mbps": round(sum(sum(x.demands_mbps.values()) for x in inputs) / len(inputs), 3),
            "mean_granted_mbps": round(sum(x.granted_mbps for x in wf_outcomes) / len(wf_outcomes), 3),
            "mean_utilization_pct": round(100 * sum(x.granted_mbps / x.capacity_mbps for x in wf_outcomes) / len(wf_outcomes), 2),
            "mean_qoe": round(sum(qoe_values) / len(qoe_values), 4) if qoe_values else 0,
            "mean_jain_fairness": round(sum(fairness_values) / len(fairness_values), 4) if fairness_values else 1,
            "sla_rate": round(collector.sla_rate(), 4),
            "data_quality": collector.data_quality_report(),
        },
        "allocations": allocation_rows,
        "forecasts": forecast_rows,
        "policy_summaries": policy_summaries,
        "modules": {
            "M01": "virtual users (trace input)",
            "M02": "traffic generator (trace-compatible input)",
            "M03": "traffic classifier (optional artifact-backed)",
            "M04": "SimPy network (available for live simulation)",
            "M05": "congestion predictor",
            "M06": "AI scheduler / safety allocation",
            "M07": "QoE and SLA monitoring",
            "M08": "priority-system extension point",
            "M09": "dashboard",
            "M10": "policy analytics",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the additive NEXUS integration pipeline")
    parser.add_argument("--trace", default="datasets/sample_trace.json")
    parser.add_argument("--ticks", type=int, default=0, help="0 = all ticks")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="M09_Dashboard/backend/dashboard_data.json")
    parser.add_argument("--serve", dest="serve", action="store_true", default=True, help="Serve the dashboard in browser (default: True)")
    parser.add_argument("--no-serve", dest="serve", action="store_false", help="Only generate dataset without starting server")
    parser.add_argument("--port", type=int, default=None, help="Custom port for dashboard server")
    parser.add_argument("--no-browser", action="store_true", help="Do not automatically open browser")
    args = parser.parse_args()

    trace = load_trace(ROOT / args.trace)
    if args.ticks > 0:
        trace = trace[:args.ticks]
    data = build_dashboard_data(trace, seed=args.seed)
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"Integration complete: {output}")
    print(json.dumps(data["kpis"], indent=2))

    if args.serve:
        from M09_Dashboard.backend.server import start_server
        start_server(port=args.port, open_browser=not args.no_browser)


if __name__ == "__main__":
    main()
