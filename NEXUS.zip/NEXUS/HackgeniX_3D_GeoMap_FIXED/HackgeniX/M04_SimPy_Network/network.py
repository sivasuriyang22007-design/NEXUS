# M04_SimPy_Network/network.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

from .cell import Cell
from .network_link import NetworkLink
from .router import Router


@dataclass
class NetworkConfig:

    propagation_delay_ms: float = 5.0
    queue_bytes: int = 10_000_000
    loss_probability: float = 0.0


class Network:

    def __init__(
        self,
        env,
        config: NetworkConfig | None = None,
        seed: int = 42,
    ):

        self.env = env

        self.config = (
            config
            if config is not None
            else NetworkConfig()
        )

        self.seed = seed

        self.cells: Dict[str, Cell] = {}
        self.links: Dict[str, NetworkLink] = {}

        self.router = Router()

    # ---------------------------------------------------------
    # Cells
    # ---------------------------------------------------------

    def add_cell(
        self,
        cell_id: str,
        capacity_mbps: float,
        usable_mbps: float | None = None,
        link_efficiency: float = 1.0,
    ) -> Cell:

        if cell_id in self.cells:
            raise ValueError(
                f"Cell {cell_id} already exists"
            )

        cell = Cell(
            env=self.env,
            cell_id=cell_id,
            total_mbps=capacity_mbps,
            usable_mbps=usable_mbps,
            link_efficiency=link_efficiency,
        )

        self.cells[cell_id] = cell

        return cell

    # ---------------------------------------------------------
    # Links
    # ---------------------------------------------------------

    def add_link(
        self,
        link_id: str,
        capacity_mbps: float,
        propagation_delay_ms: float | None = None,
        queue_bytes: int | None = None,
        loss_probability: float | None = None,
    ) -> NetworkLink:

        if link_id in self.links:
            raise ValueError(
                f"Link {link_id} already exists"
            )

        link = NetworkLink(
            env=self.env,
            link_id=link_id,
            capacity_mbps=capacity_mbps,
            propagation_delay_ms=(
                propagation_delay_ms
                if propagation_delay_ms is not None
                else self.config.propagation_delay_ms
            ),
            queue_bytes=(
                queue_bytes
                if queue_bytes is not None
                else self.config.queue_bytes
            ),
            loss_probability=(
                loss_probability
                if loss_probability is not None
                else self.config.loss_probability
            ),
            seed=self.seed,
        )

        self.links[link_id] = link

        return link

    # ---------------------------------------------------------
    # Routing
    # ---------------------------------------------------------

    def add_route(
        self,
        source_cell: str,
        destination: str,
        next_hop: str,
        link_id: str,
    ):

        if link_id not in self.links:
            raise ValueError(
                f"Unknown link: {link_id}"
            )

        self.router.add_route(
            source=source_cell,
            destination=destination,
            next_hop=next_hop,
            link_id=link_id,
        )

    def get_link_for_flow(
        self,
        source_cell: str,
        destination: str,
    ) -> Optional[NetworkLink]:

        link_id = self.router.route_packet(
            source_cell,
            destination,
        )

        if link_id is None:
            return None

        return self.links.get(link_id)

    # ---------------------------------------------------------
    # Packet injection
    # ---------------------------------------------------------

    def send_packet(
        self,
        packet,
        source_cell: str,
        destination: str = "internet",
    ) -> bool:

        link = self.get_link_for_flow(
            source_cell,
            destination,
        )

        if link is None:

            # Direct fallback for single-cell demo.
            if len(self.links) == 1:
                link = next(
                    iter(self.links.values())
                )
            else:
                return False

        return link.put(
            packet,
            current_time=self.env.now,
        )

    # ---------------------------------------------------------
    # Network metrics
    # ---------------------------------------------------------

    def snapshot(self) -> dict:

        return {
            "time_seconds": self.env.now,

            "cells": {
                cell_id: cell.snapshot()
                for cell_id, cell in self.cells.items()
            },

            "links": {
                link_id: link.snapshot()
                for link_id, link in self.links.items()
            },
        }

    def total_offered_bits(self) -> int:

        return sum(
            link.total_offered_bits
            for link in self.links.values()
        )

    def total_delivered_bits(self) -> int:

        return sum(
            link.total_delivered_bits
            for link in self.links.values()
        )

    def total_dropped_bits(self) -> int:

        return sum(
            link.total_dropped_bits
            for link in self.links.values()
        )