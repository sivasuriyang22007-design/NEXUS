# M04_SimPy_Network/router.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class Route:

    source: str
    destination: str
    next_hop: str
    link_id: str


class Router:
    """
    Simple deterministic router.

    M04 currently uses a direct cell -> link -> destination model.
    It can later be extended to multi-hop topology.
    """

    def __init__(self):

        self.routes: Dict[
            tuple[str, str],
            Route
        ] = {}

    def add_route(
        self,
        source: str,
        destination: str,
        next_hop: str,
        link_id: str,
    ):

        route = Route(
            source=source,
            destination=destination,
            next_hop=next_hop,
            link_id=link_id,
        )

        self.routes[
            (source, destination)
        ] = route

    def get_route(
        self,
        source: str,
        destination: str,
    ) -> Optional[Route]:

        return self.routes.get(
            (source, destination)
        )

    def remove_route(
        self,
        source: str,
        destination: str,
    ):

        self.routes.pop(
            (source, destination),
            None,
        )

    def route_packet(
        self,
        source: str,
        destination: str,
    ) -> Optional[str]:

        route = self.get_route(
            source,
            destination,
        )

        if route is None:
            return None

        return route.link_id