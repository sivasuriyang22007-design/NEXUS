"""NEXUS Module 10 standalone demo/analytics runner.

Input format for --trace:
JSON list of records:
[
  {
    "tick": 0,
    "cell_id": "cell-1",
    "capacity_mbps": 100,
    "demands_mbps": {"u1": 20, "u2": 50},
    "state": {"weights": {"u1": 2, "u2": 1}, "qos_weights": {"u1": 3, "u2": 1}}
  }
]
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from M10_Analytics.comparison import TickInput, compare_policies
from M10_Analytics.what_if_simulation import WhatIfConfig, run_what_if
from M10_Analytics.report_generator import export_report_bundle


def load_trace(path: str | None) -> list[TickInput]:
    if path:
        records = json.loads(Path(path).read_text(encoding="utf-8"))
    else:
        records = [
            {
                "tick": t,
                "cell_id": "cell-1",
                "capacity_mbps": 100.0,
                "demands_mbps": {"u1": 70.0 + (t % 3) * 5, "u2": 45.0, "u3": 15.0},
                "state": {
                    "weights": {"u1": 2.0, "u2": 1.0, "u3": 1.0},
                    "qos_weights": {"u1": 3.0, "u2": 1.0, "u3": 1.0},
                },
            }
            for t in range(60)
        ]
    return [
        TickInput(
            tick=int(r["tick"]),
            cell_id=str(r["cell_id"]),
            capacity_mbps=float(r["capacity_mbps"]),
            demands_mbps={str(k): float(v) for k, v in r["demands_mbps"].items()},
            state=dict(r.get("state", {})),
        )
        for r in records
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description="NEXUS M10 Analytics")
    parser.add_argument("--trace", help="JSON trace path")
    parser.add_argument("--out", default="reports/m10_demo")
    parser.add_argument("--what-if", action="store_true")
    parser.add_argument("--capacity-multiplier", type=float, default=1.0)
    parser.add_argument("--arrivals-multiplier", type=float, default=1.0)
    parser.add_argument("--failure-cell", action="append", default=[])
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    trace = load_trace(args.trace)
    if args.what_if:
        result = run_what_if(
            trace,
            WhatIfConfig(
                capacity_multiplier=args.capacity_multiplier,
                arrivals_multiplier=args.arrivals_multiplier,
                forced_failure_cells=tuple(args.failure_cell),
                seed=args.seed,
            ),
        )
    else:
        result = compare_policies(trace, seed=args.seed)

    paths = export_report_bundle(result, args.out)
    print(json.dumps({"status": "ok", "reports": paths}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
