"""Per-cell 5/10/30 s forecasts, baseline first and safe GRU fallback."""
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import math
import time
import joblib
import numpy as np
from .load_monitor import LoadSample
from .gru_model import GRUForecaster, FEATURES, HORIZONS

@dataclass
class Forecast:
    cell_id: str
    predicted_demand_mbps: dict
    lower_mbps: dict
    upper_mbps: dict
    expected_utilization: dict
    overload_probability: dict
    model_version: str
    predictor_source: str
    used_fallback: bool
    freshness_s: float
    error_state: str | None

    def to_dict(self):
        return asdict(self)

class CongestionPredictor:
    def __init__(self, artifact_dir=None, history_length=30, max_age_s=5,
                 timeout_ms=50, ema_alpha=0.3, use_gru=False):
        self.history_length = history_length
        self.max_age_s = max_age_s
        self.timeout_ms = timeout_ms
        self.ema_alpha = ema_alpha
        self.model = None
        self.scaler = None
        self.version = "ema-v1"
        self.residual_mae = 0.0
        self.gru_enabled = use_gru
        if use_gru and artifact_dir:
            try:
                import torch
                folder = Path(artifact_dir)
                meta = json.loads((folder / "metrics.json").read_text())
                self.scaler = joblib.load(folder / "scaler.joblib")
                self.model = GRUForecaster(**meta["model_config"])
                self.model.load_state_dict(torch.load(folder / "weights.pt", map_location="cpu", weights_only=True))
                self.model.eval()
                self.version = meta["model_version"]
                self.residual_mae = float(meta.get("validation_mae_mbps", 0.0))
                if not meta.get("gru_passed_gate", False):
                    self.model = None
            except (OSError, ValueError, KeyError, RuntimeError, ImportError):
                self.model = None

    def predict(self, history, known_future_events=None, cell_id="cell-1", now_s=None):
        """Events: [{time_s, cell_id, demand_delta_mbps, capacity_mbps?}].
        Only events supplied as known at prediction time may be used.
        """
        history = list(history)
        now_s = history[-1].time_s if now_s is None and history else (now_s or 0.0)
        events = known_future_events or []
        valid = bool(history) and all(isinstance(s, LoadSample) for s in history)
        if valid:
            valid = all(a.time_s < b.time_s for a, b in zip(history, history[1:]))
            valid = valid and history[-1].time_s <= now_s
        age = max(0.0, now_s - history[-1].time_s) if valid else float("inf")
        stale = not valid or age > self.max_age_s
        if valid:
            demand = np.array([s.offered_mbps for s in history], dtype=float)
            ema = demand[0]
            for value in demand[1:]:
                ema = self.ema_alpha * value + (1-self.ema_alpha)*ema
            baseline = float(ema)
            cap = history[-1].capacity_mbps
            residual = float(np.mean(np.abs(np.diff(demand)))) if len(demand) > 1 else 0.0
        else:
            baseline, cap, residual = 0.0, 0.0, 0.0
        source = "ema" if valid else "unavailable"
        error = "stale_data" if stale and valid else ("missing_data" if not valid else None)
        predicted = np.repeat(baseline, 3)
        if self.gru_enabled and self.model is not None and not stale and len(history) >= self.history_length:
            try:
                import torch
                start = time.perf_counter()
                seq = history[-self.history_length:]
                x = np.array([[getattr(s, k) for k in FEATURES[:6]] + [0, s.capacity_mbps]
                              for s in seq], dtype=float)
                x = self.scaler.transform(x)
                with torch.no_grad():
                    predicted = self.model(torch.tensor(x[None], dtype=torch.float32)).numpy()[0]
                if (time.perf_counter()-start)*1000 > self.timeout_ms:
                    raise TimeoutError("inference_timeout")
                if not np.isfinite(predicted).all():
                    raise ValueError("invalid_inference")
                source = "gru"
            except (Exception) as exc:
                predicted = np.repeat(baseline, 3)
                error = "inference_timeout" if isinstance(exc, TimeoutError) else "model_error"
        elif self.gru_enabled and self.model is None and not stale:
            error = "model_unavailable_or_not_approved"
        if stale and valid:
            source = "persistence_stale"
            predicted = np.repeat(history[-1].offered_mbps, 3)
        out, low, high, util, prob = {}, {}, {}, {}, {}
        for i, horizon in enumerate(HORIZONS):
            target = now_s + horizon
            delta, future_cap = 0.0, cap
            for event in sorted(events, key=lambda e: e["time_s"]):
                if event.get("cell_id", cell_id) != cell_id or not now_s < event["time_s"] <= target:
                    continue
                delta += float(event.get("demand_delta_mbps", 0.0))
                if "capacity_mbps" in event:
                    future_cap = max(0.0, float(event["capacity_mbps"]))
            value = max(0.0, float(predicted[i]) + delta)
            width = 1.645 * max(residual, self.residual_mae) * math.sqrt(horizon / 5)
            out[horizon] = value
            low[horizon] = max(0.0, value - width)
            high[horizon] = value + width
            util[horizon] = value / future_cap if future_cap > 0 else (float("inf") if value > 0 else 0.0)
            prob[horizon] = None  # Uncalibrated: never invent overload probabilities.
        return Forecast(cell_id, out, low, high, util, prob,
                        self.version if source == "gru" else "baseline-v1",
                        source, source != "gru", age, error)
