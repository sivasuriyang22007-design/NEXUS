# user_generator.py

import json
import uuid
from pathlib import Path

import numpy as np

from user import User, Session, Scenario
from user_profiles import (
    load_profiles,
    validate_profile_mix,
    get_default_profiles
)
from user_mobility import update_user_mobility


# Stable namespace for deterministic UUID generation
NEXUS_NAMESPACE = uuid.UUID(
    "12345678-1234-5678-1234-567812345678"
)


def stable_uuid(name):
    """
    Generate deterministic UUID.

    Same name -> same UUID.
    """

    return str(
        uuid.uuid5(
            NEXUS_NAMESPACE,
            str(name)
        )
    )


def create_scenario(config, seed):
    """
    Create a reproducible scenario.

    Example config:

    {
        "name": "Morning Rush",
        "type": "rush_hour",
        "duration_seconds": 3600,
        "cells": ["CELL_1", "CELL_2"],
        "arrival_rate": 10
    }
    """

    scenario_type = config.get(
        "type",
        "rush_hour"
    )

    name = config.get(
        "name",
        scenario_type
    )

    duration = float(
        config.get(
            "duration_seconds",
            3600
        )
    )

    if duration <= 0:
        raise ValueError(
            "Scenario duration must be greater than zero"
        )

    cells = config.get(
        "cells",
        []
    )

    if not cells:
        raise ValueError(
            "Scenario must contain at least one cell"
        )

    arrival_rate = float(
        config.get(
            "arrival_rate",
            1.0
        )
    )

    if arrival_rate < 0:
        raise ValueError(
            "Arrival rate cannot be negative"
        )

    events = []

    # Explicit exogenous scenario schedules
    if scenario_type == "rush_hour":

        events = [
            {
                "time": 0,
                "event": "RUSH_START"
            },
            {
                "time": duration * 0.8,
                "event": "RUSH_END"
            }
        ]

    elif scenario_type == "flash_crowd":

        events = [
            {
                "time": duration * 0.2,
                "event": "FLASH_CROWD_START"
            },
            {
                "time": duration * 0.5,
                "event": "FLASH_CROWD_END"
            }
        ]

    elif scenario_type == "mass_event":

        events = [
            {
                "time": duration * 0.25,
                "event": "MASS_EVENT_START"
            },
            {
                "time": duration * 0.75,
                "event": "MASS_EVENT_END"
            }
        ]

    elif scenario_type == "outage":

        events = [
            {
                "time": duration * 0.4,
                "event": "OUTAGE_START"
            },
            {
                "time": duration * 0.6,
                "event": "OUTAGE_END"
            }
        ]

    elif scenario_type == "emergency":

        events = [
            {
                "time": duration * 0.3,
                "event": "EMERGENCY_START"
            },
            {
                "time": duration * 0.7,
                "event": "EMERGENCY_END"
            }
        ]

    elif scenario_type == "recovery":

        events = [
            {
                "time": duration * 0.5,
                "event": "RECOVERY_START"
            },
            {
                "time": duration,
                "event": "RECOVERY_END"
            }
        ]

    scenario_id = stable_uuid(
        f"{name}:{seed}"
    )

    scenario = Scenario(
        id=scenario_id,
        name=name,
        scenario_type=scenario_type,
        duration_seconds=duration,
        cells=list(cells),
        config=dict(config),
        seed=seed,
        exogenous_events=events
    )

    return scenario


def spawn_users(
    n,
    profile_mix,
    cells,
    rng,
    start_time=0.0,
    duration_seconds=3600
):
    """
    Generate n users efficiently using NumPy.

    Around 2000 users can be generated efficiently.
    """

    if n <= 0:
        raise ValueError(
            "Number of users must be greater than zero"
        )

    if not cells:
        raise ValueError(
            "At least one cell is required"
        )

    validate_profile_mix(profile_mix)

    profile_names = list(
        profile_mix.keys()
    )

    probabilities = np.array(
        list(profile_mix.values()),
        dtype=float
    )

    # Vectorized profile assignment
    selected_profiles = rng.choice(
        profile_names,
        size=n,
        p=probabilities
    )

    # Vectorized cell assignment
    selected_cells = rng.choice(
        cells,
        size=n
    )

    # Vectorized arrival times
    arrivals = rng.uniform(
        start_time,
        start_time + duration_seconds * 0.5,
        size=n
    )

    # Vectorized session durations
    durations = rng.uniform(
        30,
        duration_seconds * 0.5,
        size=n
    )

    departures = np.minimum(
        arrivals + durations,
        start_time + duration_seconds
    )

    # Vectorized user tiers
    tier_values = np.array([
        "STANDARD",
        "PREMIUM"
    ])

    tier_probability = [
        0.8,
        0.2
    ]

    tiers = rng.choice(
        tier_values,
        size=n,
        p=tier_probability
    )

    users = []

    for i in range(n):

        user_id = stable_uuid(
            f"user-{i}"
        )

        profile_id = selected_profiles[i]

        user = User(
            id=user_id,
            cell_id=str(selected_cells[i]),
            user_tier=str(tiers[i]),
            activity_id=profile_id,
            arrival_time=float(arrivals[i]),
            departure_time=float(departures[i]),
            priority_eligible=(
                profile_id == "voice"
            ),
            aging_counter=0,
            state="IDLE"
        )

        users.append(user)

    return users


def advance_user_sessions(
    tick,
    users,
    scenario,
    rng
):
    """
    Advance user state and generate session events.
    """

    events = []

    profiles = {
        profile.id: profile
        for profile in get_default_profiles()
    }

    for user in users:

        # User has not arrived yet
        if tick < user.arrival_time:
            user.state = "WAITING"
            continue

        # User has departed
        if tick >= user.departure_time:
            user.state = "DEPARTED"

            events.append({
                "event": "USER_DEPARTURE",
                "time": tick,
                "user_id": user.id,
                "cell_id": user.cell_id
            })

            continue

        # User is currently present
        user.state = "ACTIVE"

        # Check existing active session
        active_session = None

        for session in user.sessions:

            if session.is_active(tick):
                active_session = session
                break

        # Create a new session if required
        if active_session is None:

            profile = profiles.get(
                user.activity_id
            )

            if profile is None:
                continue

            session_id = stable_uuid(
                f"{user.id}-session-{len(user.sessions)}"
            )

            end_time = min(
                tick + profile.duration_seconds,
                user.departure_time
            )

            session = Session(
                id=session_id,
                user_id=user.id,
                start_time=tick,
                end_time=end_time,
                activity_id=user.activity_id,
                traffic_profile_id=profile.id,
                state="ACTIVE"
            )

            user.add_session(session)

            events.append({
                "event": "SESSION_START",
                "time": tick,
                "user_id": user.id,
                "session_id": session.id,
                "cell_id": user.cell_id,
                "traffic_profile": profile.id
            })

    # Mobility
    mobility_events = update_user_mobility(
        users=users,
        tick=tick,
        cells=scenario.cells,
        rng=rng,
        mobility_probability=scenario.config.get(
            "mobility_probability",
            0.1
        )
    )

    events.extend(mobility_events)

    return events


def export_arrival_trace(scenario):
    """
    Generate an immutable arrival trace.

    Returns:
        immutable trace_id
    """

    rng = np.random.default_rng(
        scenario.seed
    )

    arrival_rate = float(
        scenario.config.get(
            "arrival_rate",
            1.0
        )
    )

    if arrival_rate <= 0:
        raise ValueError(
            "Arrival rate must be greater than zero"
        )

    events = []

    current_time = 0.0

    user_index = 0

    while current_time < scenario.duration_seconds:

        interval = rng.exponential(
            1.0 / arrival_rate
        )

        current_time += interval

        if current_time >= scenario.duration_seconds:
            break

        cell = scenario.cells[
            rng.integers(
                0,
                len(scenario.cells)
            )
        ]

        events.append({
            "sequence": user_index,
            "time": round(
                float(current_time),
                6
            ),
            "cell_id": cell
        })

        user_index += 1

    # Convert to immutable tuple
    scenario.arrival_trace = tuple(
        (
            item["sequence"],
            item["time"],
            item["cell_id"]
        )
        for item in events
    )

    # Stable trace ID
    trace_text = json.dumps(
        scenario.arrival_trace,
        sort_keys=True
    )

    trace_id = stable_uuid(
        f"{scenario.id}:{trace_text}"
    )

    return trace_id


def save_scenario(
    scenario,
    path
):
    """
    Save scenario as JSON.
    """

    data = {
        "id": scenario.id,
        "name": scenario.name,
        "type": scenario.scenario_type,
        "duration_seconds": scenario.duration_seconds,
        "cells": scenario.cells,
        "config": scenario.config,
        "seed": scenario.seed,
        "exogenous_events": scenario.exogenous_events
    }

    with open(
        path,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            data,
            file,
            indent=4
        )


def load_scenario(path):
    """
    Load a scenario from JSON.
    """

    with open(
        path,
        "r",
        encoding="utf-8"
    ) as file:

        data = json.load(file)

    return create_scenario(
        data,
        seed=int(data["seed"])
    )


# ------------------------------------------------
# BASIC MODULE TEST
# ------------------------------------------------

if __name__ == "__main__":

    print("================================")
    print(" MODULE 1 - VIRTUAL USERS TEST")
    print("================================")

    # -------------------------------
    # 1. PROFILE TEST
    # -------------------------------

    print("\n1. PROFILE TEST")

    profiles = get_default_profiles()

    for profile in profiles:
        print(
            profile.id,
            "->",
            profile.target_mbps,
            "Mbps"
        )

    print("Profiles:", len(profiles))
    print("Profile Test: PASS")

    # -------------------------------
    # 2. PROFILE MIX TEST
    # -------------------------------

    print("\n2. PROFILE MIX TEST")

    profile_mix = {
        "voice": 0.20,
        "video": 0.30,
        "web": 0.30,
        "iot": 0.20
    }

    validate_profile_mix(
        profile_mix
    )

    print(
        "Profile mix sum:",
        sum(profile_mix.values())
    )

    print("Profile Mix: PASS")

    # -------------------------------
    # 3. SCENARIO TEST
    # -------------------------------

    print("\n3. SCENARIO TEST")

    config = {
        "name": "Hackathon Rush Hour",
        "type": "rush_hour",
        "duration_seconds": 3600,
        "cells": [
            "CELL_1",
            "CELL_2",
            "CELL_3",
            "CELL_4"
        ],
        "arrival_rate": 2.0,
        "mobility_probability": 0.1
    }

    scenario = create_scenario(
        config,
        seed=42
    )

    print(
        "Scenario:",
        scenario.name
    )

    print(
        "Scenario ID:",
        scenario.id
    )

    print(
        "Events:",
        scenario.exogenous_events
    )

    print("Scenario: PASS")

    # -------------------------------
    # 4. 2000 USER TEST
    # -------------------------------

    print("\n4. USER GENERATION TEST")

    rng = np.random.default_rng(42)

    users = spawn_users(
        n=2000,
        profile_mix=profile_mix,
        cells=scenario.cells,
        rng=rng,
        duration_seconds=scenario.duration_seconds
    )

    print(
        "Users generated:",
        len(users)
    )

    print(
        "First user:",
        users[0]
    )

    print("2000 User Test: PASS")

    # -------------------------------
    # 5. SESSION TEST
    # -------------------------------

    print("\n5. SESSION TEST")

    rng = np.random.default_rng(42)

    events = advance_user_sessions(
        tick=10,
        users=users,
        scenario=scenario,
        rng=rng
    )

    print(
        "Events generated:",
        len(events)
    )

    print("Session Test: PASS")

    # -------------------------------
    # 6. ARRIVAL TRACE TEST
    # -------------------------------

    print("\n6. ARRIVAL TRACE TEST")

    trace_id = export_arrival_trace(
        scenario
    )

    print(
        "Trace ID:",
        trace_id
    )

    print(
        "Trace length:",
        len(scenario.arrival_trace)
    )

    print("Arrival Trace: PASS")

    # -------------------------------
    # 7. NEGATIVE RATE TEST
    # -------------------------------

    print("\n7. NEGATIVE RATE TEST")

    try:

        bad_config = {
            "name": "Invalid",
            "type": "rush_hour",
            "duration_seconds": 100,
            "cells": ["CELL_1"],
            "arrival_rate": -5
        }

        create_scenario(
            bad_config,
            seed=42
        )

        print(
            "ERROR: Negative rate was accepted"
        )

    except ValueError:
        print(
            "Negative rate correctly rejected"
        )

    print("Negative Rate Test: PASS")

    # -------------------------------
    # 8. REPRODUCIBILITY TEST
    # -------------------------------

    print("\n8. REPRODUCIBILITY TEST")

    rng1 = np.random.default_rng(42)
    rng2 = np.random.default_rng(42)

    users1 = spawn_users(
        100,
        profile_mix,
        scenario.cells,
        rng1
    )

    users2 = spawn_users(
        100,
        profile_mix,
        scenario.cells,
        rng2
    )

    same = True

    for u1, u2 in zip(users1, users2):

        if (
            u1.id != u2.id
            or u1.cell_id != u2.cell_id
            or u1.activity_id != u2.activity_id
            or u1.arrival_time != u2.arrival_time
        ):
            same = False
            break

    print(
        "Reproducible:",
        same
    )

    print("Reproducibility: PASS")

    print("\n================================")
    print(" MODULE 1 TESTS COMPLETED")
    print("================================")