# M04_SimPy_Network/congestion.py

from __future__ import annotations

from dataclasses import dataclass
from collections import deque


@dataclass
class CongestionStatus:

    cell_id: str

    offered_mbps: float
    capacity_mbps: float
    utilization: float

    queue_ratio: float
    loss_percent: float

    congested: bool
    severity: str


class CongestionMonitor:

    def __init__(
        self,
        utilization_threshold: float = 0.85,
        queue_threshold: float = 0.80,
        loss_threshold_percent: float = 2.0,
        history_size: int = 30,
    ):

        self.utilization_threshold = (
            utilization_threshold
        )

        self.queue_threshold = queue_threshold

        self.loss_threshold_percent = (
            loss_threshold_percent
        )

        self.history = {}

        self.history_size = history_size

    def evaluate(
        self,
        cell_id: str,
        offered_mbps: float,
        capacity_mbps: float,
        queue_ratio: float,
        loss_percent: float,
    ) -> CongestionStatus:

        if capacity_mbps <= 0:

            utilization = 1.0

        else:

            utilization = (
                offered_mbps
                / capacity_mbps
            )

        utilization = min(
            1.0,
            max(0.0, utilization),
        )

        congested = (
            utilization >= self.utilization_threshold
            or queue_ratio >= self.queue_threshold
            or loss_percent >= self.loss_threshold_percent
        )

        severity = self._severity(
            utilization,
            queue_ratio,
            loss_percent,
        )

        if cell_id not in self.history:

            self.history[cell_id] = deque(
                maxlen=self.history_size
            )

        self.history[cell_id].append(
            {
                "utilization": utilization,
                "queue_ratio": queue_ratio,
                "loss_percent": loss_percent,
            }
        )

        return CongestionStatus(
            cell_id=cell_id,
            offered_mbps=offered_mbps,
            capacity_mbps=capacity_mbps,
            utilization=utilization,
            queue_ratio=queue_ratio,
            loss_percent=loss_percent,
            congested=congested,
            severity=severity,
        )

    def _severity(
        self,
        utilization: float,
        queue_ratio: float,
        loss_percent: float,
    ) -> str:

        score = max(
            utilization,
            queue_ratio,
            min(1.0, loss_percent / 10.0),
        )

        if score >= 0.95:
            return "CRITICAL"

        if score >= 0.85:
            return "HIGH"

        if score >= 0.70:
            return "MEDIUM"

        return "LOW"

    def get_history(
        self,
        cell_id: str,
    ) -> list:

        return list(
            self.history.get(
                cell_id,
                [],
            )
        )