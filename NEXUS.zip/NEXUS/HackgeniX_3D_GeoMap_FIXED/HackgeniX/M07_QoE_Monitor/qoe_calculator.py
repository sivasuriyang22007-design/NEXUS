"""
M07_QoE_Monitor - qoe_calculator.py

Activity-specific QoE, SLA, fairness, starvation, anomaly detection,
feature-leakage checks, temporal sequence building, distribution shift
and optional scikit-learn model benchmarking.

Required formula/version metadata is retained in QoEConfig.

No third-party package is required for normal QoE/SLA operation.
ML benchmarking uses scikit-learn only when it is already installed.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from math import exp, log, sqrt
from statistics import mean
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


FORMULA_VERSION = "qoe-v1.0"
SCHEMA_VERSION = "m07-features-v1.0"


def clip(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def throughput_satisfaction(
    delivered_mbps: float,
    target_mbps: float,
    eps: float = 1e-12,
) -> float:
    return clip(delivered_mbps / max(target_mbps, eps))


def latency_satisfaction(
    delay_ms: float,
    budget_ms: float,
    scale_ms: float,
) -> float:
    scale_ms = max(scale_ms, 1e-12)
    return exp(-max(0.0, delay_ms - budget_ms) / scale_ms)


def loss_satisfaction(
    loss_fraction: float,
    tolerance: float,
) -> float:
    return exp(-max(0.0, loss_fraction) / max(tolerance, 1e-12))


def weighted_geometric_mean(
    scores: Mapping[str, float],
    weights: Mapping[str, float],
) -> float:
    active = [
        (name, clip(value), max(0.0, float(weights.get(name, 0.0))))
        for name, value in scores.items()
        if float(weights.get(name, 0.0)) > 0
    ]
    if not active:
        return 0.0
    total_weight = sum(w for _, _, w in active)
    if total_weight <= 0:
        return 0.0
    return exp(sum(w * log(max(s, 1e-12)) for _, s, w in active) / total_weight)


@dataclass
class QoEConfig:
    formula_version: str = FORMULA_VERSION
    schema_version: str = SCHEMA_VERSION

    scale_ms: float = 20.0
    loss_tolerance: float = 0.02

    class_weights: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        "streaming": {
            "bitrate": 0.45,
            "stall": 0.30,
            "startup": 0.25,
        },
        "interactive": {
            "latency": 0.45,
            "jitter": 0.25,
            "loss": 0.30,
        },
        "download": {
            "completion": 0.55,
            "progress": 0.45,
        },
        "browsing": {
            "response": 1.0,
        },
        "deadline_sensitive": {
            "deadline": 0.70,
            "availability": 0.30,
        },
    })

    sla_thresholds: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        "streaming": {"min_qoe": 0.70, "max_startup_ms": 3000.0},
        "interactive": {"max_latency_ms": 100.0, "max_loss_fraction": 0.03},
        "download": {"max_completion_s": 60.0},
        "browsing": {"max_response_ms": 500.0},
        "deadline_sensitive": {"max_deadline_ms": 1000.0, "min_availability": 0.99},
    })

    starvation_min_mbps: float = 0.1
    starvation_ticks: int = 3

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def calculate_activity_qoe(
    traffic_class: str,
    metrics: Mapping[str, float],
    config: Optional[QoEConfig] = None,
) -> Dict[str, float]:
    cfg = config or QoEConfig()
    cls = traffic_class.lower()

    if cls == "streaming":
        scores = {
            "bitrate": throughput_satisfaction(
                metrics.get("delivered_mbps", 0.0),
                metrics.get("target_mbps", 1.0),
            ),
            "stall": clip(1.0 - metrics.get("stall_probability", 0.0)),
            "startup": clip(
                exp(-max(0.0, metrics.get("startup_delay_ms", 0.0)) /
                    max(metrics.get("startup_scale_ms", cfg.scale_ms), 1e-12))
            ),
        }
    elif cls in {"interactive", "call", "gaming"}:
        jitter_score = exp(
            -max(0.0, metrics.get("jitter_ms", 0.0)) /
            max(metrics.get("jitter_scale_ms", cfg.scale_ms), 1e-12)
        )
        scores = {
            "latency": latency_satisfaction(
                metrics.get("latency_ms", 0.0),
                metrics.get("latency_budget_ms", 100.0),
                cfg.scale_ms,
            ),
            "jitter": clip(jitter_score),
            "loss": loss_satisfaction(
                metrics.get("loss_fraction", 0.0),
                cfg.loss_tolerance,
            ),
        }
        cls = "interactive"
    elif cls == "download":
        completion = metrics.get("completion_time_s", 0.0)
        target_completion = max(metrics.get("target_completion_s", 1.0), 1e-12)
        scores = {
            "completion": clip(target_completion / max(completion, target_completion)),
            "progress": clip(metrics.get("progress_ratio", 0.0)),
        }
    elif cls == "browsing":
        scores = {
            "response": latency_satisfaction(
                metrics.get("response_delay_ms", 0.0),
                metrics.get("response_budget_ms", 500.0),
                cfg.scale_ms,
            )
        }
    elif cls in {"deadline_sensitive", "emergency", "medical"}:
        deadline_score = latency_satisfaction(
            metrics.get("delivery_delay_ms", 0.0),
            metrics.get("deadline_ms", 1000.0),
            cfg.scale_ms,
        )
        scores = {
            "deadline": deadline_score,
            "availability": clip(metrics.get("availability", 1.0)),
        }
        cls = "deadline_sensitive"
    else:
        scores = {
            "throughput": throughput_satisfaction(
                metrics.get("delivered_mbps", 0.0),
                metrics.get("target_mbps", 1.0),
            ),
            "latency": latency_satisfaction(
                metrics.get("latency_ms", 0.0),
                metrics.get("latency_budget_ms", 100.0),
                cfg.scale_ms,
            ),
            "loss": loss_satisfaction(
                metrics.get("loss_fraction", 0.0),
                cfg.loss_tolerance,
            ),
        }
        cfg.class_weights.setdefault(cls, {
            "throughput": 1 / 3,
            "latency": 1 / 3,
            "loss": 1 / 3,
        })

    qoe = weighted_geometric_mean(scores, cfg.class_weights.get(cls, {}))
    result = dict(scores)
    result["qoe"] = qoe
    return result


def jain_index(values: Sequence[float], eps: float = 1e-12) -> float:
    xs = [max(0.0, float(v)) for v in values]
    if not xs:
        return 1.0
    denominator = len(xs) * sum(v * v for v in xs)
    return 1.0 if denominator <= eps else (sum(xs) ** 2) / denominator


def sla_violation(
    traffic_class: str,
    metrics: Mapping[str, float],
    qoe: Optional[float] = None,
    config: Optional[QoEConfig] = None,
) -> bool:
    """Configured thresholds define SLA evaluation; inactive sessions should
    be excluded by the caller before calculating an SLA rate."""
    cfg = config or QoEConfig()
    cls = traffic_class.lower()
    t = cfg.sla_thresholds.get(cls, {})

    if cls == "streaming":
        return (
            (qoe is not None and qoe < t.get("min_qoe", 0.0))
            or metrics.get("startup_delay_ms", 0.0) > t.get("max_startup_ms", float("inf"))
        )
    if cls in {"interactive", "call", "gaming"}:
        return (
            metrics.get("latency_ms", 0.0) > t.get("max_latency_ms", float("inf"))
            or metrics.get("loss_fraction", 0.0) > t.get("max_loss_fraction", 1.0)
        )
    if cls == "download":
        return metrics.get("completion_time_s", 0.0) > t.get("max_completion_s", float("inf"))
    if cls == "browsing":
        return metrics.get("response_delay_ms", 0.0) > t.get("max_response_ms", float("inf"))
    if cls in {"deadline_sensitive", "emergency", "medical"}:
        return (
            metrics.get("delivery_delay_ms", 0.0) > t.get("max_deadline_ms", float("inf"))
            or metrics.get("availability", 1.0) < t.get("min_availability", 0.0)
        )
    return False


def sla_rate(
    rows: Iterable[Mapping[str, Any]],
    config: Optional[QoEConfig] = None,
) -> float:
    cfg = config or QoEConfig()
    evaluated = [r for r in rows if bool(r.get("active", True))]
    if not evaluated:
        return 1.0
    violations = 0
    for row in evaluated:
        violations += int(
            sla_violation(
                str(row.get("traffic_class", "generic")),
                row,
                row.get("qoe"),
                cfg,
            )
        )
    return 1.0 - violations / len(evaluated)


def detect_starvation(
    rows: Sequence[Mapping[str, Any]],
    minimum_rate_mbps: float,
    consecutive_ticks: int,
) -> List[Dict[str, Any]]:
    by_user: Dict[str, List[Mapping[str, Any]]] = {}
    for row in rows:
        if row.get("active", True):
            by_user.setdefault(str(row["user_id"]), []).append(row)

    events = []
    for user_id, user_rows in by_user.items():
        ordered = sorted(user_rows, key=lambda x: float(x.get("timestamp", 0.0)))
        run = []
        for row in ordered:
            if (
                float(row.get("delivered_mbps", 0.0)) < minimum_rate_mbps
                and float(row.get("backlog_bytes", 0.0)) > 0
            ):
                run.append(row)
            else:
                if len(run) >= consecutive_ticks:
                    events.append(_make_starvation_event(user_id, run))
                run = []
        if len(run) >= consecutive_ticks:
            events.append(_make_starvation_event(user_id, run))
    return events


def _make_starvation_event(user_id: str, rows: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    return {
        "user_id": user_id,
        "start": float(rows[0].get("timestamp", 0.0)),
        "end": float(rows[-1].get("timestamp", 0.0)),
        "ticks": len(rows),
        "age": max(
            0.0,
            float(rows[-1].get("timestamp", 0.0)) -
            float(rows[0].get("timestamp", 0.0)),
        ),
        "minimum_rate_observed_mbps": min(
            float(r.get("delivered_mbps", 0.0)) for r in rows
        ),
    }


def feature_leakage_check(
    feature_rows: Sequence[Mapping[str, Any]],
    forbidden_names: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """
    Finds fields that should not be observer inputs because they represent
    future outcomes, synthetic ground truth, application identity or configured
    targets. The exact names are configurable.
    """
    forbidden = {
        "future_qoe",
        "future_latency",
        "future_loss",
        "future_throughput",
        "ground_truth",
        "synthetic_label",
        "application_name",
        "app_name",
        "qos_target",
        "configured_qos_target",
        "future_sla_violation",
        "future_value",
    }
    forbidden.update(forbidden_names or [])
    found = sorted({key for row in feature_rows for key in row if key in forbidden})
    return {
        "leakage_detected": bool(found),
        "forbidden_features": found,
        "checked_rows": len(feature_rows),
    }


def build_temporal_sequences(
    rows: Sequence[Mapping[str, Any]],
    feature_names: Sequence[str],
    sequence_length: int = 10,
    user_key: str = "user_id",
    time_key: str = "timestamp",
) -> Tuple[List[List[List[float]]], List[str]]:
    """Build past-only sequences. Rows are sorted by time within each user."""
    if sequence_length < 1:
        raise ValueError("sequence_length must be >= 1")

    grouped: Dict[str, List[Mapping[str, Any]]] = {}
    for row in rows:
        grouped.setdefault(str(row[user_key]), []).append(row)

    sequences: List[List[List[float]]] = []
    users: List[str] = []

    for user, user_rows in grouped.items():
        ordered = sorted(user_rows, key=lambda x: float(x.get(time_key, 0.0)))
        for i in range(sequence_length, len(ordered) + 1):
            window = ordered[i - sequence_length:i]
            sequences.append([
                [float(row.get(name, 0.0)) for name in feature_names]
                for row in window
            ])
            users.append(user)

    return sequences, users


def chronological_split(
    rows: Sequence[Mapping[str, Any]],
    train_ratio: float = 0.70,
    validation_ratio: float = 0.15,
    time_key: str = "timestamp",
) -> Tuple[List[Mapping[str, Any]], List[Mapping[str, Any]], List[Mapping[str, Any]]]:
    ordered = sorted(rows, key=lambda x: float(x.get(time_key, 0.0)))
    n = len(ordered)
    a = int(n * train_ratio)
    b = int(n * (train_ratio + validation_ratio))
    return ordered[:a], ordered[a:b], ordered[b:]


def _ks_statistic(a: Sequence[float], b: Sequence[float]) -> float:
    if not a or not b:
        return 0.0
    x = sorted(float(v) for v in a)
    y = sorted(float(v) for v in b)
    i = j = 0
    d = 0.0
    while i < len(x) and j < len(y):
        if x[i] <= y[j]:
            i += 1
        else:
            j += 1
        d = max(d, abs(i / len(x) - j / len(y)))
    return d


def detect_distribution_shift(
    baseline: Mapping[str, Sequence[float]],
    current: Mapping[str, Sequence[float]],
    threshold: float = 0.20,
) -> Dict[str, Any]:
    result = {}
    for name in sorted(set(baseline) & set(current)):
        score = _ks_statistic(baseline[name], current[name])
        result[name] = {
            "ks_statistic": score,
            "shift_detected": score >= threshold,
        }
    return result


def anomaly_scores(
    rows: Sequence[Mapping[str, Any]],
    feature_names: Sequence[str],
) -> List[float]:
    """Dependency-free robust-ish anomaly score using z-distance."""
    if not rows:
        return []
    columns = {
        f: [float(r.get(f, 0.0)) for r in rows]
        for f in feature_names
    }
    stats = {}
    for f, xs in columns.items():
        mu = mean(xs)
        variance = mean((x - mu) ** 2 for x in xs)
        stats[f] = (mu, sqrt(variance) or 1e-12)

    scores = []
    for row in rows:
        z2 = 0.0
        for f in feature_names:
            mu, sd = stats[f]
            z2 += ((float(row.get(f, 0.0)) - mu) / sd) ** 2
        scores.append(sqrt(z2 / max(len(feature_names), 1)))
    return scores


def benchmark_ml_models(
    rows: Sequence[Mapping[str, Any]],
    feature_names: Sequence[str],
    target_name: str,
) -> Dict[str, Any]:
    """
    Optional benchmark. If scikit-learn is installed, evaluates lightweight
    models using a chronological 70/15/15 split. Otherwise returns a clear
    dependency status instead of failing the module.
    """
    try:
        from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
        from sklearn.linear_model import Ridge
        from sklearn.metrics import mean_absolute_error, mean_squared_error
    except ImportError:
        return {
            "available": False,
            "reason": "scikit-learn is not installed; core Module 7 does not require it.",
            "models": {},
        }

    train, validation, test = chronological_split(rows)
    if not train or not test:
        return {"available": True, "models": {}, "reason": "insufficient rows"}

    def matrix(part):
        return [[float(r.get(f, 0.0)) for f in feature_names] for r in part]

    X_train = matrix(train)
    y_train = [float(r[target_name]) for r in train]
    X_test = matrix(test)
    y_test = [float(r[target_name]) for r in test]

    models = {
        "Ridge": Ridge(),
        "RandomForest": RandomForestRegressor(n_estimators=80, random_state=42, n_jobs=-1),
        "ExtraTrees": ExtraTreesRegressor(n_estimators=80, random_state=42, n_jobs=-1),
        "HistGradientBoosting": HistGradientBoostingRegressor(random_state=42),
    }

    results = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        mae = mean_absolute_error(y_test, pred)
        rmse = mean_squared_error(y_test, pred) ** 0.5
        results[name] = {
            "mae": float(mae),
            "rmse": float(rmse),
            "test_rows": len(y_test),
        }

    return {
        "available": True,
        "split": {"train": len(train), "validation": len(validation), "test": len(test)},
        "models": results,
        "note": "Chronological test evaluation; no future rows are used as inputs.",
    }


def make_ml_feature_row(
    *,
    latency_p95: float,
    latency_trend: float,
    jitter_ms: float,
    loss_fraction: float,
    loss_trend: float,
    rolling_throughput: float,
    throughput_trend: float,
    backlog_growth: float,
    demand_shed_rate: float,
    current_qoe: float,
    starvation_age: float,
) -> Dict[str, float]:
    """
    Deployment-observer feature vector. It deliberately excludes future
    outcomes, synthetic labels and configured QoS targets.
    """
    return {
        "latency_p95": float(latency_p95),
        "latency_trend": float(latency_trend),
        "jitter_ms": float(jitter_ms),
        "loss_fraction": float(loss_fraction),
        "loss_trend": float(loss_trend),
        "rolling_throughput": float(rolling_throughput),
        "throughput_trend": float(throughput_trend),
        "backlog_growth": float(backlog_growth),
        "demand_shed_rate": float(demand_shed_rate),
        "current_qoe": float(current_qoe),
        "starvation_age": float(starvation_age),
    }


def evaluate_fairness(
    user_values: Mapping[str, float],
    class_values: Optional[Mapping[str, Sequence[float]]] = None,
) -> Dict[str, Any]:
    result = {
        "user_jain_index": jain_index(list(user_values.values())),
        "user_distribution": {
            "min": min(user_values.values()) if user_values else 0.0,
            "p50": _percentile(list(user_values.values()), 50),
            "p95": _percentile(list(user_values.values()), 95),
            "max": max(user_values.values()) if user_values else 0.0,
        },
    }
    if class_values:
        result["class_jain_index"] = {
            cls: jain_index(values) for cls, values in class_values.items()
        }
    return result


def _percentile(values: Sequence[float], p: float) -> float:
    if not values:
        return 0.0
    xs = sorted(float(v) for v in values)
    if len(xs) == 1:
        return xs[0]
    rank = (len(xs) - 1) * p / 100.0
    lo = int(rank)
    hi = min(lo + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (rank - lo)


if __name__ == "__main__":
    cfg = QoEConfig()
    result = calculate_activity_qoe(
        "interactive",
        {
            "latency_ms": 45,
            "latency_budget_ms": 100,
            "jitter_ms": 8,
            "loss_fraction": 0.01,
        },
        cfg,
    )
    print("QoECalculator self-check:", result)
    print("Formula version:", cfg.formula_version)
