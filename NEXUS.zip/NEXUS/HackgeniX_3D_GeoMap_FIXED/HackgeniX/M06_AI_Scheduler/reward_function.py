def calculate_reward(metrics, weights=None):

    if weights is None:

        weights = {
            "qoe": 1.0,
            "latency": 1.0,
            "fairness": 1.0,
            "throughput": 1.0,
            "packet_loss": 1.0,
            "starvation": 1.0,
            "capacity_violation": 5.0,
            "oscillation": 0.5
        }

    reward = (
        weights["qoe"]
        * metrics["qoe"]

        + weights["latency"]
        * metrics["latency"]

        + weights["fairness"]
        * metrics["fairness"]

        + weights["throughput"]
        * metrics["throughput"]

        - weights["packet_loss"]
        * metrics["packet_loss"]

        - weights["starvation"]
        * metrics["starvation"]

        - weights["capacity_violation"]
        * metrics["capacity_violation"]

        - weights["oscillation"]
        * metrics["oscillation"]
    )

    return reward