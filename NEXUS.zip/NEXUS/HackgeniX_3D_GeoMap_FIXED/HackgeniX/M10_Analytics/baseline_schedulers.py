"""Baseline schedulers for NEXUS Module 10.

All schedulers implement the same pure allocation contract:
    allocate(demands, capacity_mbps, state=None) -> AllocationResult

They allocate only available capacity and never create capacity.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence


EPS = 1e-12


@dataclass
class AllocationResult:
    policy: str
    grants_mbps: dict[str, float]
    requested_mbps: dict[str, float]
    capacity_mbps: float
    reason_codes: list[str] = field(default_factory=list)

    @property
    def total_requested_mbps(self) -> float:
        return sum(self.requested_mbps.values())

    @property
    def total_granted_mbps(self) -> float:
        return sum(self.grants_mbps.values())

    @property
    def utilization_of_grant_capacity(self) -> float:
        if self.capacity_mbps <= EPS:
            return 0.0
        return self.total_granted_mbps / self.capacity_mbps


def _clean_demands(demands: Mapping[str, float]) -> dict[str, float]:
    cleaned = {}
    for key, value in demands.items():
        try:
            v = float(value)
        except (TypeError, ValueError):
            v = 0.0
        if v != v or v < 0:  # NaN or negative
            v = 0.0
        cleaned[str(key)] = v
    return cleaned


def _empty(policy: str, demands: Mapping[str, float], capacity_mbps: float, reason: str) -> AllocationResult:
    d = _clean_demands(demands)
    return AllocationResult(
        policy=policy,
        grants_mbps={k: 0.0 for k in d},
        requested_mbps=d,
        capacity_mbps=max(0.0, float(capacity_mbps)),
        reason_codes=[reason],
    )


def fixed_equal(demands: Mapping[str, float], capacity_mbps: float, state: Mapping[str, Any] | None = None) -> AllocationResult:
    """Equal/fixed allocation among active demand groups, capped by demand."""
    d = _clean_demands(demands)
    capacity = max(0.0, float(capacity_mbps))
    active = [k for k, v in d.items() if v > EPS]
    grants = {k: 0.0 for k in d}
    if not active or capacity <= EPS:
        return _empty("fixed_equal", d, capacity, "NO_ACTIVE_DEMAND")
    remaining = capacity
    unsatisfied = set(active)
    while unsatisfied and remaining > EPS:
        share = remaining / len(unsatisfied)
        served_now = []
        for k in unsatisfied:
            add = min(d[k] - grants[k], share)
            grants[k] += max(0.0, add)
            if grants[k] >= d[k] - EPS:
                served_now.append(k)
        spent = sum(grants[k] for k in unsatisfied)
        remaining = max(0.0, capacity - sum(grants.values()))
        for k in served_now:
            unsatisfied.discard(k)
        if not served_now and spent <= EPS:
            break
    return AllocationResult("fixed_equal", grants, d, capacity, ["EQUAL_SHARE"])


def round_robin(
    demands: Mapping[str, float],
    capacity_mbps: float,
    state: Mapping[str, Any] | None = None,
    quantum_mbps: float = 1.0,
) -> AllocationResult:
    """Documented quantum round-robin over stable key order."""
    d = _clean_demands(demands)
    capacity = max(0.0, float(capacity_mbps))
    q = max(EPS, float(quantum_mbps))
    grants = {k: 0.0 for k in d}
    active = [k for k, v in d.items() if v > EPS]
    if not active or capacity <= EPS:
        return _empty("round_robin", d, capacity, "NO_ACTIVE_DEMAND")
    idx = 0
    while capacity - sum(grants.values()) >= min(q, capacity) - EPS and active:
        k = active[idx % len(active)]
        remaining_demand = d[k] - grants[k]
        if remaining_demand > EPS:
            add = min(q, remaining_demand, capacity - sum(grants.values()))
            grants[k] += max(0.0, add)
        if grants[k] >= d[k] - EPS:
            active.remove(k)
            if active:
                idx %= len(active)
        else:
            idx += 1
    return AllocationResult("round_robin", grants, d, capacity, [f"QUANTUM_{q:g}_MBPS"])


def weighted_fair(
    demands: Mapping[str, float],
    capacity_mbps: float,
    state: Mapping[str, Any] | None = None,
) -> AllocationResult:
    """Weighted proportional allocation, with weights from state['weights'] or 1.0."""
    d = _clean_demands(demands)
    capacity = max(0.0, float(capacity_mbps))
    raw_weights = (state or {}).get("weights", {})
    weights = {k: max(0.0, float(raw_weights.get(k, 1.0))) for k in d}
    grants = {k: 0.0 for k in d}
    remaining = capacity
    active = {k for k, v in d.items() if v > EPS and weights[k] > EPS}

    while active and remaining > EPS:
        total_w = sum(weights[k] for k in active)
        if total_w <= EPS:
            break
        capped = []
        for k in active:
            share = remaining * weights[k] / total_w
            if share >= d[k] - grants[k] - EPS:
                capped.append(k)
        if not capped:
            for k in active:
                grants[k] += min(d[k] - grants[k], remaining * weights[k] / total_w)
            break
        spent = 0.0
        for k in capped:
            add = max(0.0, d[k] - grants[k])
            grants[k] += add
            spent += add
        remaining = max(0.0, remaining - spent)
        for k in capped:
            active.discard(k)

    return AllocationResult("weighted_fair", grants, d, capacity, ["WEIGHTED_PROPORTIONAL"])


def static_qos(
    demands: Mapping[str, float],
    capacity_mbps: float,
    state: Mapping[str, Any] | None = None,
) -> AllocationResult:
    """Static QoS weights; no learning or future information is used."""
    state = state or {}
    qos_weights = state.get("qos_weights", {})
    return weighted_fair(demands, capacity_mbps, {"weights": qos_weights})


POLICIES = {
    "fixed_equal": fixed_equal,
    "round_robin": round_robin,
    "weighted_fair": weighted_fair,
    "static_qos": static_qos,
}


def allocate(
    policy: str,
    demands: Mapping[str, float],
    capacity_mbps: float,
    state: Mapping[str, Any] | None = None,
) -> AllocationResult:
    try:
        fn = POLICIES[policy]
    except KeyError as exc:
        raise ValueError(f"Unknown baseline policy: {policy}") from exc
    result = fn(demands, capacity_mbps, state)
    if sum(result.grants_mbps.values()) > result.capacity_mbps + 1e-8:
        raise AssertionError("Capacity invariant violated")
    if any(v < -1e-10 for v in result.grants_mbps.values()):
        raise AssertionError("Negative allocation invariant violated")
    return result
