from stable_baselines3 import PPO

from ppo_environment import SchedulerEnv


MODEL_NAME = "ppo_scheduler"


def train():

    env = SchedulerEnv()

    model = PPO(
        "MlpPolicy",
        env,
        verbose=1,
        learning_rate=0.0003,
        n_steps=512,
        batch_size=64,
        gamma=0.99
    )

    model.learn(
        total_timesteps=10000
    )

    model.save(
        MODEL_NAME
    )

    print(
        "PPO model saved."
    )


def load_model():

    return PPO.load(
        MODEL_NAME
    )


def predict(model, state):

    action, _ = model.predict(
        state,
        deterministic=True
    )

    return action


if __name__ == "__main__":

    train()