@echo off
title NEXUS Dashboard
cd /d "%~dp0HackgeniX"
echo.
echo ==========================================
echo   NEXUS 3D GeoMap Dashboard
echo ==========================================
echo.
python integration.py
if errorlevel 1 (
  echo.
  echo Integration failed. Check the error above.
  pause
  exit /b 1
)
pause

