"""
M07_QoE_Monitor - latency_monitor.py

Latency, jitter, deadline and temporal degradation monitoring.
Standard library only.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from statistics import mean, pstdev
from typing import Dict, List, Optional, Sequence

from metrics_collector import percentile


@dataclass
class LatencySample:
    timestamp: float
    user_id: str
    delay_ms: float
    budget_ms: Optional[float] = None
    active: bool = True


class LatencyMonitor:
    def __init__(self, scale_ms: float = 20.0):
        self.scale_ms = max(float(scale_ms), 1e-9)
        self.samples: List[LatencySample] = []
        self._previous_delay: Dict[str, float] = {}

    def add(self, sample: LatencySample) -> None:
        if not isfinite(sample.delay_ms) or sample.delay_ms < 0:
            raise ValueError("delay_ms must be a finite non-negative number")
        self.samples.append(sample)

    def add_value(
        self,
        timestamp: float,
        user_id: str,
        delay_ms: float,
        budget_ms: Optional[float] = None,
        active: bool = True,
    ) -> LatencySample:
        sample = LatencySample(timestamp, user_id, delay_ms, budget_ms, active)
        self.add(sample)
        return sample

    def delays(self, active_only: bool = True) -> List[float]:
        return [
            s.delay_ms for s in self.samples
            if (s.active or not active_only)
        ]

    def summary(self) -> Dict[str, float]:
        xs = self.delays()
        if not xs:
            return {k: 0.0 for k in (
                "mean", "std", "p50", "p90", "p95", "p99",
                "min", "max", "jitter_mean", "jitter_std",
                "budget_exceedance_rate", "spike_count"
            )}
        jitters = self.jitter_values()
        return {
            "mean": mean(xs),
            "std": pstdev(xs) if len(xs) > 1 else 0.0,
            "p50": percentile(xs, 50),
            "p90": percentile(xs, 90),
            "p95": percentile(xs, 95),
            "p99": percentile(xs, 99),
            "min": min(xs),
            "max": max(xs),
            "jitter_mean": mean(jitters) if jitters else 0.0,
            "jitter_std": pstdev(jitters) if len(jitters) > 1 else 0.0,
            "budget_exceedance_rate": self.deadline_miss_rate(),
            "spike_count": float(self.spike_count()),
        }

    def jitter_values(self) -> List[float]:
        by_user: Dict[str, List[LatencySample]] = {}
        for s in self.samples:
            if s.active:
                by_user.setdefault(s.user_id, []).append(s)
        result = []
        for rows in by_user.values():
            rows.sort(key=lambda x: x.timestamp)
            for a, b in zip(rows, rows[1:]):
                result.append(abs(b.delay_ms - a.delay_ms))
        return result

    def deadline_miss_rate(self) -> float:
        evaluated = [
            s for s in self.samples
            if s.active and s.budget_ms is not None
        ]
        if not evaluated:
            return 0.0
        return sum(s.delay_ms > float(s.budget_ms) for s in evaluated) / len(evaluated)

    def spike_count(self, threshold_ms: Optional[float] = None) -> int:
        xs = self.delays()
        if len(xs) < 3:
            return 0
        threshold = threshold_ms
        if threshold is None:
            threshold = mean(xs) + 3.0 * (pstdev(xs) if len(xs) > 1 else 0.0)
        return sum(x > threshold for x in xs)

    def temporal_features(self, window: int = 5) -> Dict[str, float]:
        xs = self.delays()
        if not xs:
            return {
                "latency_trend": 0.0,
                "latency_acceleration": 0.0,
                "rolling_latency": 0.0,
                "rolling_p95_latency": 0.0,
                "latency_volatility": 0.0,
                "consecutive_budget_violations": 0.0,
            }

        tail = xs[-max(1, window):]
        trend = 0.0
        if len(tail) >= 2:
            trend = (tail[-1] - tail[0]) / (len(tail) - 1)

        acceleration = 0.0
        if len(tail) >= 3:
            d1 = tail[-1] - tail[-2]
            d0 = tail[-2] - tail[-3]
            acceleration = d1 - d0

        consecutive = 0
        for s in reversed(self.samples):
            if not s.active or s.budget_ms is None:
                continue
            if s.delay_ms > s.budget_ms:
                consecutive += 1
            else:
                break

        return {
            "latency_trend": trend,
            "latency_acceleration": acceleration,
            "rolling_latency": mean(tail),
            "rolling_p95_latency": percentile(tail, 95),
            "latency_volatility": pstdev(tail) if len(tail) > 1 else 0.0,
            "consecutive_budget_violations": float(consecutive),
        }

    def recovery_time(self, threshold_ms: float) -> float:
        """Seconds from a threshold exceedance until latency returns below it."""
        rows = sorted((s for s in self.samples if s.active), key=lambda x: x.timestamp)
        start = None
        for s in rows:
            if s.delay_ms > threshold_ms and start is None:
                start = s.timestamp
            elif start is not None and s.delay_ms <= threshold_ms:
                return max(0.0, s.timestamp - start)
        return 0.0


if __name__ == "__main__":
    m = LatencyMonitor()
    for i, d in enumerate((20, 25, 40, 35, 22)):
        m.add_value(i, "u1", d, budget_ms=30)
    print("LatencyMonitor self-check:", m.summary())
