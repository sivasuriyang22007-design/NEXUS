"""Small bounded in-process event bus for dashboard/analytics integration."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from threading import Lock
from typing import Any, Callable


@dataclass(frozen=True)
class Event:
    sequence: int
    topic: str
    payload: dict[str, Any]


class EventBus:
    def __init__(self, max_events: int = 1000):
        self._events = deque(maxlen=max_events)
        self._subscribers: dict[str, list[Callable[[Event], None]]] = {}
        self._sequence = 0
        self._lock = Lock()

    def publish(self, topic: str, payload: dict[str, Any]) -> Event:
        with self._lock:
            self._sequence += 1
            event = Event(self._sequence, topic, dict(payload))
            self._events.append(event)
            subscribers = list(self._subscribers.get(topic, []))
        for callback in subscribers:
            callback(event)
        return event

    def subscribe(self, topic: str, callback: Callable[[Event], None]) -> None:
        with self._lock:
            self._subscribers.setdefault(topic, []).append(callback)

    def snapshot(self, after_sequence: int = 0) -> list[Event]:
        with self._lock:
            return [e for e in self._events if e.sequence > after_sequence]
