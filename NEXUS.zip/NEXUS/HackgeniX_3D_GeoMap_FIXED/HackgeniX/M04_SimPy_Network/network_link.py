# M04_SimPy_Network/network_link.py

from __future__ import annotations

import random
import simpy

from .packet_queue import PacketQueue
from .transmission import Transmission, TransmissionRecord


class NetworkLink:
    """
    SimPy network link.

    Capacity:
        Mbps

    Packet transmission:
        packet_bits / (allocated_Mbps * 1e6)

    The link does not create bandwidth beyond its configured capacity.
    """

    def __init__(
        self,
        env: simpy.Environment,
        link_id: str,
        capacity_mbps: float,
        propagation_delay_ms: float = 5.0,
        queue_bytes: int = 10_000_000,
        loss_probability: float = 0.0,
        seed: int = 42,
    ):
        self.env = env
        self.link_id = link_id

        self.capacity_mbps = max(
            0.0,
            float(capacity_mbps),
        )

        self.propagation_delay_ms = max(
            0.0,
            float(propagation_delay_ms),
        )

        self.loss_probability = min(
            1.0,
            max(0.0, float(loss_probability)),
        )

        self.queue = PacketQueue(
            max_bytes=queue_bytes,
            name=f"{link_id}_queue",
        )

        self.random = random.Random(seed)

        self.transmission_records: list[TransmissionRecord] = []

        self.busy_time_seconds = 0.0

        self.total_offered_bits = 0
        self.total_delivered_bits = 0
        self.total_dropped_bits = 0

        self.total_offered_packets = 0
        self.total_delivered_packets = 0
        self.total_dropped_packets = 0

        self.active = True

        self.service_process = env.process(
            self._service_loop()
        )

    # ---------------------------------------------------------
    # Capacity
    # ---------------------------------------------------------

    def effective_capacity_mbps(
        self,
        efficiency: float = 1.0,
    ) -> float:

        efficiency = min(
            1.0,
            max(0.0, float(efficiency)),
        )

        return self.capacity_mbps * efficiency

    # ---------------------------------------------------------
    # Packet arrival
    # ---------------------------------------------------------

    def put(
        self,
        packet,
        current_time: float | None = None,
    ) -> bool:

        if current_time is None:
            current_time = float(self.env.now)

        size_bits = self._packet_bits(packet)

        self.total_offered_packets += 1
        self.total_offered_bits += size_bits

        accepted = self.queue.enqueue(
            packet,
            current_time,
        )

        if not accepted:
            self.total_dropped_packets += 1
            self.total_dropped_bits += size_bits

            self._mark_drop(
                packet,
                "BUFFER_OVERFLOW",
            )

        return accepted

    # ---------------------------------------------------------
    # Service process
    # ---------------------------------------------------------

    def _service_loop(self):

        while True:

            if not self.active or self.queue.is_empty():

                yield self.env.timeout(0.001)

                continue

            packet = self.queue.peek()

            if packet is None:

                yield self.env.timeout(0.001)

                continue

            allocated_mbps = self._get_packet_allocation(
                packet
            )

            allocated_mbps = min(
                allocated_mbps,
                self.capacity_mbps,
            )

            if allocated_mbps <= 0:

                yield self.env.timeout(0.001)

                continue

            packet = self.queue.dequeue(
                self.env.now
            )

            if packet is None:
                continue

            transmission = Transmission(
                packet=packet,
                start_time=self.env.now,
                allocated_mbps=allocated_mbps,
                propagation_delay_ms=self.propagation_delay_ms,
            )

            tx_time = transmission.total_delay_seconds()

            self.busy_time_seconds += (
                transmission.serialization_delay_seconds()
            )

            yield self.env.timeout(tx_time)

            # Optional stochastic link loss.
            if self.random.random() < self.loss_probability:

                self.total_dropped_packets += 1
                self.total_dropped_bits += (
                    transmission.packet_bits()
                )

                self._mark_drop(
                    packet,
                    "LINK_LOSS",
                )

                continue

            delivered_at = float(self.env.now)

            record = transmission.build_record(
                delivered_at=delivered_at,
                queue_delay_ms=getattr(
                    packet,
                    "queue_delay_seconds",
                    0.0,
                ) * 1000.0,
            )

            self.transmission_records.append(record)

            self.total_delivered_packets += 1
            self.total_delivered_bits += (
                transmission.packet_bits()
            )

            self._mark_delivery(
                packet,
                record,
            )

    # ---------------------------------------------------------
    # Allocation
    # ---------------------------------------------------------

    def _get_packet_allocation(self, packet) -> float:

        if hasattr(packet, "allocated_mbps"):

            value = getattr(
                packet,
                "allocated_mbps",
            )

            return max(0.0, float(value))

        if isinstance(packet, dict):

            return max(
                0.0,
                float(
                    packet.get(
                        "allocated_mbps",
                        self.capacity_mbps,
                    )
                ),
            )

        return self.capacity_mbps

    # ---------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------

    @staticmethod
    def _packet_bits(packet) -> int:

        if hasattr(packet, "size_bits"):
            return max(1, int(packet.size_bits))

        if hasattr(packet, "size_bytes"):
            return max(1, int(packet.size_bytes) * 8)

        if isinstance(packet, dict):

            if "size_bits" in packet:
                return max(
                    1,
                    int(packet["size_bits"]),
                )

            if "size_bytes" in packet:
                return max(
                    1,
                    int(packet["size_bytes"]) * 8,
                )

        raise ValueError("Packet size not found")

    @staticmethod
    def _mark_drop(packet, reason: str):

        try:
            packet.dropped = True
            packet.drop_reason = reason
        except Exception:
            pass

    @staticmethod
    def _mark_delivery(
        packet,
        record: TransmissionRecord,
    ):

        try:
            packet.delivered_at = record.delivered_at
            packet.latency_ms = record.total_delay_ms
            packet.delivered = True
        except Exception:
            pass

    # ---------------------------------------------------------
    # Metrics
    # ---------------------------------------------------------

    def utilization(
        self,
        elapsed_seconds: float,
    ) -> float:

        if elapsed_seconds <= 0:
            return 0.0

        available_time = (
            elapsed_seconds
            * self.capacity_mbps
            / max(self.capacity_mbps, 1e-12)
        )

        if available_time <= 0:
            return 0.0

        return min(
            1.0,
            self.busy_time_seconds / available_time,
        )

    def snapshot(self) -> dict:

        return {
            "link_id": self.link_id,
            "capacity_mbps": self.capacity_mbps,
            "queue": self.queue.snapshot(),
            "offered_bits": self.total_offered_bits,
            "delivered_bits": self.total_delivered_bits,
            "dropped_bits": self.total_dropped_bits,
            "offered_packets": self.total_offered_packets,
            "delivered_packets": self.total_delivered_packets,
            "dropped_packets": self.total_dropped_packets,
            "busy_time_seconds": self.busy_time_seconds,
        }