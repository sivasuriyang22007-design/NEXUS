"""
NEXUS / Hackathon
M03 - Traffic Classifier
STANDALONE DEMO RUNNER

IMPORTANT:
This is a temporary standalone runner.

Do NOT modify:
    feature_extractor.py
    classifier.py
    train_classifier.py

Delete this file when integrating M03 into the main project.
"""

from __future__ import annotations

import json
import os
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    accuracy_score,
)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.calibration import CalibratedClassifierCV
from sklearn.preprocessing import LabelEncoder


# ============================================================
# CONFIGURATION
# ============================================================

SEED = 42

SAMPLES_PER_CLASS = 100

TOP_K = 3

UNKNOWN_THRESHOLD = 0.50

MODEL_VERSION = "standalone-v1"

FEATURE_SCHEMA_VERSION = "m03-features-v1"

OUTPUT_DIR = (
    Path(__file__).resolve().parent
    / "standalone_artifacts"
    / "classifier"
    / "v1"
)

MODEL_PATH = OUTPUT_DIR / "model.joblib"

METRICS_PATH = OUTPUT_DIR / "metrics.json"


# ============================================================
# FEATURE SCHEMA
# ============================================================

FEATURE_COLUMNS = [
    "packet_rate",
    "packet_size_mean",
    "packet_size_std",
    "flow_duration",
    "burst_frequency",
    "ul_dl_ratio",
    "interarrival_mean",
    "interarrival_std",
    "retransmission_proxy",
    "rolling_rate_1s",
    "rolling_rate_5s",
    "rolling_rate_10s",
]


# ============================================================
# 25 TRAFFIC CLASSES
# ============================================================

TRAFFIC_CLASSES = [

    "01_reels",
    "02_video_480p",
    "03_video_1080p",
    "04_video_4k",

    "05_ott",
    "06_live_stream",

    "07_video_call",
    "08_voice_call",

    "09_messaging",
    "10_browsing",
    "11_online_gaming",

    "12_cloud_gaming",
    "13_ar_vr",
    "14_remote_desktop",

    "15_online_exam",
    "16_file_download",
    "17_backup",

    "18_software_update",
    "19_p2p",
    "20_upload",

    "21_emergency",
    "22_disaster_stream",
    "23_medical_telemetry",

    "24_public_broadcast",
    "25_operator_control",
]


# ============================================================
# SERVICE CATEGORY MAPPING
# ============================================================

SERVICE_CATEGORIES = {

    "01_reels": "VIDEO_STREAMING",
    "02_video_480p": "VIDEO_STREAMING",
    "03_video_1080p": "VIDEO_STREAMING",
    "04_video_4k": "VIDEO_STREAMING",

    "05_ott": "VIDEO_STREAMING",
    "06_live_stream": "VIDEO_STREAMING",

    "07_video_call": "REAL_TIME_COMMUNICATION",
    "08_voice_call": "REAL_TIME_COMMUNICATION",

    "09_messaging": "INTERACTIVE",
    "10_browsing": "INTERACTIVE",
    "11_online_gaming": "INTERACTIVE",

    "12_cloud_gaming": "REAL_TIME_INTERACTIVE",
    "13_ar_vr": "REAL_TIME_INTERACTIVE",
    "14_remote_desktop": "REAL_TIME_INTERACTIVE",

    "15_online_exam": "INTERACTIVE_CRITICAL",

    "16_file_download": "ELASTIC_TRANSFER",
    "17_backup": "BACKGROUND_TRANSFER",
    "18_software_update": "BACKGROUND_TRANSFER",
    "19_p2p": "BACKGROUND_TRANSFER",
    "20_upload": "ELASTIC_TRANSFER",

    "21_emergency": "AUTHORIZED_PRIORITY",
    "22_disaster_stream": "AUTHORIZED_PRIORITY",
    "23_medical_telemetry": "AUTHORIZED_PRIORITY",

    "24_public_broadcast": "EVENT_BROADCAST",
    "25_operator_control": "CONTROL_PLANE",
}


# ============================================================
# RANDOM GENERATOR
# ============================================================

rng = np.random.default_rng(SEED)


# ============================================================
# CLASS CHARACTERISTICS
#
# These are synthetic demonstration distributions.
# They are NOT real-world measured application signatures.
# ============================================================

CLASS_PROFILES = {

    "01_reels": {
        "packet_rate": (45, 12),
        "packet_size_mean": (850, 120),
        "packet_size_std": (180, 40),
        "flow_duration": (20, 8),
        "burst_frequency": (0.75, 0.10),
        "ul_dl_ratio": (0.20, 0.05),
        "interarrival_mean": (0.025, 0.008),
        "interarrival_std": (0.012, 0.004),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (40, 12),
    },

    "02_video_480p": {
        "packet_rate": (30, 8),
        "packet_size_mean": (800, 100),
        "packet_size_std": (160, 35),
        "flow_duration": (25, 10),
        "burst_frequency": (0.65, 0.10),
        "ul_dl_ratio": (0.18, 0.04),
        "interarrival_mean": (0.035, 0.010),
        "interarrival_std": (0.015, 0.005),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (25, 8),
    },

    "03_video_1080p": {
        "packet_rate": (55, 14),
        "packet_size_mean": (900, 110),
        "packet_size_std": (190, 40),
        "flow_duration": (30, 12),
        "burst_frequency": (0.78, 0.09),
        "ul_dl_ratio": (0.18, 0.04),
        "interarrival_mean": (0.020, 0.006),
        "interarrival_std": (0.010, 0.003),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (55, 15),
    },

    "04_video_4k": {
        "packet_rate": (90, 20),
        "packet_size_mean": (1050, 130),
        "packet_size_std": (220, 45),
        "flow_duration": (35, 15),
        "burst_frequency": (0.85, 0.08),
        "ul_dl_ratio": (0.15, 0.03),
        "interarrival_mean": (0.012, 0.004),
        "interarrival_std": (0.006, 0.002),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (90, 20),
    },

    "05_ott": {
        "packet_rate": (50, 13),
        "packet_size_mean": (900, 120),
        "packet_size_std": (190, 40),
        "flow_duration": (35, 15),
        "burst_frequency": (0.72, 0.10),
        "ul_dl_ratio": (0.18, 0.04),
        "interarrival_mean": (0.022, 0.007),
        "interarrival_std": (0.011, 0.004),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (50, 14),
    },

    "06_live_stream": {
        "packet_rate": (65, 15),
        "packet_size_mean": (920, 110),
        "packet_size_std": (200, 40),
        "flow_duration": (45, 18),
        "burst_frequency": (0.80, 0.08),
        "ul_dl_ratio": (0.25, 0.05),
        "interarrival_mean": (0.018, 0.005),
        "interarrival_std": (0.009, 0.003),
        "retransmission_proxy": (0.025, 0.01),
        "rate": (65, 16),
    },

    "07_video_call": {
        "packet_rate": (35, 8),
        "packet_size_mean": (500, 80),
        "packet_size_std": (120, 25),
        "flow_duration": (60, 25),
        "burst_frequency": (0.55, 0.10),
        "ul_dl_ratio": (0.95, 0.15),
        "interarrival_mean": (0.030, 0.008),
        "interarrival_std": (0.015, 0.005),
        "retransmission_proxy": (0.03, 0.012),
        "rate": (4, 1.5),
    },

    "08_voice_call": {
        "packet_rate": (45, 8),
        "packet_size_mean": (180, 35),
        "packet_size_std": (45, 12),
        "flow_duration": (80, 30),
        "burst_frequency": (0.35, 0.08),
        "ul_dl_ratio": (1.0, 0.12),
        "interarrival_mean": (0.020, 0.006),
        "interarrival_std": (0.010, 0.003),
        "retransmission_proxy": (0.03, 0.01),
        "rate": (0.10, 0.03),
    },

    "09_messaging": {
        "packet_rate": (8, 3),
        "packet_size_mean": (250, 60),
        "packet_size_std": (80, 20),
        "flow_duration": (10, 5),
        "burst_frequency": (0.25, 0.08),
        "ul_dl_ratio": (0.9, 0.2),
        "interarrival_mean": (0.15, 0.05),
        "interarrival_std": (0.08, 0.03),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (0.10, 0.04),
    },

    "10_browsing": {
        "packet_rate": (15, 5),
        "packet_size_mean": (600, 100),
        "packet_size_std": (160, 35),
        "flow_duration": (8, 4),
        "burst_frequency": (0.40, 0.10),
        "ul_dl_ratio": (0.55, 0.12),
        "interarrival_mean": (0.08, 0.025),
        "interarrival_std": (0.04, 0.015),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (1, 0.4),
    },

    "11_online_gaming": {
        "packet_rate": (25, 6),
        "packet_size_mean": (300, 50),
        "packet_size_std": (70, 15),
        "flow_duration": (120, 40),
        "burst_frequency": (0.50, 0.08),
        "ul_dl_ratio": (0.75, 0.15),
        "interarrival_mean": (0.040, 0.010),
        "interarrival_std": (0.020, 0.006),
        "retransmission_proxy": (0.025, 0.01),
        "rate": (0.50, 0.15),
    },

    "12_cloud_gaming": {
        "packet_rate": (70, 15),
        "packet_size_mean": (850, 100),
        "packet_size_std": (180, 35),
        "flow_duration": (90, 30),
        "burst_frequency": (0.75, 0.10),
        "ul_dl_ratio": (0.30, 0.06),
        "interarrival_mean": (0.015, 0.005),
        "interarrival_std": (0.008, 0.003),
        "retransmission_proxy": (0.025, 0.01),
        "rate": (20, 6),
    },

    "13_ar_vr": {
        "packet_rate": (80, 18),
        "packet_size_mean": (950, 120),
        "packet_size_std": (200, 40),
        "flow_duration": (70, 25),
        "burst_frequency": (0.80, 0.08),
        "ul_dl_ratio": (0.50, 0.10),
        "interarrival_mean": (0.013, 0.004),
        "interarrival_std": (0.007, 0.002),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (25, 8),
    },

    "14_remote_desktop": {
        "packet_rate": (30, 7),
        "packet_size_mean": (600, 100),
        "packet_size_std": (140, 30),
        "flow_duration": (100, 40),
        "burst_frequency": (0.55, 0.10),
        "ul_dl_ratio": (0.60, 0.12),
        "interarrival_mean": (0.035, 0.010),
        "interarrival_std": (0.018, 0.006),
        "retransmission_proxy": (0.025, 0.01),
        "rate": (5, 2),
    },

    "15_online_exam": {
        "packet_rate": (20, 5),
        "packet_size_mean": (500, 90),
        "packet_size_std": (120, 25),
        "flow_duration": (60, 25),
        "burst_frequency": (0.45, 0.08),
        "ul_dl_ratio": (0.70, 0.15),
        "interarrival_mean": (0.05, 0.015),
        "interarrival_std": (0.025, 0.008),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (1.5, 0.5),
    },

    "16_file_download": {
        "packet_rate": (100, 25),
        "packet_size_mean": (1100, 100),
        "packet_size_std": (220, 40),
        "flow_duration": (50, 20),
        "burst_frequency": (0.85, 0.07),
        "ul_dl_ratio": (0.05, 0.02),
        "interarrival_mean": (0.010, 0.003),
        "interarrival_std": (0.005, 0.002),
        "retransmission_proxy": (0.03, 0.012),
        "rate": (50, 20),
    },

    "17_backup": {
        "packet_rate": (90, 20),
        "packet_size_mean": (1050, 120),
        "packet_size_std": (210, 40),
        "flow_duration": (120, 40),
        "burst_frequency": (0.80, 0.10),
        "ul_dl_ratio": (0.08, 0.03),
        "interarrival_mean": (0.012, 0.004),
        "interarrival_std": (0.006, 0.002),
        "retransmission_proxy": (0.035, 0.012),
        "rate": (35, 15),
    },

    "18_software_update": {
        "packet_rate": (110, 25),
        "packet_size_mean": (1100, 100),
        "packet_size_std": (220, 40),
        "flow_duration": (80, 30),
        "burst_frequency": (0.90, 0.06),
        "ul_dl_ratio": (0.05, 0.02),
        "interarrival_mean": (0.009, 0.003),
        "interarrival_std": (0.005, 0.002),
        "retransmission_proxy": (0.03, 0.01),
        "rate": (60, 20),
    },

    "19_p2p": {
        "packet_rate": (95, 25),
        "packet_size_mean": (1000, 150),
        "packet_size_std": (250, 50),
        "flow_duration": (100, 40),
        "burst_frequency": (0.75, 0.12),
        "ul_dl_ratio": (0.30, 0.08),
        "interarrival_mean": (0.011, 0.004),
        "interarrival_std": (0.006, 0.002),
        "retransmission_proxy": (0.04, 0.015),
        "rate": (30, 15),
    },

    "20_upload": {
        "packet_rate": (80, 20),
        "packet_size_mean": (950, 130),
        "packet_size_std": (200, 45),
        "flow_duration": (70, 30),
        "burst_frequency": (0.70, 0.10),
        "ul_dl_ratio": (3.0, 0.5),
        "interarrival_mean": (0.014, 0.004),
        "interarrival_std": (0.007, 0.002),
        "retransmission_proxy": (0.03, 0.012),
        "rate": (25, 12),
    },

    "21_emergency": {
        "packet_rate": (20, 5),
        "packet_size_mean": (450, 80),
        "packet_size_std": (100, 25),
        "flow_duration": (30, 12),
        "burst_frequency": (0.45, 0.08),
        "ul_dl_ratio": (0.8, 0.15),
        "interarrival_mean": (0.05, 0.015),
        "interarrival_std": (0.025, 0.008),
        "retransmission_proxy": (0.01, 0.005),
        "rate": (2, 0.8),
    },

    "22_disaster_stream": {
        "packet_rate": (65, 15),
        "packet_size_mean": (900, 110),
        "packet_size_std": (190, 40),
        "flow_duration": (50, 20),
        "burst_frequency": (0.78, 0.08),
        "ul_dl_ratio": (0.25, 0.05),
        "interarrival_mean": (0.018, 0.005),
        "interarrival_std": (0.009, 0.003),
        "retransmission_proxy": (0.015, 0.007),
        "rate": (15, 5),
    },

    "23_medical_telemetry": {
        "packet_rate": (35, 7),
        "packet_size_mean": (300, 50),
        "packet_size_std": (70, 15),
        "flow_duration": (120, 40),
        "burst_frequency": (0.30, 0.06),
        "ul_dl_ratio": (0.9, 0.15),
        "interarrival_mean": (0.035, 0.010),
        "interarrival_std": (0.018, 0.006),
        "retransmission_proxy": (0.01, 0.005),
        "rate": (0.5, 0.15),
    },

    "24_public_broadcast": {
        "packet_rate": (75, 18),
        "packet_size_mean": (950, 120),
        "packet_size_std": (200, 40),
        "flow_duration": (100, 40),
        "burst_frequency": (0.82, 0.08),
        "ul_dl_ratio": (0.15, 0.03),
        "interarrival_mean": (0.014, 0.004),
        "interarrival_std": (0.007, 0.002),
        "retransmission_proxy": (0.02, 0.01),
        "rate": (30, 10),
    },

    "25_operator_control": {
        "packet_rate": (10, 3),
        "packet_size_mean": (200, 40),
        "packet_size_std": (50, 12),
        "flow_duration": (90, 30),
        "burst_frequency": (0.20, 0.05),
        "ul_dl_ratio": (1.0, 0.1),
        "interarrival_mean": (0.10, 0.03),
        "interarrival_std": (0.05, 0.015),
        "retransmission_proxy": (0.005, 0.003),
        "rate": (0.05, 0.02),
    },
}


# ============================================================
# SYNTHETIC DATA GENERATOR
# ============================================================

def positive_normal(mean, std, size):

    values = rng.normal(
        mean,
        std,
        size
    )

    return np.maximum(
        values,
        0.000001
    )


def generate_dataset():

    rows = []

    print("\nGenerating synthetic M03 dataset...")
    print(
        f"Classes: {len(TRAFFIC_CLASSES)}"
    )
    print(
        f"Samples per class: {SAMPLES_PER_CLASS}"
    )

    scenario_names = [
        "normal",
        "rush_hour",
        "flash_crowd",
        "overload",
        "recovery",
    ]

    for class_id in TRAFFIC_CLASSES:

        profile = CLASS_PROFILES[class_id]

        for i in range(
            SAMPLES_PER_CLASS
        ):

            scenario = scenario_names[
                i % len(scenario_names)
            ]

            session_id = (
                f"{scenario}_"
                f"{class_id}_"
                f"session_{i // 5}"
            )

            row = {}

            for feature in FEATURE_COLUMNS:

                if feature.startswith(
                    "rolling_rate"
                ):

                    continue

                if feature == "rate":

                    continue

                mean, std = profile[
                    feature
                ]

                row[feature] = float(
                    positive_normal(
                        mean,
                        std,
                        1
                    )[0]
                )

            base_rate = positive_normal(
                profile["rate"][0],
                profile["rate"][1],
                1,
            )[0]

            # Scenario variation
            if scenario == "rush_hour":
                base_rate *= 1.15

            elif scenario == "flash_crowd":
                base_rate *= 1.30

            elif scenario == "overload":
                base_rate *= 1.45

            elif scenario == "recovery":
                base_rate *= 0.80

            row["rolling_rate_1s"] = float(
                base_rate * rng.uniform(
                    0.90,
                    1.10
                )
            )

            row["rolling_rate_5s"] = float(
                base_rate * rng.uniform(
                    0.85,
                    1.05
                )
            )

            row["rolling_rate_10s"] = float(
                base_rate * rng.uniform(
                    0.80,
                    1.02
                )
            )

            row["class_id"] = class_id

            row["scenario_id"] = scenario

            row["session_id"] = session_id

            rows.append(row)

    df = pd.DataFrame(rows)

    return df


# ============================================================
# FEATURE VALIDATION
# ============================================================

def validate_features(df):

    missing = [
        column
        for column in FEATURE_COLUMNS
        if column not in df.columns
    ]

    if missing:

        raise ValueError(
            "Missing features: "
            + str(missing)
        )

    X = df[
        FEATURE_COLUMNS
    ].copy()

    X = X.replace(
        [np.inf, -np.inf],
        np.nan
    )

    return X


# ============================================================
# GROUPED TRAIN / TEST SPLIT
# ============================================================

def split_dataset(df):

    groups = (
        df["scenario_id"].astype(str)
        + "::"
        + df["session_id"].astype(str)
    )

    splitter = GroupShuffleSplit(
        n_splits=1,
        test_size=0.20,
        random_state=SEED,
    )

    train_idx, test_idx = next(
        splitter.split(
            df,
            df["class_id"],
            groups=groups,
        )
    )

    train_df = df.iloc[
        train_idx
    ].reset_index(drop=True)

    test_df = df.iloc[
        test_idx
    ].reset_index(drop=True)

    return train_df, test_df


# ============================================================
# BUILD MODEL
# ============================================================

def build_model():

    base_model = Pipeline(
        steps=[
            (
                "imputer",
                SimpleImputer(
                    strategy="median"
                ),
            ),

            (
                "classifier",
                RandomForestClassifier(
                    n_estimators=250,
                    max_depth=None,
                    min_samples_leaf=1,
                    class_weight="balanced_subsample",
                    random_state=SEED,
                    n_jobs=-1,
                ),
            ),
        ]
    )

    # Calibration provides better probability estimates.
    calibrated = CalibratedClassifierCV(
        estimator=base_model,
        method="sigmoid",
        cv=3,
    )

    return calibrated


# ============================================================
# MULTICLASS BRIER SCORE
# ============================================================

def multiclass_brier(
    y_true,
    probabilities,
    classes,
):

    class_to_index = {
        cls: i
        for i, cls in enumerate(classes)
    }

    total = 0.0

    for true_label, probs in zip(
        y_true,
        probabilities,
    ):

        target = np.zeros(
            len(classes)
        )

        target[
            class_to_index[true_label]
        ] = 1.0

        total += np.mean(
            (probs - target) ** 2
        )

    return float(
        total / len(y_true)
    )


# ============================================================
# TOP-K
# ============================================================

def get_top_k(
    probabilities,
    classes,
    k=3,
):

    order = np.argsort(
        probabilities
    )[::-1][:k]

    return [
        {
            "class_id": str(
                classes[index]
            ),

            "probability": float(
                probabilities[index]
            ),
        }

        for index in order
    ]


# ============================================================
# SERVICE CATEGORY FALLBACK
# ============================================================

def get_service_category(
    probabilities,
    classes,
):

    category_scores = {}

    for class_id, probability in zip(
        classes,
        probabilities,
    ):

        category = SERVICE_CATEGORIES.get(
            str(class_id),
            "UNKNOWN_SERVICE",
        )

        category_scores[
            category
        ] = (
            category_scores.get(
                category,
                0.0,
            )
            + float(probability)
        )

    if not category_scores:

        return "UNKNOWN_SERVICE"

    return max(
        category_scores.items(),
        key=lambda item: item[1],
    )[0]


# ============================================================
# OOD DETECTOR
# ============================================================

def train_ood_detector(
    X_train,
):

    # Median imputation before OOD detection.
    imputer = SimpleImputer(
        strategy="median"
    )

    X_clean = imputer.fit_transform(
        X_train
    )

    detector = IsolationForest(
        n_estimators=200,
        contamination=0.05,
        random_state=SEED,
        n_jobs=-1,
    )

    detector.fit(X_clean)

    return imputer, detector


# ============================================================
# MAIN
# ============================================================

def main():

    print()
    print("=" * 65)
    print("      M03 TRAFFIC CLASSIFIER - STANDALONE")
    print("=" * 65)

    print(
        f"Model version : {MODEL_VERSION}"
    )

    print(
        f"Seed          : {SEED}"
    )

    print(
        f"Features      : {len(FEATURE_COLUMNS)}"
    )

    print(
        f"Classes       : {len(TRAFFIC_CLASSES)}"
    )

    print("=" * 65)

    # --------------------------------------------------------
    # 1. Generate data
    # --------------------------------------------------------

    df = generate_dataset()

    print()
    print(
        f"Generated rows: {len(df)}"
    )

    # --------------------------------------------------------
    # 2. Validate features
    # --------------------------------------------------------

    X_all = validate_features(
        df
    )

    y_all = df[
        "class_id"
    ]

    # --------------------------------------------------------
    # 3. Group split
    # --------------------------------------------------------

    train_df, test_df = split_dataset(
        df
    )

    X_train = validate_features(
        train_df
    )

    X_test = validate_features(
        test_df
    )

    y_train = train_df[
        "class_id"
    ]

    y_test = test_df[
        "class_id"
    ]

    print()
    print(
        f"Training rows: {len(train_df)}"
    )

    print(
        f"Testing rows : {len(test_df)}"
    )

    # --------------------------------------------------------
    # 4. Train classifier
    # --------------------------------------------------------

    print()
    print(
        "Training calibrated Random Forest..."
    )

    model = build_model()

    with warnings.catch_warnings():

        warnings.simplefilter(
            "ignore"
        )

        model.fit(
            X_train,
            y_train,
        )

    print(
        "Training completed."
    )

    # --------------------------------------------------------
    # 5. Predictions
    # --------------------------------------------------------

    probabilities = (
        model.predict_proba(
            X_test
        )
    )

    classes = model.classes_

    predictions = classes[
        np.argmax(
            probabilities,
            axis=1
        )
    ]

    # --------------------------------------------------------
    # 6. Metrics
    # --------------------------------------------------------

    macro_f1 = f1_score(
        y_test,
        predictions,
        average="macro",
        zero_division=0,
    )

    macro_precision = precision_score(
        y_test,
        predictions,
        average="macro",
        zero_division=0,
    )

    macro_recall = recall_score(
        y_test,
        predictions,
        average="macro",
        zero_division=0,
    )

    accuracy = accuracy_score(
        y_test,
        predictions,
    )

    brier = multiclass_brier(
        y_test,
        probabilities,
        classes,
    )

    max_confidence = (
        probabilities.max(
            axis=1
        )
    )

    low_confidence_rate = float(
        np.mean(
            max_confidence
            < UNKNOWN_THRESHOLD
        )
    )

    # --------------------------------------------------------
    # 7. OOD detector
    # --------------------------------------------------------

    ood_imputer, ood_detector = (
        train_ood_detector(
            X_train
        )
    )

    X_test_clean = (
        ood_imputer.transform(
            X_test
        )
    )

    ood_predictions = (
        ood_detector.predict(
            X_test_clean
        )
    )

    ood_rate = float(
        np.mean(
            ood_predictions == -1
        )
    )

    # --------------------------------------------------------
    # 8. Confusion matrix
    # --------------------------------------------------------

    matrix = confusion_matrix(
        y_test,
        predictions,
        labels=classes,
    )

    report = classification_report(
        y_test,
        predictions,
        labels=classes,
        zero_division=0,
        output_dict=True,
    )

    # --------------------------------------------------------
    # 9. Print results
    # --------------------------------------------------------

    print()
    print("=" * 65)
    print("              M03 EVALUATION")
    print("=" * 65)

    print(
        f"Accuracy              : {accuracy:.4f}"
    )

    print(
        f"Macro Precision       : {macro_precision:.4f}"
    )

    print(
        f"Macro Recall          : {macro_recall:.4f}"
    )

    print(
        f"Macro F1              : {macro_f1:.4f}"
    )

    print(
        f"Multiclass Brier      : {brier:.4f}"
    )

    print(
        f"Low Confidence Rate   : "
        f"{low_confidence_rate:.4f}"
    )

    print(
        f"OOD Rate              : "
        f"{ood_rate:.4f}"
    )

    print("=" * 65)

    # --------------------------------------------------------
    # 10. Print classification report
    # --------------------------------------------------------

    print()
    print("Per-class metrics:")
    print()

    report_df = pd.DataFrame(
        report
    ).T

    print(
        report_df[
            [
                "precision",
                "recall",
                "f1-score",
                "support",
            ]
        ].round(3).to_string()
    )

    # --------------------------------------------------------
    # 11. Save artifacts
    # --------------------------------------------------------

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    artifact = {

        "model": model,

        "ood_imputer":
            ood_imputer,

        "ood_detector":
            ood_detector,

        "feature_columns":
            FEATURE_COLUMNS,

        "feature_schema_version":
            FEATURE_SCHEMA_VERSION,

        "class_ids":
            [
                str(x)
                for x in classes
            ],

        "service_categories":
            SERVICE_CATEGORIES,

        "unknown_threshold":
            UNKNOWN_THRESHOLD,

        "model_version":
            MODEL_VERSION,

        "seed":
            SEED,

        "warning":
            (
                "This classifier was trained and "
                "evaluated on synthetic data only. "
                "Synthetic performance does not "
                "establish generalization to real "
                "network traffic."
            ),
    }

    joblib.dump(
        artifact,
        MODEL_PATH
    )

    metrics = {

        "model_version":
            MODEL_VERSION,

        "feature_schema_version":
            FEATURE_SCHEMA_VERSION,

        "seed":
            SEED,

        "samples_per_class":
            SAMPLES_PER_CLASS,

        "total_samples":
            int(len(df)),

        "train_samples":
            int(len(train_df)),

        "test_samples":
            int(len(test_df)),

        "num_classes":
            len(classes),

        "feature_columns":
            FEATURE_COLUMNS,

        "metrics": {

            "accuracy":
                float(accuracy),

            "macro_precision":
                float(macro_precision),

            "macro_recall":
                float(macro_recall),

            "macro_f1":
                float(macro_f1),

            "multiclass_brier":
                float(brier),

            "low_confidence_rate":
                float(low_confidence_rate),

            "ood_rate":
                float(ood_rate),
        },

        "confusion_matrix":
            matrix.tolist(),

        "classes":
            [
                str(x)
                for x in classes
            ],

        "classification_report":
            report,

        "synthetic_to_real_warning":
            (
                "IMPORTANT: Results are based "
                "on synthetic traffic metadata. "
                "They must not be interpreted "
                "as measured real-network "
                "application classification "
                "performance."
            ),
    }

    with open(
        METRICS_PATH,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            metrics,
            file,
            indent=2,
        )

    print()
    print(
        "Artifacts saved:"
    )

    print(
        f"Model   : {MODEL_PATH}"
    )

    print(
        f"Metrics : {METRICS_PATH}"
    )

    # --------------------------------------------------------
    # 12. Standalone prediction demonstration
    # --------------------------------------------------------

    print()
    print("=" * 65)
    print("          LIVE PREDICTION DEMO")
    print("=" * 65)

    sample = X_test.iloc[
        0:1
    ]

    sample_probabilities = (
        model.predict_proba(
            sample
        )[0]
    )

    top_k = get_top_k(
        sample_probabilities,
        classes,
        TOP_K,
    )

    best_index = int(
        np.argmax(
            sample_probabilities
        )
    )

    confidence = float(
        sample_probabilities[
            best_index
        ]
    )

    ood_value = (
        ood_detector.predict(
            ood_imputer.transform(
                sample
            )
        )[0]
        == -1
    )

    if (
        confidence
        < UNKNOWN_THRESHOLD
        or ood_value
    ):

        predicted_class = "UNKNOWN"

        category = (
            get_service_category(
                sample_probabilities,
                classes,
            )
        )

    else:

        predicted_class = str(
            classes[best_index]
        )

        category = (
            SERVICE_CATEGORIES.get(
                predicted_class,
                "UNKNOWN_SERVICE",
            )
        )

    print()
    print(
        f"Predicted Class    : "
        f"{predicted_class}"
    )

    print(
        f"Confidence         : "
        f"{confidence:.4f}"
    )

    print(
        f"Service Category   : "
        f"{category}"
    )

    print(
        f"OOD                : "
        f"{ood_value}"
    )

    print()
    print("Top-K probabilities:")

    for item in top_k:

        print(
            f"  {item['class_id']:<25}"
            f"{item['probability']:.4f}"
        )

    print()
    print("=" * 65)
    print("             M03 COMPLETE")
    print("=" * 65)

    print()
    print(
        "This standalone runner can be deleted "
        "when M03 is integrated."
    )


if __name__ == "__main__":

    main()