"""
Module 7 - QoE, SLA and Fairness Engine

Provides:
- Activity-specific QoE calculations
- Throughput satisfaction
- Latency satisfaction
- Packet-loss satisfaction
- Streaming QoE
- SLA violation detection
- SLA violation rate
- Starvation detection
- Jain fairness
- Temporal sequence generation
- Feature leakage detection
- Deployment-safe ML features
- Distribution-shift detection
- Dependency-free anomaly scores
- Formula/version metadata
"""

from __future__ import annotations

import math
from statistics import mean, pstdev
from typing import Any, Dict, List, Sequence


class QoECalculator:
    """
    Main QoE calculation engine.

    All scores are normalized to approximately [0, 1].
    """

    FORMULA_VERSION = "M07-QOE-v1.0"

    def __init__(
        self,
        throughput_weight: float = 0.40,
        latency_weight: float = 0.30,
        loss_weight: float = 0.30,
    ):
        total = (
            throughput_weight
            + latency_weight
            + loss_weight
        )

        if total <= 0:
            raise ValueError("QoE weights must have a positive sum.")

        self.weights = {
            "throughput": throughput_weight / total,
            "latency": latency_weight / total,
            "loss": loss_weight / total,
        }

    # ============================================================
    # BASIC SATISFACTION FUNCTIONS
    # ============================================================

    @staticmethod
    def throughput_satisfaction(
        delivered_mbps: float,
        target_mbps: float,
        eps: float = 1e-9,
    ) -> float:
        """
        throughput_satisfaction =
        clip(delivered / max(target, eps), 0, 1)
        """

        if delivered_mbps < 0:
            raise ValueError("delivered_mbps cannot be negative.")

        if target_mbps < 0:
            raise ValueError("target_mbps cannot be negative.")

        denominator = max(target_mbps, eps)

        value = delivered_mbps / denominator

        return max(0.0, min(1.0, value))

    @staticmethod
    def latency_satisfaction(
        delay_ms: float,
        budget_ms: float,
        scale_ms: float = 50.0,
    ) -> float:
        """
        latency_satisfaction =
        exp(-max(0, delay - budget) / scale)
        """

        if delay_ms < 0:
            raise ValueError("delay_ms cannot be negative.")

        if budget_ms < 0:
            raise ValueError("budget_ms cannot be negative.")

        if scale_ms <= 0:
            raise ValueError("scale_ms must be > 0.")

        excess = max(
            0.0,
            delay_ms - budget_ms
        )

        return math.exp(
            -excess / scale_ms
        )

    @staticmethod
    def loss_satisfaction(
        loss_fraction: float,
        tolerance: float = 0.05,
    ) -> float:
        """
        loss_satisfaction =
        exp(-loss_fraction / tolerance)
        """

        if not 0 <= loss_fraction <= 1:
            raise ValueError(
                "loss_fraction must be between 0 and 1."
            )

        if tolerance <= 0:
            raise ValueError(
                "tolerance must be > 0."
            )

        return math.exp(
            -loss_fraction / tolerance
        )

    # ============================================================
    # WEIGHTED GEOMETRIC MEAN
    # ============================================================

    @staticmethod
    def weighted_geometric_mean(
        scores: Sequence[float],
        weights: Sequence[float],
    ) -> float:

        if len(scores) != len(weights):
            raise ValueError(
                "scores and weights must have equal length."
            )

        if not scores:
            raise ValueError(
                "At least one score is required."
            )

        total_weight = sum(weights)

        if total_weight <= 0:
            raise ValueError(
                "Weights must have positive sum."
            )

        result = 0.0

        for score, weight in zip(scores, weights):

            score = max(
                0.0,
                min(1.0, float(score))
            )

            if score == 0:
                return 0.0

            normalized_weight = (
                weight / total_weight
            )

            result += (
                normalized_weight
                * math.log(score)
            )

        return math.exp(result)

    # ============================================================
    # GENERAL QoE
    # ============================================================

    def calculate_qoe(
        self,
        throughput_mbps: float,
        target_mbps: float,
        delay_ms: float,
        delay_budget_ms: float,
        loss_fraction: float,
    ) -> float:

        throughput_score = (
            self.throughput_satisfaction(
                throughput_mbps,
                target_mbps
            )
        )

        latency_score = (
            self.latency_satisfaction(
                delay_ms,
                delay_budget_ms
            )
        )

        loss_score = (
            self.loss_satisfaction(
                loss_fraction
            )
        )

        return self.weighted_geometric_mean(
            [
                throughput_score,
                latency_score,
                loss_score,
            ],
            [
                self.weights["throughput"],
                self.weights["latency"],
                self.weights["loss"],
            ],
        )

    # ============================================================
    # STREAMING QoE
    # ============================================================

    def streaming_qoe(
        self,
        bitrate_mbps: float,
        target_mbps: float,
        startup_delay_ms: float,
        stall_probability: float,
    ) -> float:

        if startup_delay_ms < 0:
            raise ValueError(
                "startup_delay_ms cannot be negative."
            )

        if not 0 <= stall_probability <= 1:
            raise ValueError(
                "stall_probability must be between 0 and 1."
            )

        bitrate_score = (
            self.throughput_satisfaction(
                bitrate_mbps,
                target_mbps
            )
        )

        startup_score = math.exp(
            -startup_delay_ms / 5000.0
        )

        stall_score = 1.0 - stall_probability

        return self.weighted_geometric_mean(
            [
                bitrate_score,
                startup_score,
                stall_score,
            ],
            [0.50, 0.20, 0.30],
        )

    # ============================================================
    # SLA
    # ============================================================

    @staticmethod
    def sla_violation(
        value: float,
        threshold: float,
    ) -> bool:

        return float(value) > float(threshold)

    @staticmethod
    def sla_violation_rate(
        values: Sequence[float],
        threshold: float,
    ) -> float:

        if not values:
            return 0.0

        violations = sum(
            1
            for value in values
            if value > threshold
        )

        return violations / len(values)

    # ============================================================
    # STARVATION
    # ============================================================

    @staticmethod
    def detect_starvation(
        throughput_history: Sequence[float],
        minimum_throughput: float,
        consecutive_ticks: int,
    ) -> bool:

        if consecutive_ticks <= 0:
            raise ValueError(
                "consecutive_ticks must be > 0."
            )

        current = 0

        for value in throughput_history:

            if value < minimum_throughput:
                current += 1

                if current >= consecutive_ticks:
                    return True

            else:
                current = 0

        return False

    # ============================================================
    # JAIN FAIRNESS
    # ============================================================

    @staticmethod
    def jain_fairness(
        values: Sequence[float],
    ) -> float:

        if not values:
            return 0.0

        values = [
            max(0.0, float(x))
            for x in values
        ]

        n = len(values)

        total = sum(values)
        squared = sum(
            x * x
            for x in values
        )

        if squared == 0:
            return 1.0

        return (
            total * total
        ) / (
            n * squared
        )

    # ============================================================
    # TEMPORAL FEATURES
    # ============================================================

    @staticmethod
    def build_temporal_sequences(
        data: Sequence[Sequence[float]],
        sequence_length: int,
    ) -> List[List[List[float]]]:

        if sequence_length <= 0:
            raise ValueError(
                "sequence_length must be > 0."
            )

        data = [list(row) for row in data]

        if len(data) < sequence_length:
            return []

        sequences = []

        for i in range(
            len(data) - sequence_length + 1
        ):
            sequences.append(
                data[
                    i:i + sequence_length
                ]
            )

        return sequences

    # ============================================================
    # FEATURE LEAKAGE
    # ============================================================

    @staticmethod
    def detect_feature_leakage(
        features: Sequence[str],
    ) -> Dict[str, Any]:

        leakage_keywords = [
            "future",
            "next",
            "outcome",
            "target",
            "label",
            "post",
            "after",
        ]

        suspicious = []

        for feature in features:

            name = str(feature).lower()

            for keyword in leakage_keywords:

                if keyword in name:
                    suspicious.append(
                        feature
                    )
                    break

        return {
            "leakage_detected": bool(
                suspicious
            ),
            "suspicious_features": suspicious,
        }

    # ============================================================
    # DEPLOYMENT-SAFE FEATURES
    # ============================================================

    @staticmethod
    def deployment_safe_features(
        throughput: float,
        latency: float,
        packet_loss: float,
    ) -> Dict[str, float]:

        return {
            "throughput": float(throughput),
            "latency": float(latency),
            "packet_loss": float(packet_loss),
        }

    # ============================================================
    # DISTRIBUTION SHIFT
    # ============================================================

    @staticmethod
    def detect_distribution_shift(
        reference: Sequence[float],
        current: Sequence[float],
        threshold: float = 0.50,
    ) -> Dict[str, Any]:

        if not reference:
            raise ValueError(
                "reference cannot be empty."
            )

        if not current:
            raise ValueError(
                "current cannot be empty."
            )

        reference_mean = mean(reference)
        current_mean = mean(current)

        reference_std = pstdev(reference)

        scale = max(
            abs(reference_mean),
            reference_std,
            1e-9,
        )

        shift = abs(
            current_mean - reference_mean
        ) / scale

        return {
            "reference_mean": reference_mean,
            "current_mean": current_mean,
            "shift_score": shift,
            "shift_detected": shift > threshold,
        }

    # ============================================================
    # ANOMALY SCORES
    # ============================================================

    @staticmethod
    def anomaly_scores(
        values: Sequence[float],
    ) -> List[float]:

        if not values:
            return []

        values = [
            float(x)
            for x in values
        ]

        avg = mean(values)
        std = pstdev(values)

        if std == 0:
            return [0.0] * len(values)

        return [
            abs(x - avg) / std
            for x in values
        ]

    # ============================================================
    # FORMULA VERSION
    # ============================================================

    @classmethod
    def formula_version(cls) -> str:
        return cls.FORMULA_VERSION

    # ============================================================
    # COMPLETE METRICS
    # ============================================================

    def calculate_all(
        self,
        throughput_mbps: float,
        target_mbps: float,
        delay_ms: float,
        delay_budget_ms: float,
        loss_fraction: float,
    ) -> Dict[str, Any]:

        throughput = self.throughput_satisfaction(
            throughput_mbps,
            target_mbps,
        )

        latency = self.latency_satisfaction(
            delay_ms,
            delay_budget_ms,
        )

        loss = self.loss_satisfaction(
            loss_fraction,
        )

        qoe = self.calculate_qoe(
            throughput_mbps,
            target_mbps,
            delay_ms,
            delay_budget_ms,
            loss_fraction,
        )

        return {
            "throughput_satisfaction": throughput,
            "latency_satisfaction": latency,
            "loss_satisfaction": loss,
            "qoe": qoe,
            "formula_version": self.FORMULA_VERSION,
            "weights": dict(self.weights),
        }


# ================================================================
# DIRECT TEST
# ================================================================

if __name__ == "__main__":

    print("=" * 60)
    print("MODULE 7 - QoE CALCULATOR")
    print("=" * 60)

    calculator = QoECalculator()

    result = calculator.calculate_all(
        throughput_mbps=50,
        target_mbps=25,
        delay_ms=30,
        delay_budget_ms=100,
        loss_fraction=0.01,
    )

    print("\nQoE Results:")

    for key, value in result.items():
        print(f"{key}: {value}")

    print("\nStreaming QoE:")

    streaming = calculator.streaming_qoe(
        bitrate_mbps=8,
        target_mbps=5,
        startup_delay_ms=500,
        stall_probability=0.02,
    )

    print(streaming)

    print("\nJain Fairness:")

    fairness = calculator.jain_fairness(
        [10, 10, 10, 10]
    )

    print(fairness)

    print("\nFormula Version:")
    print(calculator.formula_version())

    print("\nQoE Calculator test completed successfully.")