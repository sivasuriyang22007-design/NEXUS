# M04_SimPy_Network/simulation_engine.py

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, Any
from collections import defaultdict

from .environment import SimulationEnvironment
from .network import Network, NetworkConfig
from .congestion import CongestionMonitor


@dataclass
class SimulationConfig:

    duration_seconds: int = 60
    tick_seconds: float = 1.0

    mode: str = "offline"

    realtime_factor: float = 1.0
    realtime_strict: bool = False

    seed: int = 42

    cell_capacity_mbps: float = 1000.0

    queue_bytes: int = 10_000_000

    propagation_delay_ms: float = 5.0

    loss_probability: float = 0.0


@dataclass
class TickMetrics:

    tick: int
    timestamp_seconds: float

    offered_mbps: float
    delivered_mbps: float

    utilization_percent: float

    queue_bytes: int

    dropped_packets: int

    dropped_bits: int

    p50_latency_ms: float
    p95_latency_ms: float

    congestion: dict = field(
        default_factory=dict
    )


class SimulationEngine:

    def __init__(
        self,
        config: SimulationConfig | None = None,
    ):

        self.config = (
            config
            if config is not None
            else SimulationConfig()
        )

        self.env_manager = SimulationEnvironment(
            mode=self.config.mode,
            realtime_factor=self.config.realtime_factor,
            strict=self.config.realtime_strict,
        )

        self.env = self.env_manager.env

        self.network = Network(
            env=self.env,
            config=NetworkConfig(
                propagation_delay_ms=(
                    self.config.propagation_delay_ms
                ),
                queue_bytes=self.config.queue_bytes,
                loss_probability=(
                    self.config.loss_probability
                ),
            ),
            seed=self.config.seed,
        )

        self.congestion_monitor = (
            CongestionMonitor()
        )

        self.scheduler_callback: Optional[
            Callable
        ] = None

        self.event_callback: Optional[
            Callable
        ] = None

        self.packet_arrival_process = None

        self.tick_metrics: list[
            TickMetrics
        ] = []

        self._previous_offered_bits = 0
        self._previous_delivered_bits = 0

        self._previous_dropped_packets = 0
        self._previous_dropped_bits = 0

        self._running = False

        self._setup_default_network()

    # =========================================================
    # NETWORK SETUP
    # =========================================================

    def _setup_default_network(self):

        self.network.add_cell(
            cell_id="CELL_001",
            capacity_mbps=(
                self.config.cell_capacity_mbps
            ),
            usable_mbps=(
                self.config.cell_capacity_mbps
            ),
            link_efficiency=1.0,
        )

        self.network.add_link(
            link_id="LINK_001",
            capacity_mbps=(
                self.config.cell_capacity_mbps
            ),
            propagation_delay_ms=(
                self.config.propagation_delay_ms
            ),
            queue_bytes=(
                self.config.queue_bytes
            ),
            loss_probability=(
                self.config.loss_probability
            ),
        )

        self.network.add_route(
            source_cell="CELL_001",
            destination="internet",
            next_hop="UPLINK",
            link_id="LINK_001",
        )

    # =========================================================
    # RESET
    # =========================================================

    def reset(
        self,
        seed: Optional[int] = None,
    ):

        if seed is not None:
            self.config.seed = seed

        self.tick_metrics.clear()

        self._previous_offered_bits = 0
        self._previous_delivered_bits = 0

        self._previous_dropped_packets = 0
        self._previous_dropped_bits = 0

        self._running = False

    # =========================================================
    # CALLBACKS
    # =========================================================

    def set_scheduler(
        self,
        callback: Callable,
    ):

        self.scheduler_callback = callback

    def set_event_callback(
        self,
        callback: Callable,
    ):

        self.event_callback = callback

    # =========================================================
    # PACKET ARRIVAL
    # =========================================================

    def inject_packet(
        self,
        packet,
        source_cell: str = "CELL_001",
        destination: str = "internet",
    ) -> bool:

        return self.network.send_packet(
            packet=packet,
            source_cell=source_cell,
            destination=destination,
        )

    # =========================================================
    # EXTERNAL ARRIVAL TRACE
    # =========================================================

    def schedule_packet(
        self,
        packet,
        arrival_time: float,
        source_cell: str = "CELL_001",
        destination: str = "internet",
    ):

        def arrival_process():

            wait_time = max(
                0.0,
                arrival_time - self.env.now,
            )

            yield self.env.timeout(
                wait_time
            )

            accepted = self.inject_packet(
                packet=packet,
                source_cell=source_cell,
                destination=destination,
            )

            if self.event_callback:

                self.event_callback(
                    {
                        "type": "PACKET_ARRIVAL",
                        "time": self.env.now,
                        "accepted": accepted,
                    }
                )

        return self.env.process(
            arrival_process()
        )

    # =========================================================
    # SCHEDULER TICK
    # =========================================================

    def _scheduler_tick(self):

        if self.scheduler_callback is None:
            return

        observation = self.get_observation()

        try:

            plan = self.scheduler_callback(
                observation
            )

            self._apply_allocation_plan(
                plan
            )

        except Exception as exc:

            if self.event_callback:

                self.event_callback(
                    {
                        "type": "SCHEDULER_ERROR",
                        "time": self.env.now,
                        "error": str(exc),
                    }
                )

    def _apply_allocation_plan(
        self,
        plan: Any,
    ):

        """
        Applies allocation to future packet service.

        Expected possible format:

        {
            "LINK_001": 800.0
        }

        or:

        {
            "per_link_grants": {
                "LINK_001": 800.0
            }
        }
        """

        if plan is None:
            return

        if isinstance(plan, dict):

            if "per_link_grants" in plan:

                grants = plan[
                    "per_link_grants"
                ]

            else:

                grants = plan

        else:

            return

        for link_id, grant in grants.items():

            if link_id not in self.network.links:
                continue

            link = self.network.links[
                link_id
            ]

            grant = max(
                0.0,
                float(grant),
            )

            # Never allow configured capacity violation.
            grant = min(
                grant,
                link.capacity_mbps,
            )

            link.current_allocation_mbps = (
                grant
            )

    # =========================================================
    # TICK LOOP
    # =========================================================

    def _tick_process(self):

        tick = 0

        while (
            self.env.now
            < self.config.duration_seconds
        ):

            tick += 1

            self._scheduler_tick()

            yield self.env.timeout(
                self.config.tick_seconds
            )

            metrics = self.collect_tick_metrics(
                tick=tick
            )

            self.tick_metrics.append(
                metrics
            )

            if self.event_callback:

                self.event_callback(
                    {
                        "type": "TICK_METRICS",
                        "tick": tick,
                        "metrics": metrics,
                    }
                )

    # =========================================================
    # METRICS
    # =========================================================

    def collect_tick_metrics(
        self,
        tick: int,
    ) -> TickMetrics:

        elapsed = self.config.tick_seconds

        offered_bits = (
            self.network.total_offered_bits()
        )

        delivered_bits = (
            self.network.total_delivered_bits()
        )

        dropped_packets = sum(
            link.total_dropped_packets
            for link in self.network.links.values()
        )

        dropped_bits = (
            self.network.total_dropped_bits()
        )

        offered_delta = max(
            0,
            offered_bits
            - self._previous_offered_bits,
        )

        delivered_delta = max(
            0,
            delivered_bits
            - self._previous_delivered_bits,
        )

        dropped_packet_delta = max(
            0,
            dropped_packets
            - self._previous_dropped_packets,
        )

        dropped_bits_delta = max(
            0,
            dropped_bits
            - self._previous_dropped_bits,
        )

        self._previous_offered_bits = (
            offered_bits
        )

        self._previous_delivered_bits = (
            delivered_bits
        )

        self._previous_dropped_packets = (
            dropped_packets
        )

        self._previous_dropped_bits = (
            dropped_bits
        )

        offered_mbps = (
            offered_delta * 8
            / elapsed
            / 1_000_000
        )

        delivered_mbps = (
            delivered_delta * 8
            / elapsed
            / 1_000_000
        )

        capacity_mbps = sum(
            link.capacity_mbps
            for link in self.network.links.values()
        )

        if capacity_mbps > 0:

            utilization = min(
                1.0,
                delivered_mbps
                / capacity_mbps,
            )

        else:

            utilization = 0.0

        queue_bytes = sum(
            link.queue.occupancy_bytes
            for link in self.network.links.values()
        )

        queue_ratio = self._queue_ratio()

        loss_percent = self._loss_percent(
            offered_delta,
            dropped_bits_delta,
        )

        congestion_by_cell = {}

        for cell_id, cell in (
            self.network.cells.items()
        ):

            status = (
                self.congestion_monitor.evaluate(
                    cell_id=cell_id,
                    offered_mbps=offered_mbps,
                    capacity_mbps=(
                        cell.capacity_mbps
                    ),
                    queue_ratio=queue_ratio,
                    loss_percent=loss_percent,
                )
            )

            congestion_by_cell[
                cell_id
            ] = status.__dict__

            cell.update_metrics(
                offered_mbps=offered_mbps,
                delivered_mbps=delivered_mbps,
                queue_bytes=queue_bytes,
                loss_percent=loss_percent,
            )

        latencies = []

        for link in self.network.links.values():

            for record in (
                link.transmission_records
            ):

                if (
                    record.delivered_at is not None
                    and record.delivered_at
                    >= self.env.now - elapsed
                ):

                    latencies.append(
                        record.total_delay_ms
                    )

        p50 = self._percentile(
            latencies,
            50,
        )

        p95 = self._percentile(
            latencies,
            95,
        )

        return TickMetrics(
            tick=tick,
            timestamp_seconds=float(
                self.env.now
            ),
            offered_mbps=offered_mbps,
            delivered_mbps=delivered_mbps,
            utilization_percent=(
                utilization * 100.0
            ),
            queue_bytes=queue_bytes,
            dropped_packets=dropped_packet_delta,
            dropped_bits=dropped_bits_delta,
            p50_latency_ms=p50,
            p95_latency_ms=p95,
            congestion=congestion_by_cell,
        )

    # =========================================================
    # OBSERVATION
    # =========================================================

    def get_observation(self) -> dict:

        return {
            "timestamp_seconds": self.env.now,

            "cells": {
                cell_id: cell.snapshot()
                for cell_id, cell
                in self.network.cells.items()
            },

            "links": {
                link_id: {
                    **link.snapshot(),

                    "allocated_mbps":
                        getattr(
                            link,
                            "current_allocation_mbps",
                            link.capacity_mbps,
                        ),
                }

                for link_id, link
                in self.network.links.items()
            },
        }

    # =========================================================
    # RUN
    # =========================================================

    def run(self):

        self._running = True

        self.env.process(
            self._tick_process()
        )

        self.env.run(
            until=self.config.duration_seconds
        )

        self._running = False

        return self.get_results()

    # =========================================================
    # RESULTS
    # =========================================================

    def get_results(self) -> dict:

        return {
            "simulation_time_seconds":
                self.env.now,

            "offered_bits":
                self.network.total_offered_bits(),

            "delivered_bits":
                self.network.total_delivered_bits(),

            "dropped_bits":
                self.network.total_dropped_bits(),

            "tick_metrics": [
                metrics.__dict__
                for metrics
                in self.tick_metrics
            ],

            "network":
                self.network.snapshot(),
        }

    # =========================================================
    # UTILITY FUNCTIONS
    # =========================================================

    def _queue_ratio(self) -> float:

        ratios = []

        for link in self.network.links.values():

            ratios.append(
                link.queue.occupancy_ratio
            )

        if not ratios:
            return 0.0

        return min(
            1.0,
            max(ratios),
        )

    @staticmethod
    def _loss_percent(
        offered_bits: int,
        dropped_bits: int,
    ) -> float:

        if offered_bits <= 0:
            return 0.0

        return min(
            100.0,
            (
                dropped_bits
                / offered_bits
            ) * 100.0,
        )

    @staticmethod
    def _percentile(
        values: list[float],
        percentile: float,
    ) -> float:

        if not values:
            return 0.0

        values = sorted(values)

        index = (
            (len(values) - 1)
            * percentile
            / 100.0
        )

        lower = int(index)

        upper = min(
            lower + 1,
            len(values) - 1,
        )

        fraction = index - lower

        return (
            values[lower]
            + (
                values[upper]
                - values[lower]
            )
            * fraction
        )