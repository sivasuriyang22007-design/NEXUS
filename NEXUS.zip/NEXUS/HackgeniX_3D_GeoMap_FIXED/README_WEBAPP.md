# NEXUS Intelligent Network Resource Scheduler — Web Application

## Overview
Full web UI for the NEXUS multi-module network intelligence system (M01–M10).
The model pipeline and folder structure are **unchanged**. Only the M09 Dashboard
frontend was rebuilt to match the provided reference designs (dark cyan theme,
left sidebar, all required pages) and to support continuous real-time metrics
for 2000+ simulated values with low latency.

## Features
- Login page (demo: **admin / admin**)
- Left sidebar navigation:
  - Dashboard (Network Overview)
  - Line Network
  - AI Scheduler
  - Prediction & Drift
  - Resource Allocation
  - Simulation (What-If)
  - Event Requests (dynamic red badge)
  - Reports
  - Settings
- Real-time KPI polling every 1.5 s via `/api/realtime` (lightweight, does not
  touch the ML pipeline)
- Charts (Chart.js CDN), topology view, tables, toggles
- Preserves all existing backend APIs (`/api/dashboard`, `/api/users`,
  `/api/admin/*`, what-if, config, login)

## Run locally

```bash
cd HackgeniX_3D_GeoMap_FIXED/HackgeniX

# Optional: create venv and install deps
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt

# Generate dashboard data + start server (opens browser)
python integration.py

# Or data only, then serve:
python integration.py --no-serve
python M09_Dashboard/backend/server.py
```

Dashboard opens at `http://127.0.0.1:8080` (or next free port).

## Windows quick start
Double-click `RUN_DASHBOARD.bat` from the project root.

## Cloud / free hosting notes
- The server is pure Python `ThreadingHTTPServer` + static HTML/JS.
- For continuous 2000+ value streams the `/api/realtime` endpoint is intentionally
  lightweight (math-only simulation) so it can be proxied behind any free tier
  (Render, Railway, Fly.io, Cloudflare Workers + external origin, etc.).
- The heavy ML pipeline (`integration.py`) is only run on demand / at startup;
  the UI does not block on it for live metrics.

## Structure (unchanged model code)
```
HackgeniX/
  M01_Virtual_Users/ … M10_Analytics/
  M09_Dashboard/
    backend/server.py      # + /api/realtime
    frontend/index.html    # Full SPA matching reference UI
  integration.py
  main.py
  requirements.txt
```

Model modules, algorithms, and performance characteristics were not modified.
