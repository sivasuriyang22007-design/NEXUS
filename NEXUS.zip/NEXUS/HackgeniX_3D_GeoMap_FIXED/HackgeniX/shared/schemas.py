"""Typed data contracts shared by NEXUS Module 10 components."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class CellSnapshot:
    cell_id: str
    tick: int
    capacity_mbps: float
    offered_mbps: float
    delivered_mbps: float
    forecast_5_mbps: float | None = None
    forecast_10_mbps: float | None = None
    forecast_30_mbps: float | None = None
    active_users: int = 0
    mobility_events: int = 0


@dataclass
class UserSnapshot:
    user_id: str
    cell_id: str
    tick: int
    flow_features: dict[str, float] = field(default_factory=dict)
    target_mbps: float = 0.0
    granted_mbps: float = 0.0
    queue_mbps: float = 0.0
    delay_ms: float = 0.0
    qoe: float = 0.0
    decision_id: str | None = None


@dataclass
class DecisionRecord:
    decision_id: str
    tick: int
    cell_id: str
    input_state: dict[str, Any]
    policy_constraints: list[str]
    proposed_allocation_mbps: dict[str, float]
    final_allocation_mbps: dict[str, float]
    reason_codes: list[str]
    subsequent_outcome: dict[str, Any] = field(default_factory=dict)


@dataclass
class PriorityRequest:
    request_id: str
    requester: str
    status: str
    start_tick: int
    end_tick: int
    requested_capacity_mbps: float
    affected_cells: list[str] = field(default_factory=list)
    audit: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class MetricsSnapshot:
    tick: int
    active_users: int
    offered_load_mbps: float
    served_utilization: float
    free_capacity_mbps: float
    p95_latency_ms: float
    loss_fraction: float
    qoe_proxy: float
    fairness: float
    active_alerts: list[str] = field(default_factory=list)
    simulated: bool = True
