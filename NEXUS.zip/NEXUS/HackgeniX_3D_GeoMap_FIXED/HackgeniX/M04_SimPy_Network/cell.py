# M04_SimPy_Network/cell.py

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Any


@dataclass
class CellState:
    cell_id: str
    total_mbps: float
    usable_mbps: float

    link_efficiency: float = 1.0

    active_users: set[str] = field(
        default_factory=set
    )

    load_mbps: float = 0.0
    delivered_mbps: float = 0.0

    offered_bits: int = 0
    delivered_bits: int = 0
    dropped_bits: int = 0

    queue_bytes: int = 0

    loss_percent: float = 0.0

    capacity_schedule: list[dict] = field(
        default_factory=list
    )

    def effective_capacity_mbps(self) -> float:

        efficiency = min(
            1.0,
            max(0.0, self.link_efficiency),
        )

        return self.usable_mbps * efficiency

    def add_user(self, user_id: str):

        self.active_users.add(str(user_id))

    def remove_user(self, user_id: str):

        self.active_users.discard(str(user_id))

    def update_load(
        self,
        offered_mbps: float,
        delivered_mbps: float,
    ):

        self.load_mbps = max(
            0.0,
            float(offered_mbps),
        )

        self.delivered_mbps = max(
            0.0,
            float(delivered_mbps),
        )

    def utilization(self) -> float:

        capacity = self.effective_capacity_mbps()

        if capacity <= 0:
            return 0.0

        return min(
            1.0,
            self.delivered_mbps / capacity,
        )

    def snapshot(self) -> dict:

        return {
            "cell_id": self.cell_id,
            "total_mbps": self.total_mbps,
            "usable_mbps": self.usable_mbps,
            "effective_capacity_mbps":
                self.effective_capacity_mbps(),

            "link_efficiency":
                self.link_efficiency,

            "active_users":
                len(self.active_users),

            "load_mbps":
                self.load_mbps,

            "delivered_mbps":
                self.delivered_mbps,

            "queue_bytes":
                self.queue_bytes,

            "loss_percent":
                self.loss_percent,

            "utilization":
                self.utilization(),
        }


class Cell:

    def __init__(
        self,
        env,
        cell_id: str,
        total_mbps: float,
        usable_mbps: float | None = None,
        link_efficiency: float = 1.0,
    ):

        self.env = env
        self.state = CellState(
            cell_id=cell_id,
            total_mbps=float(total_mbps),
            usable_mbps=float(
                usable_mbps
                if usable_mbps is not None
                else total_mbps
            ),
            link_efficiency=link_efficiency,
        )

        self.queues: Dict[str, Any] = {}

    @property
    def cell_id(self):
        return self.state.cell_id

    @property
    def capacity_mbps(self):
        return self.state.effective_capacity_mbps()

    def register_user(self, user_id: str):

        self.state.add_user(user_id)

    def remove_user(self, user_id: str):

        self.state.remove_user(user_id)

    def set_link_efficiency(
        self,
        efficiency: float,
    ):

        self.state.link_efficiency = min(
            1.0,
            max(0.0, float(efficiency)),
        )

    def update_metrics(
        self,
        offered_mbps: float,
        delivered_mbps: float,
        queue_bytes: int,
        loss_percent: float,
    ):

        self.state.update_load(
            offered_mbps,
            delivered_mbps,
        )

        self.state.queue_bytes = max(
            0,
            int(queue_bytes),
        )

        self.state.loss_percent = min(
            100.0,
            max(0.0, float(loss_percent)),
        )

    def snapshot(self):

        return self.state.snapshot()