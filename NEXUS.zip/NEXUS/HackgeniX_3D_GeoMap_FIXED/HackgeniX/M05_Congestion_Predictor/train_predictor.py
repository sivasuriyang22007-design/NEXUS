"""Train optional GRU on chronological, scenario-isolated telemetry CSV.
CSV: scenario_id,cell_id,time_s,offered_mbps,delivered_mbps,queue_mbits,
active_users,active_sessions,capacity_mbps. 1 row per simulated second.
"""
import argparse
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import StandardScaler
from .gru_model import GRUForecaster, FEATURES, HORIZONS

BASE = list(FEATURES[:6])

def windows(frame, lookback=30):
    xs, ys = [], []
    for (_, _), g in frame.groupby(["scenario_id", "cell_id"], sort=True):
        g = g.sort_values("time_s")
        t = g.time_s.to_numpy()
        v = g[BASE].to_numpy(dtype=float)
        for i in range(lookback - 1, len(g) - max(HORIZONS)):
            if not np.allclose(np.diff(t[i-lookback+1:i+1]), 1):
                continue
            if not all(np.isclose(t[i+h]-t[i], h) for h in HORIZONS):
                continue
            x = np.column_stack((v[i-lookback+1:i+1],
                                 np.zeros(lookback), v[i-lookback+1:i+1, 5]))
            xs.append(x)
            ys.append([v[i+h, 0] for h in HORIZONS])
    if not xs:
        return np.empty((0, lookback, len(FEATURES))), np.empty((0, 3))
    return np.array(xs), np.array(ys)

def metrics(pred, truth):
    err = pred-truth
    denom = np.abs(pred)+np.abs(truth)
    return {"mae_mbps": float(np.abs(err).mean()),
            "rmse_mbps": float(np.sqrt(np.square(err).mean())),
            "smape_pct": float(np.mean(np.divide(200*np.abs(err), denom,
                                      out=np.zeros_like(err), where=denom>0)))}

def train(csv_path, out_dir, epochs=12, lookback=30, seed=42):
    torch.manual_seed(seed)
    np.random.seed(seed)
    df = pd.read_csv(csv_path).sort_values(["scenario_id", "cell_id", "time_s"])
    required = {"scenario_id", "cell_id", "time_s", *BASE}
    if not required.issubset(df.columns) or df[list(BASE)].isna().any().any():
        raise ValueError("Missing or NaN telemetry columns")
    # Scenario-held-out evaluation; chronological split within remaining scenarios.
    scenarios = sorted(df.scenario_id.unique())
    if len(scenarios) < 3:
        raise ValueError("At least three independent scenarios required")
    test = df[df.scenario_id == scenarios[-1]]
    dev = df[df.scenario_id != scenarios[-1]]
    tr_parts, va_parts = [], []
    for _, g in dev.groupby(["scenario_id", "cell_id"]):
        cut = int(len(g)*0.7)
        tr_parts.append(g.iloc[:cut]); va_parts.append(g.iloc[cut:])
    tr, va = pd.concat(tr_parts), pd.concat(va_parts)
    xtr, ytr = windows(tr, lookback)
    xva, yva = windows(va, lookback)
    xte, yte = windows(test, lookback)
    if min(len(xtr), len(xva), len(xte)) == 0:
        raise ValueError("Need >= lookback+30 consecutive seconds per split")
    scaler = StandardScaler().fit(xtr.reshape(-1, len(FEATURES)))
    def transform(x):
        return torch.tensor(scaler.transform(x.reshape(-1,len(FEATURES))).reshape(x.shape),dtype=torch.float32)
    model = GRUForecaster()
    opt = torch.optim.Adam(model.parameters(), lr=0.002)
    train_x, train_y = transform(xtr), torch.tensor(ytr,dtype=torch.float32)
    val_x = transform(xva)
    best, best_state = float("inf"), None
    for epoch in range(epochs):
        model.train()
        for idx in torch.randperm(len(train_x)).split(128):
            opt.zero_grad()
            loss = torch.nn.functional.huber_loss(model(train_x[idx]),train_y[idx])
            loss.backward(); opt.step()
        model.eval()
        with torch.no_grad():
            val_loss = torch.nn.functional.l1_loss(model(val_x),torch.tensor(yva,dtype=torch.float32)).item()
        if val_loss < best:
            best = val_loss
            best_state = {k:v.detach().clone() for k,v in model.state_dict().items()}
    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        pred_va = model(val_x).numpy()
        pred_te = model(transform(xte)).numpy()
    # Compare against last observed offered demand on identical held-out windows.
    persistence_va = np.repeat(xva[:,-1,0,None],3,axis=1)
    persistence_te = np.repeat(xte[:,-1,0,None],3,axis=1)
    gate = metrics(pred_va,yva)["mae_mbps"] < metrics(persistence_va,yva)["mae_mbps"]
    result = {"model_version":"gru-v1", "model_config":{},
              "gru_passed_gate":bool(gate),"validation_mae_mbps":metrics(pred_va,yva)["mae_mbps"],
              "validation_gru":metrics(pred_va,yva),"validation_persistence":metrics(persistence_va,yva),
              "test_gru":metrics(pred_te,yte),"test_persistence":metrics(persistence_te,yte),
              "seed":seed,"lookback":lookback,"train_windows":len(xtr),
              "validation_windows":len(xva),"test_windows":len(xte),
              "note":"Intervals are heuristic until calibrated on separate held-out residuals."}
    out = Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    torch.save(model.state_dict(),out/"weights.pt")
    joblib.dump(scaler,out/"scaler.joblib")
    (out/"metrics.json").write_text(json.dumps(result,indent=2))
    return result

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data",required=True)
    parser.add_argument("--output",default="artifacts/forecaster/v1")
    parser.add_argument("--epochs",type=int,default=12)
    args = parser.parse_args()
    print(json.dumps(train(args.data,args.output,args.epochs),indent=2))
