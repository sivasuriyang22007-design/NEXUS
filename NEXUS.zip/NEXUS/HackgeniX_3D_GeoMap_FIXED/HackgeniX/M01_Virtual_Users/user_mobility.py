# user_mobility.py

import numpy as np


def choose_next_cell(
    current_cell,
    cells,
    rng,
    mobility_probability=0.1
):
    """
    Select the next cell for a user.

    The same RNG produces reproducible results
    when the same seed is used.
    """

    if not cells:
        raise ValueError("Cell list cannot be empty")

    if rng.random() > mobility_probability:
        return current_cell

    other_cells = [
        cell for cell in cells
        if cell != current_cell
    ]

    if not other_cells:
        return current_cell

    index = rng.integers(0, len(other_cells))

    return other_cells[index]


def update_user_mobility(
    users,
    tick,
    cells,
    rng,
    mobility_probability=0.1
):
    """
    Update the location of users at a simulation tick.

    Returns movement events.
    """

    events = []

    for user in users:

        if not user.is_present(tick):
            continue

        old_cell = user.cell_id

        new_cell = choose_next_cell(
            old_cell,
            cells,
            rng,
            mobility_probability
        )

        if old_cell != new_cell:

            user.cell_id = new_cell

            events.append({
                "event": "CELL_CHANGE",
                "time": tick,
                "user_id": user.id,
                "from_cell": old_cell,
                "to_cell": new_cell
            })

    return events