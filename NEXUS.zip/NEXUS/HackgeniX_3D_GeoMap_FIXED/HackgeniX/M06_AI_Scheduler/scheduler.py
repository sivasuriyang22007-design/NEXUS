from resource_allocator import (
    reserve_minimums,
    allocate_remaining_capacity,
    project_to_constraints,
    apply_starvation_protection
)


class SafeScheduler:

    def __init__(self):

        self.previous_allocation = None

    def schedule(self, state, ppo_proposal=None):

        capacity = state["capacity"]
        groups = state["groups"]

        # ------------------------------------------------
        # STEP 1: Reserve mandatory minimum service
        # ------------------------------------------------

        minimum_result = reserve_minimums(
            groups,
            capacity
        )

        if not minimum_result["feasible"]:

            print(
                "WARNING: Minimum guarantees cannot fit."
            )

            print(
                "Required:",
                minimum_result["required"]
            )

            print(
                "Available:",
                capacity
            )

            # Explicit operator policy:
            # allocate available capacity proportionally
            allocation = {}

            total_demand = sum(
                group["demand"]
                for group in groups
            )

            for group in groups:

                if total_demand > 0:
                    allocation[group["name"]] = (
                        capacity
                        * group["demand"]
                        / total_demand
                    )
                else:
                    allocation[group["name"]] = 0

        else:

            allocation = minimum_result["allocation"]

            remaining = minimum_result["remaining"]

            # ------------------------------------------------
            # STEP 2: Protect latency-sensitive services
            # ------------------------------------------------

            for group in groups:

                if group["latency_sensitive"]:

                    extra = min(
                        remaining * 0.20,
                        max(
                            0,
                            group["demand"]
                            - allocation[group["name"]]
                        )
                    )

                    allocation[group["name"]] += extra

                    remaining -= extra

            # ------------------------------------------------
            # STEP 3: Heuristic weighted allocation
            # ------------------------------------------------

            allocation = allocate_remaining_capacity(
                groups,
                allocation,
                remaining
            )

        # ------------------------------------------------
        # STEP 4: PPO proposal
        # ------------------------------------------------

        if ppo_proposal is not None:

            allocation = self.apply_ppo_proposal(
                allocation,
                ppo_proposal
            )

        # ------------------------------------------------
        # STEP 5: Starvation protection
        # ------------------------------------------------

        allocation = apply_starvation_protection(
            groups,
            allocation
        )

        # ------------------------------------------------
        # STEP 6: Deterministic safety projector
        # ------------------------------------------------

        allocation = project_to_constraints(
            allocation,
            groups,
            capacity,
            self.previous_allocation
        )

        # Save allocation for next timestep
        self.previous_allocation = allocation.copy()

        return allocation

    def apply_ppo_proposal(
        self,
        allocation,
        proposal
    ):
        """
        PPO only modifies the proposal.
        It does NOT bypass safety constraints.
        """

        for name in allocation:

            if name in proposal:

                adjustment = proposal[name]

                allocation[name] *= adjustment

        return allocation