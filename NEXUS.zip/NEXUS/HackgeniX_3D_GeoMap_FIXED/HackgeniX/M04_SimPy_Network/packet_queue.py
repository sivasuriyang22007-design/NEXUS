# M04_SimPy_Network/packet_queue.py

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Optional, Any


@dataclass
class QueueItem:
    packet: Any
    enqueue_time: float


class PacketQueue:
    """
    Finite FIFO packet queue.

    Size is measured in bytes.
    """

    def __init__(
        self,
        max_bytes: int = 10_000_000,
        name: str = "queue",
    ):
        self.name = name
        self.max_bytes = max(1, int(max_bytes))

        self.items: deque[QueueItem] = deque()

        self.current_bytes = 0

        self.total_enqueued_bytes = 0
        self.total_dequeued_bytes = 0
        self.total_dropped_bytes = 0

        self.total_enqueued_packets = 0
        self.total_dequeued_packets = 0
        self.total_dropped_packets = 0

        self.total_wait_time = 0.0
        self.max_occupancy_bytes = 0

    def packet_size_bytes(self, packet: Any) -> int:
        """
        Extract packet size.

        Supports:
            packet.size_bytes
            packet.size
            packet.packet_size
        """

        if hasattr(packet, "size_bytes"):
            return max(1, int(packet.size_bytes))

        if hasattr(packet, "size"):
            return max(1, int(packet.size))

        if hasattr(packet, "packet_size"):
            return max(1, int(packet.packet_size))

        if isinstance(packet, dict):
            for key in ("size_bytes", "size", "packet_size"):
                if key in packet:
                    return max(1, int(packet[key]))

        raise ValueError("Packet must contain size_bytes, size or packet_size")

    def enqueue(self, packet: Any, current_time: float) -> bool:
        """Add packet if enough buffer space exists."""

        size = self.packet_size_bytes(packet)

        if self.current_bytes + size > self.max_bytes:
            self.total_dropped_bytes += size
            self.total_dropped_packets += 1
            return False

        self.items.append(
            QueueItem(
                packet=packet,
                enqueue_time=float(current_time),
            )
        )

        self.current_bytes += size

        self.total_enqueued_bytes += size
        self.total_enqueued_packets += 1

        self.max_occupancy_bytes = max(
            self.max_occupancy_bytes,
            self.current_bytes,
        )

        return True

    def dequeue(self, current_time: float) -> Optional[Any]:
        """Remove the oldest packet."""

        if not self.items:
            return None

        item = self.items.popleft()

        size = self.packet_size_bytes(item.packet)

        self.current_bytes -= size
        self.current_bytes = max(0, self.current_bytes)

        self.total_dequeued_bytes += size
        self.total_dequeued_packets += 1

        waiting_time = max(
            0.0,
            float(current_time) - item.enqueue_time,
        )

        self.total_wait_time += waiting_time

        # Attach queue waiting time when possible.
        try:
            setattr(item.packet, "queue_delay_seconds", waiting_time)
        except Exception:
            pass

        return item.packet

    def peek(self) -> Optional[Any]:
        if not self.items:
            return None

        return self.items[0].packet

    def is_empty(self) -> bool:
        return len(self.items) == 0

    def __len__(self) -> int:
        return len(self.items)

    @property
    def occupancy_bytes(self) -> int:
        return self.current_bytes

    @property
    def occupancy_ratio(self) -> float:
        return self.current_bytes / self.max_bytes

    @property
    def average_wait_time_seconds(self) -> float:
        if self.total_dequeued_packets == 0:
            return 0.0

        return self.total_wait_time / self.total_dequeued_packets

    def snapshot(self) -> dict:
        return {
            "name": self.name,
            "packets": len(self.items),
            "occupancy_bytes": self.current_bytes,
            "max_bytes": self.max_bytes,
            "occupancy_ratio": self.occupancy_ratio,
            "enqueued_packets": self.total_enqueued_packets,
            "dequeued_packets": self.total_dequeued_packets,
            "dropped_packets": self.total_dropped_packets,
            "enqueued_bytes": self.total_enqueued_bytes,
            "dequeued_bytes": self.total_dequeued_bytes,
            "dropped_bytes": self.total_dropped_bytes,
            "average_wait_seconds": self.average_wait_time_seconds,
        }