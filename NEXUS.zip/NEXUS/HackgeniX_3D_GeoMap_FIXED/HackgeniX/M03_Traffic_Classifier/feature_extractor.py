"""
NEXUS M03 - Feature extraction and validation.

Uses observable flow metadata only. No payload inspection, true labels,
configured QoS targets, or future values are used as classifier features.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd


FEATURE_SCHEMA_VERSION = "m03-features-v1"

FEATURE_COLUMNS = [
    "packet_rate",
    "packet_size_mean",
    "packet_size_std",
    "flow_duration",
    "burst_frequency",
    "ul_dl_ratio",
    "interarrival_mean",
    "interarrival_std",
    "retransmission_proxy",
    "rolling_rate_1s",
    "rolling_rate_5s",
    "rolling_rate_10s",
]


@dataclass(frozen=True)
class ValidatedFeatures:
    frame: pd.DataFrame
    schema_version: str = FEATURE_SCHEMA_VERSION


def validate_feature_frame(
    features: pd.DataFrame | Mapping[str, Sequence[float]],
    *,
    required_columns: Sequence[str] = FEATURE_COLUMNS,
    allow_extra: bool = False,
) -> pd.DataFrame:

    if not isinstance(features, pd.DataFrame):
        features = pd.DataFrame(features)

    expected = list(required_columns)

    missing = [c for c in expected if c not in features.columns]

    if missing:
        raise ValueError(
            f"Missing required classifier features: {missing}"
        )

    extras = [
        c for c in features.columns
        if c not in expected
    ]

    if extras and not allow_extra:
        raise ValueError(
            f"Unexpected classifier features: {extras}"
        )

    # Always restore canonical column ordering.
    ordered = features.loc[:, expected].copy()

    for col in expected:
        ordered[col] = pd.to_numeric(
            ordered[col],
            errors="coerce"
        )

    if ordered.empty:
        raise ValueError("Feature batch is empty.")

    return ordered


def _safe_ratio(
    num: pd.Series,
    den: pd.Series
) -> pd.Series:

    return (
        num / den.replace(0, np.nan)
    ).replace(
        [np.inf, -np.inf],
        np.nan
    )


def extract_flow_features(
    flow_batch: Iterable[Mapping],
    windows: Sequence[int] = (1, 5, 10),
    *,
    now: float | None = None,
) -> pd.DataFrame:

    records = list(flow_batch)

    if not records:
        return pd.DataFrame(
            columns=FEATURE_COLUMNS
        )

    raw = pd.DataFrame(records)

    if "timestamp" not in raw:
        raise ValueError(
            "flow_batch must contain timestamp."
        )

    if "flow_id" not in raw:
        raise ValueError(
            "flow_batch must contain flow_id."
        )

    raw["timestamp"] = pd.to_numeric(
        raw["timestamp"],
        errors="coerce"
    )

    raw = raw.dropna(
        subset=["timestamp"]
    ).copy()

    if raw.empty:
        return pd.DataFrame(
            columns=FEATURE_COLUMNS
        )

    if now is None:
        now = float(
            raw["timestamp"].max()
        )

    # Important:
    # Never use future observations.
    raw = raw.loc[
        raw["timestamp"] <= float(now)
    ].copy()

    if raw.empty:
        return pd.DataFrame(
            columns=FEATURE_COLUMNS
        )

    defaults = {
        "packets_per_s": np.nan,
        "packet_size_mean": np.nan,
        "packet_size_std": np.nan,
        "flow_duration": np.nan,
        "burst_frequency": np.nan,
        "ul_dl_ratio": np.nan,
        "interarrival_mean": np.nan,
        "interarrival_std": np.nan,
        "retransmission_proxy": np.nan,
        "rolling_rate": np.nan,
    }

    for col, default in defaults.items():

        if col not in raw:
            raw[col] = default

        raw[col] = pd.to_numeric(
            raw[col],
            errors="coerce"
        )

    raw = raw.sort_values(
        ["flow_id", "timestamp"]
    )

    # Most recent observable state for every flow.
    latest = (
        raw.groupby("flow_id", as_index=False)
        .tail(1)
        .set_index("flow_id")
    )

    out = pd.DataFrame(
        index=latest.index
    )

    out["packet_rate"] = (
        latest["packets_per_s"]
    )

    out["packet_size_mean"] = (
        latest["packet_size_mean"]
    )

    out["packet_size_std"] = (
        latest["packet_size_std"]
    )

    out["flow_duration"] = (
        latest["flow_duration"]
    )

    out["burst_frequency"] = (
        latest["burst_frequency"]
    )

    out["ul_dl_ratio"] = (
        latest["ul_dl_ratio"]
    )

    out["interarrival_mean"] = (
        latest["interarrival_mean"]
    )

    out["interarrival_std"] = (
        latest["interarrival_std"]
    )

    out["retransmission_proxy"] = (
        latest["retransmission_proxy"]
    )

    for window in windows:

        if window not in (1, 5, 10):
            continue

        start = float(now) - float(window)

        recent = raw.loc[
            raw["timestamp"] >= start
        ]

        grouped = recent.groupby(
            "flow_id"
        )

        packet_rate = (
            grouped["packets_per_s"]
            .mean()
        )

        explicit_rolling = (
            grouped["rolling_rate"]
            .mean()
        )

        value = explicit_rolling.combine_first(
            packet_rate
        )

        out[
            f"rolling_rate_{window}s"
        ] = value.reindex(
            out.index
        )

    out = out.reset_index(
        drop=True
    )

    return validate_feature_frame(
        out
    )


def validate_observation(
    features: pd.DataFrame
    | Mapping[str, Sequence[float]]
) -> ValidatedFeatures:

    frame = validate_feature_frame(
        features
    )

    invalid_rows = (
        frame
        .replace(
            [np.inf, -np.inf],
            np.nan
        )
        .isna()
        .all(axis=1)
    )

    if invalid_rows.any():
        raise ValueError(
            "At least one feature row contains "
            "no usable numeric values."
        )

    return ValidatedFeatures(
        frame=frame
    )